/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.22-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: festgatecomcalamar_db
-- ------------------------------------------------------
-- Server version	10.6.22-MariaDB-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` (`id`, `name`, `email`, `password`, `avatar`, `remember_token`, `created_at`, `updated_at`) VALUES (1,'webmaster@festgate.com','webmaster@festgate.com','$2y$10$/0lAfOz1KepD9omY5BHQOe2NHzfKPAzvzG21RSEc224CqnfXwfpMW',NULL,'W5AclOsgODye2oqgcIPztC0GBXQbnpBCYaqBIUTQQj2nwrk8mqbGrqmmTka5','2023-07-23 22:36:43','2025-12-24 10:32:05');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `award_types`
--

DROP TABLE IF EXISTS `award_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `award_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `award_types`
--

LOCK TABLES `award_types` WRITE;
/*!40000 ALTER TABLE `award_types` DISABLE KEYS */;
INSERT INTO `award_types` (`id`, `name`, `created_at`, `updated_at`) VALUES (1,'Screening',NULL,NULL),(3,'Semi-Finalist',NULL,NULL),(4,'Finalist',NULL,NULL),(5,' Award Winner',NULL,NULL),(6,'Selected',NULL,NULL),(7,'Quarter-Finalist',NULL,NULL),(8,'Nominee',NULL,NULL),(9,'Honorable Mention\r\n\r\n',NULL,NULL);
/*!40000 ALTER TABLE `award_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_items`
--

DROP TABLE IF EXISTS `cart_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `project_id` int(10) unsigned DEFAULT NULL,
  `deadline_id` int(10) unsigned DEFAULT NULL,
  `event_id` int(10) DEFAULT NULL,
  `season_id` int(10) DEFAULT NULL,
  `cat_id` int(10) DEFAULT NULL,
  `price` decimal(18,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `project_id` (`project_id`),
  KEY `deadline_id` (`deadline_id`),
  CONSTRAINT `cart_items_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_items_ibfk_2` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_items_ibfk_3` FOREIGN KEY (`deadline_id`) REFERENCES `deadlines` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_items`
--

LOCK TABLES `cart_items` WRITE;
/*!40000 ALTER TABLE `cart_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT 0,
  `description` varchar(400) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `event_id` int(10) DEFAULT NULL,
  `season_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=215 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id`, `name`, `order`, `description`, `user_id`, `event_id`, `season_id`, `created_at`, `updated_at`, `status`, `deleted_at`) VALUES (165,'Short',165,NULL,2440,77,NULL,'2023-07-24 11:38:19','2025-12-03 16:03:23',NULL,NULL),(166,'Music Video',166,NULL,2440,77,NULL,'2023-07-24 11:38:19','2025-12-03 16:03:23',NULL,NULL),(167,'Short',167,NULL,13,13,62,'2023-08-09 18:08:46','2025-12-03 16:03:23',NULL,'2025-12-03 16:03:23'),(168,'Feature',168,NULL,13,13,NULL,'2023-08-09 18:15:14','2025-12-03 16:03:23',NULL,NULL),(169,'Television',169,NULL,13,13,NULL,'2023-08-09 18:15:14','2025-12-03 16:03:23',NULL,NULL),(170,'Screenplay',170,NULL,13,13,NULL,'2023-08-09 18:15:14','2025-12-03 16:03:23',NULL,NULL),(171,'Artwork',171,NULL,13,13,NULL,'2023-08-09 18:15:14','2025-12-03 16:03:23',NULL,NULL),(172,'Short Films',172,NULL,2440,77,63,'2025-11-19 23:19:32','2025-11-20 00:09:07',NULL,'2025-11-20 00:09:07'),(173,'Music Videos',173,NULL,2440,77,63,'2025-11-19 23:19:32','2025-11-20 00:09:07',NULL,'2025-11-20 00:09:07'),(174,NULL,174,NULL,2440,77,63,'2025-11-19 23:19:32','2025-11-20 00:09:07',NULL,'2025-11-20 00:09:07'),(175,'Short',175,NULL,2440,77,63,'2025-11-20 00:56:32','2025-12-03 16:03:23',NULL,'2025-12-03 16:03:23'),(181,'Music Video',181,NULL,1,83,69,'2025-11-30 04:46:51','2025-12-03 16:03:23',NULL,'2025-12-03 16:03:23'),(182,'Short',182,NULL,1,83,69,'2025-12-02 17:53:42','2025-12-03 16:03:23',NULL,'2025-12-03 16:03:23'),(183,'Fiction',183,NULL,NULL,NULL,NULL,'2025-12-03 16:04:01','2025-12-03 16:04:01',NULL,NULL),(184,'Animation',184,NULL,NULL,NULL,NULL,'2025-12-03 16:04:01','2025-12-03 16:04:01',NULL,NULL),(185,'Documentary',185,NULL,NULL,NULL,NULL,'2025-12-03 16:04:01','2025-12-03 16:04:01',NULL,NULL),(186,'Experimental',186,NULL,NULL,NULL,NULL,'2025-12-03 16:04:01','2025-12-03 16:04:01',NULL,NULL),(187,'Student',187,NULL,NULL,NULL,NULL,'2025-12-03 16:04:01','2025-12-03 16:04:01',NULL,NULL),(188,'Web / New Media',188,NULL,NULL,NULL,NULL,'2025-12-03 16:04:01','2025-12-03 16:04:01',NULL,NULL),(189,'Short Script',189,NULL,NULL,NULL,NULL,'2025-12-03 16:04:01','2025-12-03 16:04:01',NULL,NULL),(190,'Stage Play',190,NULL,NULL,NULL,NULL,'2025-12-03 16:04:01','2025-12-03 16:04:01',NULL,NULL),(191,'Television Script',191,NULL,NULL,NULL,NULL,'2025-12-03 16:04:01','2025-12-03 16:04:01',NULL,NULL),(192,'Treatment',192,NULL,NULL,NULL,NULL,'2025-12-03 16:04:01','2025-12-03 16:04:01',NULL,NULL),(193,'Song',193,NULL,NULL,NULL,NULL,'2025-12-03 16:04:01','2025-12-03 16:04:01',NULL,NULL),(194,'Film Score',194,NULL,NULL,NULL,NULL,'2025-12-03 16:04:01','2025-12-03 16:04:01',NULL,NULL),(195,'Lyrics Only',195,NULL,NULL,NULL,NULL,'2025-12-03 16:04:01','2025-12-03 16:04:01',NULL,NULL),(196,'Virtual Reality',196,NULL,NULL,NULL,NULL,'2025-12-03 16:04:01','2025-12-03 16:04:01',NULL,NULL),(197,'Performance',197,NULL,NULL,NULL,NULL,'2025-12-03 16:04:01','2025-12-03 16:04:01',NULL,NULL),(198,'Installation',198,NULL,NULL,NULL,NULL,'2025-12-03 16:04:01','2025-12-03 16:04:01',NULL,NULL),(199,'Game',199,NULL,NULL,NULL,NULL,'2025-12-03 16:04:01','2025-12-03 16:04:01',NULL,NULL),(200,'Interactive Film',200,NULL,NULL,NULL,NULL,'2025-12-03 16:04:01','2025-12-03 16:04:01',NULL,NULL),(201,'360 Video',201,NULL,NULL,NULL,NULL,'2025-12-03 16:04:01','2025-12-03 16:04:01',NULL,NULL),(202,'Augmented Reality',202,NULL,NULL,NULL,NULL,'2025-12-03 16:04:01','2025-12-03 16:04:01',NULL,NULL),(203,'Photography',203,NULL,NULL,NULL,NULL,'2025-12-03 16:04:01','2025-12-03 16:04:01',NULL,NULL),(204,'Other',204,NULL,NULL,NULL,NULL,'2025-12-03 16:04:01','2025-12-03 16:04:01',NULL,NULL),(205,'Cortometrajes',0,NULL,1,83,69,'2025-12-05 20:47:47','2025-12-26 17:59:12',NULL,'2025-12-26 17:59:12'),(206,'Music Videos',0,NULL,1,84,70,'2025-12-24 14:18:06','2025-12-24 14:18:06',NULL,NULL),(207,'Series',0,NULL,1,84,70,'2025-12-24 14:18:06','2025-12-24 14:18:06',NULL,NULL),(208,'Artes Plasticas',0,NULL,1,84,70,'2025-12-24 14:18:06','2025-12-24 14:18:06',NULL,NULL),(209,'Mejor Actor',0,NULL,1,84,70,'2025-12-24 14:18:07','2025-12-24 14:18:07',NULL,NULL),(210,'Pintura IA',0,NULL,1,83,69,'2025-12-26 16:42:11','2025-12-26 17:59:12',NULL,'2025-12-26 17:59:12'),(211,'Fotografia',0,NULL,1,83,69,'2025-12-26 16:44:33','2025-12-26 16:44:33',NULL,NULL),(212,'Estudiantes Gratis',0,NULL,1,83,69,'2025-12-26 16:44:33','2025-12-26 16:44:33',NULL,NULL),(213,'Cine',0,NULL,1,83,69,'2025-12-26 17:59:12','2025-12-26 17:59:12',NULL,NULL),(214,'Guion',0,NULL,1,83,69,'2025-12-26 17:59:12','2025-12-26 17:59:12',NULL,NULL);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_deadline`
--

DROP TABLE IF EXISTS `category_deadline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `category_deadline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned DEFAULT NULL,
  `deadline_id` int(10) unsigned DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `deadline_id` (`deadline_id`),
  CONSTRAINT `category_deadline_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `category_deadline_ibfk_2` FOREIGN KEY (`deadline_id`) REFERENCES `deadlines` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=521 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_deadline`
--

LOCK TABLES `category_deadline` WRITE;
/*!40000 ALTER TABLE `category_deadline` DISABLE KEYS */;
INSERT INTO `category_deadline` (`id`, `category_id`, `deadline_id`, `price`, `created_at`, `updated_at`) VALUES (351,167,315,10.00,'2023-08-09 18:08:46','2025-11-10 21:13:35'),(352,168,315,20.00,'2023-08-09 18:15:14','2025-11-10 21:13:35'),(353,169,315,10.00,'2023-08-09 18:15:14','2025-11-10 21:13:35'),(354,170,315,20.00,'2023-08-09 18:15:14','2025-11-10 21:13:35'),(355,171,315,10.00,'2023-08-09 18:15:14','2025-11-10 21:13:35'),(404,181,353,20.00,'2025-12-02 17:53:42','2025-12-02 17:53:42'),(405,181,354,30.00,'2025-12-02 17:53:42','2025-12-02 17:53:42'),(406,181,355,40.00,'2025-12-02 17:53:42','2025-12-02 17:53:42'),(408,182,353,20.00,'2025-12-02 17:53:42','2025-12-02 17:53:42'),(409,182,354,30.00,'2025-12-02 17:53:42','2025-12-02 17:53:42'),(410,182,355,40.00,'2025-12-02 17:53:42','2025-12-02 17:53:42'),(411,181,352,10.00,'2025-12-02 18:58:21','2025-12-02 18:58:21'),(412,182,352,10.00,'2025-12-02 18:58:21','2025-12-02 18:58:21'),(481,206,383,10.00,'2025-12-26 10:35:19','2025-12-26 10:35:19'),(482,206,384,20.00,'2025-12-26 10:35:19','2025-12-26 10:35:19'),(483,206,385,30.00,'2025-12-26 10:35:19','2025-12-26 10:35:19'),(484,206,386,40.00,'2025-12-26 10:35:19','2025-12-26 10:35:19'),(485,207,383,5.00,'2025-12-26 10:35:19','2025-12-26 10:35:19'),(486,207,384,10.00,'2025-12-26 10:35:19','2025-12-26 10:35:19'),(487,207,385,15.00,'2025-12-26 10:35:19','2025-12-26 10:35:19'),(488,207,386,20.00,'2025-12-26 10:35:19','2025-12-26 10:35:19'),(489,208,383,7.00,'2025-12-26 10:35:19','2025-12-26 10:35:19'),(490,208,384,8.00,'2025-12-26 10:35:19','2025-12-26 10:35:19'),(491,208,385,9.00,'2025-12-26 10:35:19','2025-12-26 10:35:19'),(492,208,386,10.00,'2025-12-26 10:35:19','2025-12-26 10:35:19'),(493,209,383,10.00,'2025-12-26 10:35:19','2025-12-26 10:35:19'),(494,209,384,11.00,'2025-12-26 10:35:19','2025-12-26 10:35:19'),(495,209,385,12.00,'2025-12-26 10:35:19','2025-12-26 10:35:19'),(496,209,386,13.00,'2025-12-26 10:35:19','2025-12-26 10:35:19'),(505,205,391,20.00,'2025-12-26 16:44:33','2025-12-26 16:44:33'),(506,205,392,30.00,'2025-12-26 16:44:33','2025-12-26 16:44:33'),(507,210,391,20.00,'2025-12-26 16:44:33','2025-12-26 16:44:33'),(508,210,392,30.00,'2025-12-26 16:44:33','2025-12-26 16:44:33'),(513,211,395,10.00,'2025-12-26 17:59:12','2025-12-26 17:59:12'),(514,211,396,20.00,'2025-12-26 17:59:12','2025-12-26 17:59:12'),(515,212,395,0.00,'2025-12-26 17:59:12','2025-12-26 17:59:12'),(516,212,396,0.00,'2025-12-26 17:59:12','2025-12-26 17:59:12'),(517,213,395,10.00,'2025-12-26 17:59:12','2025-12-26 17:59:12'),(518,213,396,20.00,'2025-12-26 17:59:12','2025-12-26 17:59:12'),(519,214,395,25.00,'2025-12-26 17:59:12','2025-12-26 17:59:12'),(520,214,396,35.00,'2025-12-26 17:59:12','2025-12-26 17:59:12');
/*!40000 ALTER TABLE `category_deadline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `certificate_templates`
--

DROP TABLE IF EXISTS `certificate_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `certificate_templates` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `file_location` varchar(255) NOT NULL,
  `event_id` int(10) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certificate_templates`
--

LOCK TABLES `certificate_templates` WRITE;
/*!40000 ALTER TABLE `certificate_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `certificate_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commission_settings`
--

DROP TABLE IF EXISTS `commission_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `commission_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `commissionable_type` varchar(255) NOT NULL,
  `commissionable_id` bigint(20) unsigned NOT NULL,
  `platform_fee_percentage` decimal(5,2) NOT NULL DEFAULT 8.00,
  `fixed_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `commission_settings_commissionable_type_commissionable_id_index` (`commissionable_type`,`commissionable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commission_settings`
--

LOCK TABLES `commission_settings` WRITE;
/*!40000 ALTER TABLE `commission_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `commission_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_messages`
--

DROP TABLE IF EXISTS `contact_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_messages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1513 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_messages`
--

LOCK TABLES `contact_messages` WRITE;
/*!40000 ALTER TABLE `contact_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_code` varchar(2) NOT NULL DEFAULT '',
  `country_name` varchar(100) NOT NULL DEFAULT '',
  `name` varchar(120) NOT NULL,
  `nationality` varchar(120) NOT NULL,
  `order` varchar(4) NOT NULL DEFAULT '0',
  `is_default` tinyint(3) unsigned NOT NULL,
  `status` varchar(60) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=243 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `name`, `nationality`, `order`, `is_default`, `status`, `created_at`, `updated_at`) VALUES (1,'US','United States','','','',0,'','2022-01-22 10:37:25',0),(2,'CA','Canada','','','',0,'','2022-01-22 10:37:25',0),(3,'AF','Afghanistan','','','',0,'','2022-01-22 10:37:25',0),(4,'AL','Albania','','','',0,'','2022-01-22 10:37:25',0),(5,'DZ','Algeria','','','',0,'','2022-01-22 10:37:25',0),(6,'DS','American Samoa','','','',0,'','2022-01-22 10:37:25',0),(7,'AD','Andorra','','','',0,'','2022-01-22 10:37:25',0),(8,'AO','Angola','','','',0,'','2022-01-22 10:37:25',0),(9,'AI','Anguilla','','','',0,'','2022-01-22 10:37:25',0),(10,'AQ','Antarctica','','','',0,'','2022-01-22 10:37:25',0),(11,'AG','Antigua and/or Barbuda','','','',0,'','2022-01-22 10:37:25',0),(12,'AR','Argentina','','','',0,'','2022-01-22 10:37:25',0),(13,'AM','Armenia','','','',0,'','2022-01-22 10:37:25',0),(14,'AW','Aruba','','','',0,'','2022-01-22 10:37:25',0),(15,'AU','Australia','','','',0,'','2022-01-22 10:37:25',0),(16,'AT','Austria','','','',0,'','2022-01-22 10:37:25',0),(17,'AZ','Azerbaijan','','','',0,'','2022-01-22 10:37:25',0),(18,'BS','Bahamas','','','',0,'','2022-01-22 10:37:25',0),(19,'BH','Bahrain','','','',0,'','2022-01-22 10:37:25',0),(20,'BD','Bangladesh','','','',0,'','2022-01-22 10:37:25',0),(21,'BB','Barbados','','','',0,'','2022-01-22 10:37:25',0),(22,'BY','Belarus','','','',0,'','2022-01-22 10:37:25',0),(23,'BE','Belgium','','','',0,'','2022-01-22 10:37:25',0),(24,'BZ','Belize','','','',0,'','2022-01-22 10:37:25',0),(25,'BJ','Benin','','','',0,'','2022-01-22 10:37:25',0),(26,'BM','Bermuda','','','',0,'','2022-01-22 10:37:25',0),(27,'BT','Bhutan','','','',0,'','2022-01-22 10:37:25',0),(28,'BO','Bolivia','','','',0,'','2022-01-22 10:37:25',0),(29,'BA','Bosnia and Herzegovina','','','',0,'','2022-01-22 10:37:25',0),(30,'BW','Botswana','','','',0,'','2022-01-22 10:37:25',0),(31,'BV','Bouvet Island','','','',0,'','2022-01-22 10:37:25',0),(32,'BR','Brazil','','','',0,'','2022-01-22 10:37:25',0),(33,'IO','British lndian Ocean Territory','','','',0,'','2022-01-22 10:37:25',0),(34,'BN','Brunei Darussalam','','','',0,'','2022-01-22 10:37:25',0),(35,'BG','Bulgaria','','','',0,'','2022-01-22 10:37:25',0),(36,'BF','Burkina Faso','','','',0,'','2022-01-22 10:37:25',0),(37,'BI','Burundi','','','',0,'','2022-01-22 10:37:25',0),(38,'KH','Cambodia','','','',0,'','2022-01-22 10:37:25',0),(39,'CM','Cameroon','','','',0,'','2022-01-22 10:37:25',0),(40,'CV','Cape Verde','','','',0,'','2022-01-22 10:37:25',0),(41,'KY','Cayman Islands','','','',0,'','2022-01-22 10:37:25',0),(42,'CF','Central African Republic','','','',0,'','2022-01-22 10:37:25',0),(43,'TD','Chad','','','',0,'','2022-01-22 10:37:25',0),(44,'CL','Chile','','','',0,'','2022-01-22 10:37:25',0),(45,'CN','China','','','',0,'','2022-01-22 10:37:25',0),(46,'CX','Christmas Island','','','',0,'','2022-01-22 10:37:25',0),(47,'CC','Cocos (Keeling) Islands','','','',0,'','2022-01-22 10:37:25',0),(48,'CO','Colombia','','','',0,'','2022-01-22 10:37:25',0),(49,'KM','Comoros','','','',0,'','2022-01-22 10:37:25',0),(50,'CG','Congo','','','',0,'','2022-01-22 10:37:25',0),(51,'CK','Cook Islands','','','',0,'','2022-01-22 10:37:25',0),(52,'CR','Costa Rica','','','',0,'','2022-01-22 10:37:25',0),(53,'HR','Croatia (Hrvatska)','','','',0,'','2022-01-22 10:37:25',0),(54,'CU','Cuba','','','',0,'','2022-01-22 10:37:25',0),(55,'CY','Cyprus','','','',0,'','2022-01-22 10:37:25',0),(56,'CZ','Czech Republic','','','',0,'','2022-01-22 10:37:25',0),(57,'DK','Denmark','','','',0,'','2022-01-22 10:37:25',0),(58,'DJ','Djibouti','','','',0,'','2022-01-22 10:37:25',0),(59,'DM','Dominica','','','',0,'','2022-01-22 10:37:25',0),(60,'DO','Dominican Republic','','','',0,'','2022-01-22 10:37:25',0),(61,'TP','East Timor','','','',0,'','2022-01-22 10:37:25',0),(62,'EC','Ecuador','','','',0,'','2022-01-22 10:37:25',0),(63,'EG','Egypt','','','',0,'','2022-01-22 10:37:25',0),(64,'SV','El Salvador','','','',0,'','2022-01-22 10:37:25',0),(65,'GQ','Equatorial Guinea','','','',0,'','2022-01-22 10:37:25',0),(66,'ER','Eritrea','','','',0,'','2022-01-22 10:37:25',0),(67,'EE','Estonia','','','',0,'','2022-01-22 10:37:25',0),(68,'ET','Ethiopia','','','',0,'','2022-01-22 10:37:25',0),(69,'FK','Falkland Islands (Malvinas)','','','',0,'','2022-01-22 10:37:25',0),(70,'FO','Faroe Islands','','','',0,'','2022-01-22 10:37:25',0),(71,'FJ','Fiji','','','',0,'','2022-01-22 10:37:25',0),(72,'FI','Finland','','','',0,'','2022-01-22 10:37:25',0),(73,'FR','France','','','',0,'','2022-01-22 10:37:25',0),(74,'FX','France, Metropolitan','','','',0,'','2022-01-22 10:37:25',0),(75,'GF','French Guiana','','','',0,'','2022-01-22 10:37:25',0),(76,'PF','French Polynesia','','','',0,'','2022-01-22 10:37:25',0),(77,'TF','French Southern Territories','','','',0,'','2022-01-22 10:37:25',0),(78,'GA','Gabon','','','',0,'','2022-01-22 10:37:25',0),(79,'GM','Gambia','','','',0,'','2022-01-22 10:37:25',0),(80,'GE','Georgia','','','',0,'','2022-01-22 10:37:25',0),(81,'DE','Germany','','','',0,'','2022-01-22 10:37:25',0),(82,'GH','Ghana','','','',0,'','2022-01-22 10:37:25',0),(83,'GI','Gibraltar','','','',0,'','2022-01-22 10:37:25',0),(84,'GR','Greece','','','',0,'','2022-01-22 10:37:25',0),(85,'GL','Greenland','','','',0,'','2022-01-22 10:37:25',0),(86,'GD','Grenada','','','',0,'','2022-01-22 10:37:25',0),(87,'GP','Guadeloupe','','','',0,'','2022-01-22 10:37:25',0),(88,'GU','Guam','','','',0,'','2022-01-22 10:37:25',0),(89,'GT','Guatemala','','','',0,'','2022-01-22 10:37:25',0),(90,'GN','Guinea','','','',0,'','2022-01-22 10:37:25',0),(91,'GW','Guinea-Bissau','','','',0,'','2022-01-22 10:37:25',0),(92,'GY','Guyana','','','',0,'','2022-01-22 10:37:25',0),(93,'HT','Haiti','','','',0,'','2022-01-22 10:37:25',0),(94,'HM','Heard and Mc Donald Islands','','','',0,'','2022-01-22 10:37:25',0),(95,'HN','Honduras','','','',0,'','2022-01-22 10:37:25',0),(96,'HK','Hong Kong','','','',0,'','2022-01-22 10:37:25',0),(97,'HU','Hungary','','','',0,'','2022-01-22 10:37:25',0),(98,'IS','Iceland','','','',0,'','2022-01-22 10:37:25',0),(99,'IN','India','','','',0,'','2022-01-22 10:37:25',0),(100,'ID','Indonesia','','','',0,'','2022-01-22 10:37:25',0),(101,'IR','Iran (Islamic Republic of)','','','',0,'','2022-01-22 10:37:25',0),(102,'IQ','Iraq','','','',0,'','2022-01-22 10:37:25',0),(103,'IE','Ireland','','','',0,'','2022-01-22 10:37:25',0),(104,'IL','Israel','','','',0,'','2022-01-22 10:37:25',0),(105,'IT','Italy','','','',0,'','2022-01-22 10:37:25',0),(106,'CI','Ivory Coast','','','',0,'','2022-01-22 10:37:25',0),(107,'JM','Jamaica','','','',0,'','2022-01-22 10:37:25',0),(108,'JP','Japan','','','',0,'','2022-01-22 10:37:25',0),(109,'JO','Jordan','','','',0,'','2022-01-22 10:37:25',0),(110,'KZ','Kazakhstan','','','',0,'','2022-01-22 10:37:25',0),(111,'KE','Kenya','','','',0,'','2022-01-22 10:37:25',0),(112,'KI','Kiribati','','','',0,'','2022-01-22 10:37:25',0),(113,'KP','Korea, Democratic People\'s Republic of','','','',0,'','2022-01-22 10:37:25',0),(114,'KR','Korea, Republic of','','','',0,'','2022-01-22 10:37:25',0),(115,'XK','Kosovo','','','',0,'','2022-01-22 10:37:25',0),(116,'KW','Kuwait','','','',0,'','2022-01-22 10:37:25',0),(117,'KG','Kyrgyzstan','','','',0,'','2022-01-22 10:37:25',0),(118,'LA','Lao People\'s Democratic Republic','','','',0,'','2022-01-22 10:37:25',0),(119,'LV','Latvia','','','',0,'','2022-01-22 10:37:25',0),(120,'LB','Lebanon','','','',0,'','2022-01-22 10:37:25',0),(121,'LS','Lesotho','','','',0,'','2022-01-22 10:37:25',0),(122,'LR','Liberia','','','',0,'','2022-01-22 10:37:25',0),(123,'LY','Libyan Arab Jamahiriya','','','',0,'','2022-01-22 10:37:25',0),(124,'LI','Liechtenstein','','','',0,'','2022-01-22 10:37:25',0),(125,'LT','Lithuania','','','',0,'','2022-01-22 10:37:25',0),(126,'LU','Luxembourg','','','',0,'','2022-01-22 10:37:25',0),(127,'MO','Macau','','','',0,'','2022-01-22 10:37:25',0),(128,'MK','Macedonia','','','',0,'','2022-01-22 10:37:25',0),(129,'MG','Madagascar','','','',0,'','2022-01-22 10:37:25',0),(130,'MW','Malawi','','','',0,'','2022-01-22 10:37:25',0),(131,'MY','Malaysia','','','',0,'','2022-01-22 10:37:25',0),(132,'MV','Maldives','','','',0,'','2022-01-22 10:37:25',0),(133,'ML','Mali','','','',0,'','2022-01-22 10:37:25',0),(134,'MT','Malta','','','',0,'','2022-01-22 10:37:25',0),(135,'MH','Marshall Islands','','','',0,'','2022-01-22 10:37:25',0),(136,'MQ','Martinique','','','',0,'','2022-01-22 10:37:25',0),(137,'MR','Mauritania','','','',0,'','2022-01-22 10:37:25',0),(138,'MU','Mauritius','','','',0,'','2022-01-22 10:37:25',0),(139,'TY','Mayotte','','','',0,'','2022-01-22 10:37:25',0),(140,'MX','Mexico','','','',0,'','2022-01-22 10:37:25',0),(141,'FM','Micronesia, Federated States of','','','',0,'','2022-01-22 10:37:25',0),(142,'MD','Moldova, Republic of','','','',0,'','2022-01-22 10:37:25',0),(143,'MC','Monaco','','','',0,'','2022-01-22 10:37:25',0),(144,'MN','Mongolia','','','',0,'','2022-01-22 10:37:25',0),(145,'ME','Montenegro','','','',0,'','2022-01-22 10:37:25',0),(146,'MS','Montserrat','','','',0,'','2022-01-22 10:37:25',0),(147,'MA','Morocco','','','',0,'','2022-01-22 10:37:25',0),(148,'MZ','Mozambique','','','',0,'','2022-01-22 10:37:25',0),(149,'MM','Myanmar','','','',0,'','2022-01-22 10:37:25',0),(150,'NA','Namibia','','','',0,'','2022-01-22 10:37:25',0),(151,'NR','Nauru','','','',0,'','2022-01-22 10:37:25',0),(152,'NP','Nepal','','','',0,'','2022-01-22 10:37:25',0),(153,'NL','Netherlands','','','',0,'','2022-01-22 10:37:25',0),(154,'AN','Netherlands Antilles','','','',0,'','2022-01-22 10:37:25',0),(155,'NC','New Caledonia','','','',0,'','2022-01-22 10:37:25',0),(156,'NZ','New Zealand','','','',0,'','2022-01-22 10:37:25',0),(157,'NI','Nicaragua','','','',0,'','2022-01-22 10:37:25',0),(158,'NE','Niger','','','',0,'','2022-01-22 10:37:25',0),(159,'NG','Nigeria','','','',0,'','2022-01-22 10:37:25',0),(160,'NU','Niue','','','',0,'','2022-01-22 10:37:25',0),(161,'NF','Norfork Island','','','',0,'','2022-01-22 10:37:25',0),(162,'MP','Northern Mariana Islands','','','',0,'','2022-01-22 10:37:25',0),(163,'NO','Norway','','','',0,'','2022-01-22 10:37:25',0),(164,'OM','Oman','','','',0,'','2022-01-22 10:37:25',0),(165,'PK','Pakistan','','','',0,'','2022-01-22 10:37:25',0),(166,'PW','Palau','','','',0,'','2022-01-22 10:37:25',0),(167,'PA','Panama','','','',0,'','2022-01-22 10:37:25',0),(168,'PG','Papua New Guinea','','','',0,'','2022-01-22 10:37:25',0),(169,'PY','Paraguay','','','',0,'','2022-01-22 10:37:25',0),(170,'PE','Peru','','','',0,'','2022-01-22 10:37:25',0),(171,'PH','Philippines','','','',0,'','2022-01-22 10:37:25',0),(172,'PN','Pitcairn','','','',0,'','2022-01-22 10:37:25',0),(173,'PL','Poland','','','',0,'','2022-01-22 10:37:25',0),(174,'PT','Portugal','','','',0,'','2022-01-22 10:37:25',0),(175,'PR','Puerto Rico','','','',0,'','2022-01-22 10:37:25',0),(176,'QA','Qatar','','','',0,'','2022-01-22 10:37:25',0),(177,'RE','Reunion','','','',0,'','2022-01-22 10:37:25',0),(178,'RO','Romania','','','',0,'','2022-01-22 10:37:25',0),(179,'RU','Russian Federation','','','',0,'','2022-01-22 10:37:25',0),(180,'RW','Rwanda','','','',0,'','2022-01-22 10:37:25',0),(181,'KN','Saint Kitts and Nevis','','','',0,'','2022-01-22 10:37:25',0),(182,'LC','Saint Lucia','','','',0,'','2022-01-22 10:37:25',0),(183,'VC','Saint Vincent and the Grenadines','','','',0,'','2022-01-22 10:37:25',0),(184,'WS','Samoa','','','',0,'','2022-01-22 10:37:25',0),(185,'SM','San Marino','','','',0,'','2022-01-22 10:37:25',0),(186,'ST','Sao Tome and Principe','','','',0,'','2022-01-22 10:37:25',0),(187,'SA','Saudi Arabia','','','',0,'','2022-01-22 10:37:25',0),(188,'SN','Senegal','','','',0,'','2022-01-22 10:37:25',0),(189,'RS','Serbia','','','',0,'','2022-01-22 10:37:25',0),(190,'SC','Seychelles','','','',0,'','2022-01-22 10:37:25',0),(191,'SL','Sierra Leone','','','',0,'','2022-01-22 10:37:25',0),(192,'SG','Singapore','','','',0,'','2022-01-22 10:37:25',0),(193,'SK','Slovakia','','','',0,'','2022-01-22 10:37:25',0),(194,'SI','Slovenia','','','',0,'','2022-01-22 10:37:25',0),(195,'SB','Solomon Islands','','','',0,'','2022-01-22 10:37:25',0),(196,'SO','Somalia','','','',0,'','2022-01-22 10:37:25',0),(197,'ZA','South Africa','','','',0,'','2022-01-22 10:37:25',0),(198,'GS','South Georgia South Sandwich Islands','','','',0,'','2022-01-22 10:37:25',0),(199,'ES','Spain','','','',0,'','2022-01-22 10:37:25',0),(200,'LK','Sri Lanka','','','',0,'','2022-01-22 10:37:25',0),(201,'SH','St. Helena','','','',0,'','2022-01-22 10:37:25',0),(202,'PM','St. Pierre and Miquelon','','','',0,'','2022-01-22 10:37:25',0),(203,'SD','Sudan','','','',0,'','2022-01-22 10:37:25',0),(204,'SR','Suriname','','','',0,'','2022-01-22 10:37:25',0),(205,'SJ','Svalbarn and Jan Mayen Islands','','','',0,'','2022-01-22 10:37:25',0),(206,'SZ','Swaziland','','','',0,'','2022-01-22 10:37:25',0),(207,'SE','Sweden','','','',0,'','2022-01-22 10:37:25',0),(208,'CH','Switzerland','','','',0,'','2022-01-22 10:37:25',0),(209,'SY','Syrian Arab Republic','','','',0,'','2022-01-22 10:37:25',0),(210,'TW','Taiwan','','','',0,'','2022-01-22 10:37:25',0),(211,'TJ','Tajikistan','','','',0,'','2022-01-22 10:37:25',0),(212,'TZ','Tanzania, United Republic of','','','',0,'','2022-01-22 10:37:25',0),(213,'TH','Thailand','','','',0,'','2022-01-22 10:37:25',0),(214,'TG','Togo','','','',0,'','2022-01-22 10:37:25',0),(215,'TK','Tokelau','','','',0,'','2022-01-22 10:37:25',0),(216,'TO','Tonga','','','',0,'','2022-01-22 10:37:25',0),(217,'TT','Trinidad and Tobago','','','',0,'','2022-01-22 10:37:25',0),(218,'TN','Tunisia','','','',0,'','2022-01-22 10:37:25',0),(219,'TR','Turkey','','','',0,'','2022-01-22 10:37:25',0),(220,'TM','Turkmenistan','','','',0,'','2022-01-22 10:37:25',0),(221,'TC','Turks and Caicos Islands','','','',0,'','2022-01-22 10:37:25',0),(222,'TV','Tuvalu','','','',0,'','2022-01-22 10:37:25',0),(223,'UG','Uganda','','','',0,'','2022-01-22 10:37:25',0),(224,'UA','Ukraine','','','',0,'','2022-01-22 10:37:25',0),(225,'AE','United Arab Emirates','','','',0,'','2022-01-22 10:37:25',0),(226,'GB','United Kingdom','','','',0,'','2022-01-22 10:37:25',0),(227,'UM','United States minor outlying islands','','','',0,'','2022-01-22 10:37:25',0),(228,'UY','Uruguay','','','',0,'','2022-01-22 10:37:25',0),(229,'UZ','Uzbekistan','','','',0,'','2022-01-22 10:37:25',0),(230,'VU','Vanuatu','','','',0,'','2022-01-22 10:37:25',0),(231,'VA','Vatican City State','','','',0,'','2022-01-22 10:37:25',0),(232,'VE','Venezuela','','','',0,'','2022-01-22 10:37:25',0),(233,'VN','Vietnam','','','',0,'','2022-01-22 10:37:25',0),(234,'VG','Virgin Islands (British)','','','',0,'','2022-01-22 10:37:25',0),(235,'VI','Virgin Islands (U.S.)','','','',0,'','2022-01-22 10:37:25',0),(236,'WF','Wallis and Futuna Islands','','','',0,'','2022-01-22 10:37:25',0),(237,'EH','Western Sahara','','','',0,'','2022-01-22 10:37:25',0),(238,'YE','Yemen','','','',0,'','2022-01-22 10:37:25',0),(239,'YU','Yugoslavia','','','',0,'','2022-01-22 10:37:25',0),(240,'ZR','Zaire','','','',0,'','2022-01-22 10:37:25',0),(241,'ZM','Zambia','','','',0,'','2022-01-22 10:37:25',0),(242,'ZW','Zimbabwe','','','',0,'','2022-01-22 10:37:25',0);
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupons` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `event_id` varchar(20) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(20) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `amount_type` varchar(20) DEFAULT NULL,
  `maximum_uses` varchar(255) DEFAULT NULL,
  `times` int(10) DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
INSERT INTO `coupons` (`id`, `event_id`, `name`, `type`, `amount`, `amount_type`, `maximum_uses`, `times`, `start_date`, `end_date`, `created_at`, `updated_at`) VALUES (17,'77','A100','Discount',1.00,'%',NULL,12,'2023-07-01','2023-12-31','2023-07-28 12:20:39','2023-07-31 23:01:06');
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crew_credits`
--

DROP TABLE IF EXISTS `crew_credits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `crew_credits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(10) NOT NULL,
  `crew_type_id` int(10) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `imdb` varchar(255) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_crew_credits_crew_type` (`crew_type_id`),
  KEY `fk_crew_credits_projects` (`project_id`) USING BTREE,
  CONSTRAINT `fk_crew_credits_crew_type` FOREIGN KEY (`crew_type_id`) REFERENCES `crew_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crew_credits`
--

LOCK TABLES `crew_credits` WRITE;
/*!40000 ALTER TABLE `crew_credits` DISABLE KEYS */;
INSERT INTO `crew_credits` (`id`, `project_id`, `crew_type_id`, `name`, `description`, `imdb`, `updated_at`, `created_at`) VALUES (5,175,1,'Julian Gomez','musico bso','87eweiuimab','2023-07-14 21:50:38','2023-07-14 21:50:38'),(38,38,2,'Tery Logan',NULL,'https://www.imdb.com/name/nm6710031/','2023-07-21 20:59:32','2023-07-21 20:59:32'),(42,38,65,'Nilo Zimmerman',NULL,'https://www.imdb.com/name/nm0613385/','2023-07-21 21:16:35','2023-07-21 21:16:35');
/*!40000 ALTER TABLE `crew_credits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crew_types`
--

DROP TABLE IF EXISTS `crew_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `crew_types` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crew_types`
--

LOCK TABLES `crew_types` WRITE;
/*!40000 ALTER TABLE `crew_types` DISABLE KEYS */;
INSERT INTO `crew_types` (`id`, `name`) VALUES (1,'Composer'),(2,'Writer'),(3,'Producer'),(4,'1st Assistant Director'),(5,'2nd Assistant Director'),(6,'Casting Director'),(7,'Director'),(8,'Set PA'),(9,'Makeup Artist'),(10,'Costume Designer'),(11,'Hair Stylist'),(12,'SPFX Makeup Designer'),(13,'Prosthetics Designer'),(14,'Boom Operator'),(15,'Sound Assistant'),(16,'Sound Mixer'),(17,'Production Sound Mixer'),(18,'Choreographer'),(19,'Stunt Coordinator'),(20,'Stunt Performer'),(21,'Set Medic'),(22,'Special Effects Coordinator'),(23,'VFX Supervisor'),(24,'VFX Coordinator'),(25,'Location Scout'),(26,'Location Manager'),(27,'Caterer'),(28,'Craft Services'),(29,'Associate Producer'),(30,'Executive Producer'),(31,'Financier'),(32,'Line Producer'),(33,'Office PA'),(34,'Production Assistant'),(35,'Production Accountant'),(36,'Production Coordinator'),(37,'Unit Production Manager'),(38,'Entertainment Lawyer'),(39,'Art Director'),(40,'Production Designer'),(41,'Art PA'),(42,'Driver'),(43,'Prop Master'),(44,'Set Decorator'),(45,'Set Dresser'),(46,'Transportation Coordinator'),(47,'Wardrobe Supervisor'),(48,'Set Costumer'),(49,'Costume Coordinator'),(50,'Tailor'),(51,'Shopper'),(52,'Weapons Wrangler'),(53,'Screenwriter'),(54,'Script Supervisor'),(55,'Digital Imaging Technician'),(56,'On-Set Editor'),(57,'Key PA'),(58,'Video Assist Operator'),(59,'1st Assistant Camera'),(60,'2nd Assistant Camera'),(61,'Best Boy'),(62,'Best Boy Grip'),(63,'Camera Operator'),(64,'Dolly Grip'),(65,'Director of Photography'),(66,'Generator Operator'),(67,'Electrician'),(68,'Key Grip'),(69,'Film Loader'),(70,'Gaffer'),(71,'Grip'),(72,'Camera & Lighting Department'),(73,'Directorial Department'),(74,'Hair and Makeup Department'),(75,'Sound Department'),(76,'Stunts Department'),(77,'Special Effects Department'),(78,'Locations Department'),(79,'Food Department'),(80,'Production Department'),(81,'Art Department'),(82,'Script Department'),(83,'Editorial Department'),(84,'Other');
/*!40000 ALTER TABLE `crew_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_form_fields`
--

DROP TABLE IF EXISTS `custom_form_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_form_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` int(10) unsigned NOT NULL,
  `field_type` enum('text','textarea','select','checkbox','radio','file') NOT NULL DEFAULT 'text',
  `question` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`options`)),
  `is_required` tinyint(1) NOT NULL DEFAULT 0,
  `all_categories` tinyint(1) NOT NULL DEFAULT 1,
  `category_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`category_ids`)),
  `order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_form_fields_event_id_foreign` (`event_id`),
  CONSTRAINT `custom_form_fields_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_form_fields`
--

LOCK TABLES `custom_form_fields` WRITE;
/*!40000 ALTER TABLE `custom_form_fields` DISABLE KEYS */;
INSERT INTO `custom_form_fields` (`id`, `event_id`, `field_type`, `question`, `description`, `options`, `is_required`, `all_categories`, `category_ids`, `order`, `is_active`, `created_at`, `updated_at`) VALUES (1,83,'select','Te interesa que nuestros partners te contacen?','Siempre se puede cancelar','[\"Si\",\"No\"]',1,1,NULL,1,1,'2025-12-02 06:13:59','2025-12-02 06:15:28');
/*!40000 ALTER TABLE `custom_form_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_form_responses`
--

DROP TABLE IF EXISTS `custom_form_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_form_responses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `custom_form_field_id` int(10) unsigned NOT NULL,
  `submission_id` int(10) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `response` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_form_responses_custom_form_field_id_foreign` (`custom_form_field_id`),
  KEY `custom_form_responses_submission_id_foreign` (`submission_id`),
  KEY `custom_form_responses_user_id_foreign` (`user_id`),
  CONSTRAINT `custom_form_responses_custom_form_field_id_foreign` FOREIGN KEY (`custom_form_field_id`) REFERENCES `custom_form_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `custom_form_responses_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `custom_form_responses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_form_responses`
--

LOCK TABLES `custom_form_responses` WRITE;
/*!40000 ALTER TABLE `custom_form_responses` DISABLE KEYS */;
INSERT INTO `custom_form_responses` (`id`, `custom_form_field_id`, `submission_id`, `user_id`, `response`, `created_at`, `updated_at`) VALUES (1,1,76,4,'Si','2025-12-02 06:44:42','2025-12-02 06:44:42'),(2,1,77,4,'No','2025-12-02 07:29:55','2025-12-02 07:29:55'),(3,1,78,4,'Si','2025-12-02 18:53:54','2025-12-02 18:53:54');
/*!40000 ALTER TABLE `custom_form_responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deadlines`
--

DROP TABLE IF EXISTS `deadlines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `deadlines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` int(10) unsigned DEFAULT NULL,
  `season_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `season_id` (`season_id`),
  CONSTRAINT `deadlines_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`),
  CONSTRAINT `deadlines_ibfk_2` FOREIGN KEY (`season_id`) REFERENCES `seasons` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=397 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deadlines`
--

LOCK TABLES `deadlines` WRITE;
/*!40000 ALTER TABLE `deadlines` DISABLE KEYS */;
INSERT INTO `deadlines` (`id`, `event_id`, `season_id`, `name`, `user_id`, `date`, `created_at`, `updated_at`, `deleted_at`) VALUES (315,13,62,'Regular Deadline',13,'2023-08-09','2023-08-09 18:08:46','2023-08-09 20:12:20',NULL),(318,77,63,'Enero',2440,'2026-01-30','2025-11-19 22:53:57','2025-11-19 23:19:32','2025-11-19 23:19:32'),(319,77,63,'Febrero',2440,'2026-02-28','2025-11-19 22:53:57','2025-11-19 23:19:32','2025-11-19 23:19:32'),(322,77,63,'Noviembre',2440,'2025-11-20','2025-11-20 00:45:14','2025-11-20 00:56:32','2025-11-20 00:56:32'),(352,83,69,'Deadline Early Bird',NULL,'2025-12-30','2025-11-30 06:23:02','2025-12-05 20:47:47','2025-12-05 20:47:47'),(353,83,69,'Deadline Regular',NULL,'2026-01-29','2025-11-30 06:23:02','2025-12-05 20:47:47','2025-12-05 20:47:47'),(354,83,69,'Deadline Tardío',NULL,'2026-02-28','2025-11-30 06:23:02','2025-12-05 20:47:47','2025-12-05 20:47:47'),(355,83,69,'Deadline Extendido',NULL,'2026-03-30','2025-11-30 06:23:02','2025-12-05 20:47:47','2025-12-05 20:47:47'),(363,83,69,'Deadline Early Bird',1,'2025-12-30','2025-12-05 20:47:47','2025-12-26 16:42:11','2025-12-26 16:42:11'),(364,83,69,'Deadline Regular',1,'2025-01-29','2025-12-05 20:47:47','2025-12-26 16:42:11','2025-12-26 16:42:11'),(365,83,69,'Deadline Tardío',1,'2025-02-28','2025-12-05 20:47:47','2025-12-26 16:42:11','2025-12-26 16:42:11'),(366,83,69,'Deadline Extendido',1,'2025-03-30','2025-12-05 20:47:47','2025-12-26 16:42:11','2025-12-26 16:42:11'),(367,84,70,'Deadline Early Bird',1,'2026-01-23','2025-12-24 14:18:06','2025-12-25 19:19:52','2025-12-25 19:19:52'),(368,84,70,'Deadline Regular',1,'2026-02-22','2025-12-24 14:18:06','2025-12-25 19:19:52','2025-12-25 19:19:52'),(369,84,70,'Deadline Tardío',1,'2026-03-24','2025-12-24 14:18:06','2025-12-25 19:19:52','2025-12-25 19:19:52'),(370,84,70,'Deadline Extendido',1,'2026-04-23','2025-12-24 14:18:06','2025-12-25 19:19:52','2025-12-25 19:19:52'),(371,84,70,'Deadline Early Bird',1,'2026-01-23','2025-12-25 19:19:52','2025-12-25 19:19:59','2025-12-25 19:19:59'),(372,84,70,'Deadline Regular',1,'2026-02-22','2025-12-25 19:19:52','2025-12-25 19:19:59','2025-12-25 19:19:59'),(373,84,70,'Deadline Tardío',1,'2026-03-24','2025-12-25 19:19:52','2025-12-25 19:19:59','2025-12-25 19:19:59'),(374,84,70,'Deadline Extendido',1,'2026-04-23','2025-12-25 19:19:52','2025-12-25 19:19:59','2025-12-25 19:19:59'),(375,84,70,'Deadline Early Bird',1,'2026-01-23','2025-12-25 19:19:59','2025-12-26 10:22:02','2025-12-26 10:22:02'),(376,84,70,'Deadline Regular',1,'2026-02-22','2025-12-25 19:19:59','2025-12-26 10:22:02','2025-12-26 10:22:02'),(377,84,70,'Deadline Tardío',1,'2026-03-24','2025-12-25 19:19:59','2025-12-26 10:22:02','2025-12-26 10:22:02'),(378,84,70,'Deadline Extendido',1,'2026-04-23','2025-12-25 19:19:59','2025-12-26 10:22:02','2025-12-26 10:22:02'),(379,84,70,'Deadline Early Bird',1,'2026-01-23','2025-12-26 10:22:02','2025-12-26 10:35:19','2025-12-26 10:35:19'),(380,84,70,'Deadline Regular',1,'2026-02-22','2025-12-26 10:22:02','2025-12-26 10:35:19','2025-12-26 10:35:19'),(381,84,70,'Deadline Tardío',1,'2026-03-24','2025-12-26 10:22:02','2025-12-26 10:35:19','2025-12-26 10:35:19'),(382,84,70,'Deadline Extendido',1,'2026-04-23','2025-12-26 10:22:02','2025-12-26 10:35:19','2025-12-26 10:35:19'),(383,84,70,'Deadline Early Bird',1,'2026-01-23','2025-12-26 10:35:19','2025-12-26 10:35:19',NULL),(384,84,70,'Deadline Regular',1,'2026-02-22','2025-12-26 10:35:19','2025-12-26 10:35:19',NULL),(385,84,70,'Deadline Tardío',1,'2026-03-24','2025-12-26 10:35:19','2025-12-26 10:35:19',NULL),(386,84,70,'Deadline Extendido',1,'2026-04-23','2025-12-26 10:35:19','2025-12-26 10:35:19',NULL),(387,83,69,'Deadline Early Bird',1,'2025-12-30','2025-12-26 16:42:11','2025-12-26 16:43:25','2025-12-26 16:43:25'),(388,83,69,'Deadline Regular',1,'2026-01-31','2025-12-26 16:42:11','2025-12-26 16:44:33','2025-12-26 16:44:33'),(389,83,69,'Deadline Tardío',1,'2026-02-28','2025-12-26 16:42:11','2025-12-26 16:44:33','2025-12-26 16:44:33'),(390,83,69,'Deadline Extendido',1,'2025-03-30','2025-12-26 16:42:11','2025-12-26 16:43:25','2025-12-26 16:43:25'),(391,83,69,'Deadline Regular',1,'2026-01-31','2025-12-26 16:44:33','2025-12-26 17:49:33','2025-12-26 17:49:33'),(392,83,69,'Deadline Tardío',1,'2026-02-28','2025-12-26 16:44:33','2025-12-26 17:49:33','2025-12-26 17:49:33'),(393,83,69,'Deadline Regular',1,'2026-01-30','2025-12-26 16:44:33','2025-12-26 17:59:12','2025-12-26 17:59:12'),(394,83,69,'Deadline Tardío',1,'2026-02-28','2025-12-26 16:44:33','2025-12-26 17:59:12','2025-12-26 17:59:12'),(395,83,69,'Deadline Regular',1,'2026-01-30','2025-12-26 17:59:12','2025-12-26 17:59:12',NULL),(396,83,69,'Deadline Tardío',1,'2026-02-28','2025-12-26 17:59:12','2025-12-26 17:59:12',NULL);
/*!40000 ALTER TABLE `deadlines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diploma_logs`
--

DROP TABLE IF EXISTS `diploma_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `diploma_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `diploma_id` bigint(20) unsigned NOT NULL,
  `action` enum('generated','downloaded','sent','viewed','verified','regenerated') NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_diploma` (`diploma_id`),
  KEY `idx_action` (`action`),
  CONSTRAINT `diploma_logs_ibfk_1` FOREIGN KEY (`diploma_id`) REFERENCES `diplomas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `diploma_logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diploma_logs`
--

LOCK TABLES `diploma_logs` WRITE;
/*!40000 ALTER TABLE `diploma_logs` DISABLE KEYS */;
INSERT INTO `diploma_logs` (`id`, `diploma_id`, `action`, `user_id`, `ip_address`, `user_agent`, `metadata`, `created_at`, `updated_at`) VALUES (1,1,'verified',2440,'162.158.123.28','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','{\"referrer\":\"https:\\/\\/www.festgate.com\\/dashboard\\/submissions\\/56\",\"timestamp\":\"2025-11-18T18:58:01+00:00\"}',NULL,NULL),(2,1,'verified',2440,'162.158.120.177','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','{\"referrer\":\"https:\\/\\/www.festgate.com\\/dashboard\\/submissions\\/56\",\"timestamp\":\"2025-11-18T19:06:33+00:00\"}',NULL,NULL),(3,1,'generated',2440,'162.158.123.28','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','{\"type\":\"regenerated\"}',NULL,NULL),(4,1,'downloaded',2440,'162.158.123.28','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL,NULL),(5,1,'sent',2440,'162.158.123.28','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','{\"email\":\"antoni.caimari.caldes@gmail.com\"}',NULL,NULL),(6,1,'downloaded',2440,'162.158.123.28','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','{\"download_type\":\"permanent_link\"}',NULL,NULL),(7,1,'verified',2440,'162.158.123.28','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','{\"referrer\":null,\"timestamp\":\"2025-11-18T19:29:44+00:00\"}',NULL,NULL),(8,1,'verified',2440,'162.158.123.29','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','{\"referrer\":\"https:\\/\\/www.festgate.com\\/dashboard\\/submissions\\/56\",\"timestamp\":\"2025-11-18T19:32:34+00:00\"}',NULL,NULL),(9,1,'downloaded',2440,'162.158.120.177','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','{\"download_type\":\"permanent_link\"}',NULL,NULL),(10,1,'verified',1,'85.52.116.226','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','{\"referrer\":\"https:\\/\\/festgate.com\\/dashboard\\/submissions\\/73\",\"timestamp\":\"2025-11-30T15:38:46+00:00\"}',NULL,NULL),(11,1,'downloaded',1,'85.52.116.226','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','{\"download_type\":\"permanent_link\"}',NULL,NULL);
/*!40000 ALTER TABLE `diploma_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diploma_templates`
--

DROP TABLE IF EXISTS `diploma_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `diploma_templates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `template_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`template_data`)),
  `default_text` text DEFAULT NULL,
  `background_image` varchar(255) DEFAULT NULL,
  `diploma_logo` varchar(255) DEFAULT NULL,
  `logo_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`logo_settings`)),
  `logo_position` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`logo_position`)),
  `colors` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`colors`)),
  `fonts` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`fonts`)),
  `is_active` tinyint(1) DEFAULT 1,
  `is_default` tinyint(1) DEFAULT 0,
  `certificate_prefix` varchar(50) DEFAULT 'CERT',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_event_active` (`event_id`,`is_active`),
  KEY `idx_default` (`is_default`),
  CONSTRAINT `diploma_templates_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diploma_templates`
--

LOCK TABLES `diploma_templates` WRITE;
/*!40000 ALTER TABLE `diploma_templates` DISABLE KEYS */;
INSERT INTO `diploma_templates` (`id`, `event_id`, `name`, `description`, `template_data`, `default_text`, `background_image`, `diploma_logo`, `logo_settings`, `logo_position`, `colors`, `fonts`, `is_active`, `is_default`, `certificate_prefix`, `created_at`, `updated_at`) VALUES (1,77,'Plantilla Por Defecto','Plantilla generada automáticamente',NULL,NULL,NULL,NULL,NULL,NULL,'{\"primary\":\"#000000\",\"secondary\":\"#666666\",\"border\":\"#CCCCCC\"}','{\"title\":\"Times New Roman\",\"body\":\"Arial\",\"sizes\":{\"title\":48,\"subtitle\":24,\"body\":16}}',1,1,'IBES','2025-11-18 17:37:09','2025-11-18 17:37:09'),(2,83,'test',NULL,'{\"version\":\"5.3.0\",\"objects\":[{\"type\":\"rect\",\"version\":\"5.3.0\",\"originX\":\"left\",\"originY\":\"top\",\"left\":30,\"top\":30,\"width\":1063,\"height\":734,\"fill\":\"transparent\",\"stroke\":\"#c4a24c\",\"strokeWidth\":3,\"strokeDashArray\":null,\"strokeLineCap\":\"butt\",\"strokeDashOffset\":0,\"strokeLineJoin\":\"miter\",\"strokeUniform\":false,\"strokeMiterLimit\":4,\"scaleX\":1,\"scaleY\":1,\"angle\":0,\"flipX\":false,\"flipY\":false,\"opacity\":1,\"shadow\":null,\"visible\":true,\"backgroundColor\":\"\",\"fillRule\":\"nonzero\",\"paintFirst\":\"fill\",\"globalCompositeOperation\":\"source-over\",\"skewX\":0,\"skewY\":0,\"rx\":0,\"ry\":0},{\"type\":\"rect\",\"version\":\"5.3.0\",\"originX\":\"left\",\"originY\":\"top\",\"left\":45,\"top\":45,\"width\":1033,\"height\":704,\"fill\":\"transparent\",\"stroke\":\"#c4a24c\",\"strokeWidth\":1,\"strokeDashArray\":null,\"strokeLineCap\":\"butt\",\"strokeDashOffset\":0,\"strokeLineJoin\":\"miter\",\"strokeUniform\":false,\"strokeMiterLimit\":4,\"scaleX\":1,\"scaleY\":1,\"angle\":0,\"flipX\":false,\"flipY\":false,\"opacity\":1,\"shadow\":null,\"visible\":true,\"backgroundColor\":\"\",\"fillRule\":\"nonzero\",\"paintFirst\":\"fill\",\"globalCompositeOperation\":\"source-over\",\"skewX\":0,\"skewY\":0,\"rx\":0,\"ry\":0},{\"type\":\"i-text\",\"version\":\"5.3.0\",\"originX\":\"center\",\"originY\":\"top\",\"left\":561.5,\"top\":95.28,\"width\":337.16,\"height\":72.32,\"fill\":\"#c4a24c\",\"stroke\":null,\"strokeWidth\":1,\"strokeDashArray\":null,\"strokeLineCap\":\"butt\",\"strokeDashOffset\":0,\"strokeLineJoin\":\"miter\",\"strokeUniform\":false,\"strokeMiterLimit\":4,\"scaleX\":1,\"scaleY\":1,\"angle\":0,\"flipX\":false,\"flipY\":false,\"opacity\":1,\"shadow\":null,\"visible\":true,\"backgroundColor\":\"\",\"fillRule\":\"nonzero\",\"paintFirst\":\"fill\",\"globalCompositeOperation\":\"source-over\",\"skewX\":0,\"skewY\":0,\"fontFamily\":\"Georgia\",\"fontWeight\":\"bold\",\"fontSize\":64,\"text\":\"DIPLOMA\",\"underline\":false,\"overline\":false,\"linethrough\":false,\"textAlign\":\"left\",\"fontStyle\":\"normal\",\"lineHeight\":1.16,\"textBackgroundColor\":\"\",\"charSpacing\":0,\"styles\":[],\"direction\":\"ltr\",\"path\":null,\"pathStartOffset\":0,\"pathSide\":\"left\",\"pathAlign\":\"baseline\"},{\"type\":\"i-text\",\"version\":\"5.3.0\",\"originX\":\"center\",\"originY\":\"top\",\"left\":561.5,\"top\":174.68,\"width\":236.67,\"height\":31.64,\"fill\":\"#333333\",\"stroke\":null,\"strokeWidth\":1,\"strokeDashArray\":null,\"strokeLineCap\":\"butt\",\"strokeDashOffset\":0,\"strokeLineJoin\":\"miter\",\"strokeUniform\":false,\"strokeMiterLimit\":4,\"scaleX\":1,\"scaleY\":1,\"angle\":0,\"flipX\":false,\"flipY\":false,\"opacity\":1,\"shadow\":null,\"visible\":true,\"backgroundColor\":\"\",\"fillRule\":\"nonzero\",\"paintFirst\":\"fill\",\"globalCompositeOperation\":\"source-over\",\"skewX\":0,\"skewY\":0,\"fontFamily\":\"Georgia\",\"fontWeight\":\"normal\",\"fontSize\":28,\"text\":\"de Reconocimiento\",\"underline\":false,\"overline\":false,\"linethrough\":false,\"textAlign\":\"left\",\"fontStyle\":\"italic\",\"lineHeight\":1.16,\"textBackgroundColor\":\"\",\"charSpacing\":0,\"styles\":[],\"direction\":\"ltr\",\"path\":null,\"pathStartOffset\":0,\"pathSide\":\"left\",\"pathAlign\":\"baseline\"},{\"type\":\"line\",\"version\":\"5.3.0\",\"originX\":\"left\",\"originY\":\"top\",\"left\":280.75,\"top\":222.32,\"width\":561.5,\"height\":0,\"fill\":\"rgb(0,0,0)\",\"stroke\":\"#c4a24c\",\"strokeWidth\":2,\"strokeDashArray\":null,\"strokeLineCap\":\"butt\",\"strokeDashOffset\":0,\"strokeLineJoin\":\"miter\",\"strokeUniform\":false,\"strokeMiterLimit\":4,\"scaleX\":1,\"scaleY\":1,\"angle\":0,\"flipX\":false,\"flipY\":false,\"opacity\":1,\"shadow\":null,\"visible\":true,\"backgroundColor\":\"\",\"fillRule\":\"nonzero\",\"paintFirst\":\"fill\",\"globalCompositeOperation\":\"source-over\",\"skewX\":0,\"skewY\":0,\"x1\":-280.75,\"x2\":280.75,\"y1\":0,\"y2\":0},{\"type\":\"i-text\",\"version\":\"5.3.0\",\"originX\":\"center\",\"originY\":\"top\",\"left\":561.5,\"top\":269.96,\"width\":93.41,\"height\":20.34,\"fill\":\"#333333\",\"stroke\":null,\"strokeWidth\":1,\"strokeDashArray\":null,\"strokeLineCap\":\"butt\",\"strokeDashOffset\":0,\"strokeLineJoin\":\"miter\",\"strokeUniform\":false,\"strokeMiterLimit\":4,\"scaleX\":1,\"scaleY\":1,\"angle\":0,\"flipX\":false,\"flipY\":false,\"opacity\":1,\"shadow\":null,\"visible\":true,\"backgroundColor\":\"\",\"fillRule\":\"nonzero\",\"paintFirst\":\"fill\",\"globalCompositeOperation\":\"source-over\",\"skewX\":0,\"skewY\":0,\"fontFamily\":\"Georgia\",\"fontWeight\":\"normal\",\"fontSize\":18,\"text\":\"Se otorga a:\",\"underline\":false,\"overline\":false,\"linethrough\":false,\"textAlign\":\"left\",\"fontStyle\":\"normal\",\"lineHeight\":1.16,\"textBackgroundColor\":\"\",\"charSpacing\":0,\"styles\":[],\"direction\":\"ltr\",\"path\":null,\"pathStartOffset\":0,\"pathSide\":\"left\",\"pathAlign\":\"baseline\"},{\"type\":\"i-text\",\"version\":\"5.3.0\",\"originX\":\"center\",\"originY\":\"top\",\"left\":561.5,\"top\":349.36,\"width\":490.71,\"height\":54.24,\"fill\":\"#333333\",\"stroke\":null,\"strokeWidth\":1,\"strokeDashArray\":null,\"strokeLineCap\":\"butt\",\"strokeDashOffset\":0,\"strokeLineJoin\":\"miter\",\"strokeUniform\":false,\"strokeMiterLimit\":4,\"scaleX\":1,\"scaleY\":1,\"angle\":0,\"flipX\":false,\"flipY\":false,\"opacity\":1,\"shadow\":null,\"visible\":true,\"backgroundColor\":\"\",\"fillRule\":\"nonzero\",\"paintFirst\":\"fill\",\"globalCompositeOperation\":\"source-over\",\"skewX\":0,\"skewY\":0,\"fontFamily\":\"Georgia\",\"fontWeight\":\"bold\",\"fontSize\":48,\"text\":\"{{recipient_name}}\",\"underline\":false,\"overline\":false,\"linethrough\":false,\"textAlign\":\"left\",\"fontStyle\":\"normal\",\"lineHeight\":1.16,\"textBackgroundColor\":\"\",\"charSpacing\":0,\"styles\":[],\"direction\":\"ltr\",\"path\":null,\"pathStartOffset\":0,\"pathSide\":\"left\",\"pathAlign\":\"baseline\"},{\"type\":\"i-text\",\"version\":\"5.3.0\",\"originX\":\"center\",\"originY\":\"top\",\"left\":561.5,\"top\":444.64,\"width\":266.44,\"height\":20.34,\"fill\":\"#333333\",\"stroke\":null,\"strokeWidth\":1,\"strokeDashArray\":null,\"strokeLineCap\":\"butt\",\"strokeDashOffset\":0,\"strokeLineJoin\":\"miter\",\"strokeUniform\":false,\"strokeMiterLimit\":4,\"scaleX\":1,\"scaleY\":1,\"angle\":0,\"flipX\":false,\"flipY\":false,\"opacity\":1,\"shadow\":null,\"visible\":true,\"backgroundColor\":\"\",\"fillRule\":\"nonzero\",\"paintFirst\":\"fill\",\"globalCompositeOperation\":\"source-over\",\"skewX\":0,\"skewY\":0,\"fontFamily\":\"Georgia\",\"fontWeight\":\"normal\",\"fontSize\":18,\"text\":\"Por su destacada participaci\\u00f3n en\",\"underline\":false,\"overline\":false,\"linethrough\":false,\"textAlign\":\"left\",\"fontStyle\":\"normal\",\"lineHeight\":1.16,\"textBackgroundColor\":\"\",\"charSpacing\":0,\"styles\":[],\"direction\":\"ltr\",\"path\":null,\"pathStartOffset\":0,\"pathSide\":\"left\",\"pathAlign\":\"baseline\"},{\"type\":\"i-text\",\"version\":\"5.3.0\",\"originX\":\"center\",\"originY\":\"top\",\"left\":561.5,\"top\":508.16,\"width\":233.47,\"height\":36.16,\"fill\":\"#c4a24c\",\"stroke\":null,\"strokeWidth\":1,\"strokeDashArray\":null,\"strokeLineCap\":\"butt\",\"strokeDashOffset\":0,\"strokeLineJoin\":\"miter\",\"strokeUniform\":false,\"strokeMiterLimit\":4,\"scaleX\":1,\"scaleY\":1,\"angle\":0,\"flipX\":false,\"flipY\":false,\"opacity\":1,\"shadow\":null,\"visible\":true,\"backgroundColor\":\"\",\"fillRule\":\"nonzero\",\"paintFirst\":\"fill\",\"globalCompositeOperation\":\"source-over\",\"skewX\":0,\"skewY\":0,\"fontFamily\":\"Georgia\",\"fontWeight\":\"normal\",\"fontSize\":32,\"text\":\"{{event_name}}\",\"underline\":false,\"overline\":false,\"linethrough\":false,\"textAlign\":\"left\",\"fontStyle\":\"italic\",\"lineHeight\":1.16,\"textBackgroundColor\":\"\",\"charSpacing\":0,\"styles\":[],\"direction\":\"ltr\",\"path\":null,\"pathStartOffset\":0,\"pathSide\":\"left\",\"pathAlign\":\"baseline\"},{\"type\":\"i-text\",\"version\":\"5.3.0\",\"originX\":\"center\",\"originY\":\"top\",\"left\":561.5,\"top\":579.62,\"width\":103.78,\"height\":18.08,\"fill\":\"#333333\",\"stroke\":null,\"strokeWidth\":1,\"strokeDashArray\":null,\"strokeLineCap\":\"butt\",\"strokeDashOffset\":0,\"strokeLineJoin\":\"miter\",\"strokeUniform\":false,\"strokeMiterLimit\":4,\"scaleX\":1,\"scaleY\":1,\"angle\":0,\"flipX\":false,\"flipY\":false,\"opacity\":1,\"shadow\":null,\"visible\":true,\"backgroundColor\":\"\",\"fillRule\":\"nonzero\",\"paintFirst\":\"fill\",\"globalCompositeOperation\":\"source-over\",\"skewX\":0,\"skewY\":0,\"fontFamily\":\"Georgia\",\"fontWeight\":\"normal\",\"fontSize\":16,\"text\":\"{{issue_date}}\",\"underline\":false,\"overline\":false,\"linethrough\":false,\"textAlign\":\"left\",\"fontStyle\":\"normal\",\"lineHeight\":1.16,\"textBackgroundColor\":\"\",\"charSpacing\":0,\"styles\":[],\"direction\":\"ltr\",\"path\":null,\"pathStartOffset\":0,\"pathSide\":\"left\",\"pathAlign\":\"baseline\"},{\"type\":\"line\",\"version\":\"5.3.0\",\"originX\":\"left\",\"originY\":\"top\",\"left\":224.44,\"top\":698.72,\"width\":180,\"height\":0,\"fill\":\"rgb(0,0,0)\",\"stroke\":\"#333333\",\"strokeWidth\":1,\"strokeDashArray\":null,\"strokeLineCap\":\"butt\",\"strokeDashOffset\":0,\"strokeLineJoin\":\"miter\",\"strokeUniform\":false,\"strokeMiterLimit\":4,\"scaleX\":1,\"scaleY\":1,\"angle\":0,\"flipX\":false,\"flipY\":false,\"opacity\":1,\"shadow\":null,\"visible\":true,\"backgroundColor\":\"\",\"fillRule\":\"nonzero\",\"paintFirst\":\"fill\",\"globalCompositeOperation\":\"source-over\",\"skewX\":0,\"skewY\":0,\"x1\":-90,\"x2\":90,\"y1\":0,\"y2\":0},{\"type\":\"text\",\"version\":\"5.3.0\",\"originX\":\"center\",\"originY\":\"top\",\"left\":314.44,\"top\":708.72,\"width\":32.24,\"height\":13.56,\"fill\":\"#333333\",\"stroke\":null,\"strokeWidth\":1,\"strokeDashArray\":null,\"strokeLineCap\":\"butt\",\"strokeDashOffset\":0,\"strokeLineJoin\":\"miter\",\"strokeUniform\":false,\"strokeMiterLimit\":4,\"scaleX\":1,\"scaleY\":1,\"angle\":0,\"flipX\":false,\"flipY\":false,\"opacity\":1,\"shadow\":null,\"visible\":true,\"backgroundColor\":\"\",\"fillRule\":\"nonzero\",\"paintFirst\":\"fill\",\"globalCompositeOperation\":\"source-over\",\"skewX\":0,\"skewY\":0,\"fontFamily\":\"Georgia\",\"fontWeight\":\"normal\",\"fontSize\":12,\"text\":\"Firma\",\"underline\":false,\"overline\":false,\"linethrough\":false,\"textAlign\":\"left\",\"fontStyle\":\"normal\",\"lineHeight\":1.16,\"textBackgroundColor\":\"\",\"charSpacing\":0,\"styles\":[],\"direction\":\"ltr\",\"path\":null,\"pathStartOffset\":0,\"pathSide\":\"left\",\"pathAlign\":\"baseline\"},{\"type\":\"line\",\"version\":\"5.3.0\",\"originX\":\"left\",\"originY\":\"top\",\"left\":718.56,\"top\":698.72,\"width\":180,\"height\":0,\"fill\":\"rgb(0,0,0)\",\"stroke\":\"#333333\",\"strokeWidth\":1,\"strokeDashArray\":null,\"strokeLineCap\":\"butt\",\"strokeDashOffset\":0,\"strokeLineJoin\":\"miter\",\"strokeUniform\":false,\"strokeMiterLimit\":4,\"scaleX\":1,\"scaleY\":1,\"angle\":0,\"flipX\":false,\"flipY\":false,\"opacity\":1,\"shadow\":null,\"visible\":true,\"backgroundColor\":\"\",\"fillRule\":\"nonzero\",\"paintFirst\":\"fill\",\"globalCompositeOperation\":\"source-over\",\"skewX\":0,\"skewY\":0,\"x1\":-90,\"x2\":90,\"y1\":0,\"y2\":0},{\"type\":\"text\",\"version\":\"5.3.0\",\"originX\":\"center\",\"originY\":\"top\",\"left\":808.56,\"top\":708.72,\"width\":44.2,\"height\":13.56,\"fill\":\"#333333\",\"stroke\":null,\"strokeWidth\":1,\"strokeDashArray\":null,\"strokeLineCap\":\"butt\",\"strokeDashOffset\":0,\"strokeLineJoin\":\"miter\",\"strokeUniform\":false,\"strokeMiterLimit\":4,\"scaleX\":1,\"scaleY\":1,\"angle\":0,\"flipX\":false,\"flipY\":false,\"opacity\":1,\"shadow\":null,\"visible\":true,\"backgroundColor\":\"\",\"fillRule\":\"nonzero\",\"paintFirst\":\"fill\",\"globalCompositeOperation\":\"source-over\",\"skewX\":0,\"skewY\":0,\"fontFamily\":\"Georgia\",\"fontWeight\":\"normal\",\"fontSize\":12,\"text\":\"Director\",\"underline\":false,\"overline\":false,\"linethrough\":false,\"textAlign\":\"left\",\"fontStyle\":\"normal\",\"lineHeight\":1.16,\"textBackgroundColor\":\"\",\"charSpacing\":0,\"styles\":[],\"direction\":\"ltr\",\"path\":null,\"pathStartOffset\":0,\"pathSide\":\"left\",\"pathAlign\":\"baseline\"},{\"type\":\"i-text\",\"version\":\"5.3.0\",\"originX\":\"right\",\"originY\":\"top\",\"left\":1073,\"top\":759,\"width\":165.03,\"height\":12.43,\"fill\":\"#999999\",\"stroke\":null,\"strokeWidth\":1,\"strokeDashArray\":null,\"strokeLineCap\":\"butt\",\"strokeDashOffset\":0,\"strokeLineJoin\":\"miter\",\"strokeUniform\":false,\"strokeMiterLimit\":4,\"scaleX\":1,\"scaleY\":1,\"angle\":0,\"flipX\":false,\"flipY\":false,\"opacity\":1,\"shadow\":null,\"visible\":true,\"backgroundColor\":\"\",\"fillRule\":\"nonzero\",\"paintFirst\":\"fill\",\"globalCompositeOperation\":\"source-over\",\"skewX\":0,\"skewY\":0,\"fontFamily\":\"Courier New\",\"fontWeight\":\"normal\",\"fontSize\":11,\"text\":\"N\\u00b0 {{certificate_number}}\",\"underline\":false,\"overline\":false,\"linethrough\":false,\"textAlign\":\"left\",\"fontStyle\":\"normal\",\"lineHeight\":1.16,\"textBackgroundColor\":\"\",\"charSpacing\":0,\"styles\":[],\"direction\":\"ltr\",\"path\":null,\"pathStartOffset\":0,\"pathSide\":\"left\",\"pathAlign\":\"baseline\"}],\"background\":\"#ffffff\",\"paperSize\":\"a4_landscape\",\"pdfWidth\":297,\"pdfHeight\":210}',NULL,NULL,NULL,'{\"width\":150,\"height\":\"auto\",\"position\":\"top-center\"}',NULL,'{\"primary\":\"#c4a24c\",\"secondary\":\"#8b7355\",\"text\":\"#333333\"}','{\"title\":\"Georgia\",\"body\":\"Arial\",\"sizes\":{\"title\":48,\"subtitle\":28,\"body\":16}}',1,0,'TEST','2025-12-01 19:05:55','2025-12-01 19:05:55');
/*!40000 ALTER TABLE `diploma_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diplomas`
--

DROP TABLE IF EXISTS `diplomas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `diplomas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `certificate_number` varchar(100) NOT NULL,
  `event_id` int(10) unsigned NOT NULL,
  `submission_id` int(11) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `project_id` int(10) unsigned NOT NULL,
  `template_id` bigint(20) unsigned DEFAULT NULL,
  `diploma_type` enum('Award Winner','Finalist','Semi-Finalist','Quarter-Finalist','Nominee','Honorable Mention') NOT NULL,
  `category_name` varchar(255) DEFAULT NULL,
  `award_name` varchar(255) DEFAULT NULL,
  `recipient_name` varchar(255) NOT NULL,
  `project_title` varchar(255) NOT NULL,
  `custom_text` text DEFAULT NULL,
  `issue_date` date NOT NULL,
  `pdf_path` varchar(255) DEFAULT NULL,
  `preview_image` varchar(255) DEFAULT NULL,
  `status` enum('draft','generated','sent','downloaded') DEFAULT 'generated',
  `generated_at` timestamp NULL DEFAULT NULL,
  `downloaded_at` timestamp NULL DEFAULT NULL,
  `sent_at` timestamp NULL DEFAULT NULL,
  `download_count` int(11) DEFAULT 0,
  `verification_code` varchar(64) NOT NULL,
  `is_public_verifiable` tinyint(1) DEFAULT 1,
  `generated_by` bigint(20) unsigned DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `certificate_number` (`certificate_number`),
  UNIQUE KEY `verification_code` (`verification_code`),
  KEY `template_id` (`template_id`),
  KEY `idx_event` (`event_id`),
  KEY `idx_submission` (`submission_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_project` (`project_id`),
  KEY `idx_verification` (`verification_code`),
  CONSTRAINT `diplomas_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `diplomas_ibfk_2` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `diplomas_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `diplomas_ibfk_4` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `diplomas_ibfk_5` FOREIGN KEY (`template_id`) REFERENCES `diploma_templates` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diplomas`
--

LOCK TABLES `diplomas` WRITE;
/*!40000 ALTER TABLE `diplomas` DISABLE KEYS */;
INSERT INTO `diplomas` (`id`, `certificate_number`, `event_id`, `submission_id`, `user_id`, `project_id`, `template_id`, `diploma_type`, `category_name`, `award_name`, `recipient_name`, `project_title`, `custom_text`, `issue_date`, `pdf_path`, `preview_image`, `status`, `generated_at`, `downloaded_at`, `sent_at`, `download_count`, `verification_code`, `is_public_verifiable`, `generated_by`, `notes`, `created_at`, `updated_at`) VALUES (1,'IBES-2025-00001',77,56,4,38,1,'Finalist','Short Films',NULL,'Antoni Caimari Caldés','Ma Belle',NULL,'2025-11-18','pdfs/ibestff/IBES-2025-00001.pdf',NULL,'sent','2025-11-18 17:37:09','2025-11-30 14:39:04','2025-11-18 18:28:52',4,'LAIjvUypv8AHa2WoXsCw9wB6n8GM7XU2vePz4Lvp8TER032MHTKpme7DreJOlIp8',1,2440,NULL,'2025-11-18 17:37:09','2025-11-30 14:39:04');
/*!40000 ALTER TABLE `diplomas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_categories`
--

DROP TABLE IF EXISTS `event_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_categories`
--

LOCK TABLES `event_categories` WRITE;
/*!40000 ALTER TABLE `event_categories` DISABLE KEYS */;
INSERT INTO `event_categories` (`id`, `name`, `order`, `created_at`, `updated_at`) VALUES (1,'Animation',1,NULL,NULL),(2,'Documentary',2,NULL,NULL),(3,'Experimental',3,NULL,NULL),(4,'Feature',4,NULL,NULL),(5,'Music Video',5,NULL,NULL),(6,'Short',6,NULL,NULL),(7,'Student',7,NULL,NULL),(8,'Television',8,NULL,NULL),(9,'Virtual Reality',9,NULL,NULL),(10,'Web / New Media',10,NULL,NULL),(11,'Performance',11,NULL,NULL),(12,'Installation',12,NULL,NULL),(13,'Game',13,NULL,NULL),(14,'Interactive Film',14,NULL,NULL),(15,'360 Video',15,NULL,NULL),(16,'Augmented Reality',16,NULL,NULL),(17,'Screenplay',17,NULL,NULL),(18,'Short Script',18,NULL,NULL),(19,'Stage Play',19,NULL,NULL),(20,'Television Script',20,NULL,NULL),(21,'Song',21,NULL,NULL),(22,'Film Score',22,NULL,NULL),(23,'Lyrics Only',23,NULL,NULL),(24,'Fiction',24,NULL,NULL),(25,'Music',25,NULL,NULL);
/*!40000 ALTER TABLE `event_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_category_event`
--

DROP TABLE IF EXISTS `event_category_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_category_event` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL,
  `event_category_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `event_category_id` (`event_category_id`),
  CONSTRAINT `event_category_event_ibfk_1` FOREIGN KEY (`event_category_id`) REFERENCES `event_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_category_event`
--

LOCK TABLES `event_category_event` WRITE;
/*!40000 ALTER TABLE `event_category_event` DISABLE KEYS */;
INSERT INTO `event_category_event` (`id`, `event_id`, `event_category_id`, `created_at`, `updated_at`) VALUES (94,77,1,NULL,NULL),(95,77,2,NULL,NULL),(96,77,3,NULL,NULL),(97,77,5,NULL,NULL),(98,77,6,NULL,NULL),(99,77,8,NULL,NULL),(100,77,10,NULL,NULL),(101,77,24,NULL,NULL),(108,13,1,NULL,NULL),(109,13,2,NULL,NULL),(110,13,3,NULL,NULL),(111,13,4,NULL,NULL),(112,13,5,NULL,NULL),(113,13,6,NULL,NULL),(114,13,7,NULL,NULL),(115,13,10,NULL,NULL),(116,13,24,NULL,NULL),(117,13,25,NULL,NULL),(120,13,17,NULL,NULL),(121,13,18,NULL,NULL),(122,13,21,NULL,NULL),(143,83,1,NULL,NULL),(144,84,4,NULL,NULL),(145,84,5,NULL,NULL),(146,84,6,NULL,NULL);
/*!40000 ALTER TABLE `event_category_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_event_type`
--

DROP TABLE IF EXISTS `event_event_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_event_type` (
  `event_id` int(10) unsigned NOT NULL,
  `event_type_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`event_id`,`event_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_event_type`
--

LOCK TABLES `event_event_type` WRITE;
/*!40000 ALTER TABLE `event_event_type` DISABLE KEYS */;
INSERT INTO `event_event_type` (`event_id`, `event_type_id`) VALUES (13,1),(13,2),(13,3),(13,6),(77,1),(77,5),(83,1),(84,5),(84,6);
/*!40000 ALTER TABLE `event_event_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_judge`
--

DROP TABLE IF EXISTS `event_judge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_judge` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_judge`
--

LOCK TABLES `event_judge` WRITE;
/*!40000 ALTER TABLE `event_judge` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_judge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_organizers`
--

DROP TABLE IF EXISTS `event_organizers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_organizers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `event_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_event_organizers_event_id` (`event_id`),
  CONSTRAINT `fk_event_organizers_event_id` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_organizers`
--

LOCK TABLES `event_organizers` WRITE;
/*!40000 ALTER TABLE `event_organizers` DISABLE KEYS */;
INSERT INTO `event_organizers` (`id`, `name`, `title`, `event_id`, `created_at`, `updated_at`) VALUES (27,'Gregorio Evans','Director',77,'2023-07-23 17:54:16','2023-07-23 17:54:16'),(28,'Carlos Mateus','Director',13,'2023-08-09 18:32:30','2023-08-09 18:32:30');
/*!40000 ALTER TABLE `event_organizers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_payouts`
--

DROP TABLE IF EXISTS `event_payouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_payouts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` int(10) unsigned NOT NULL,
  `organizer_id` bigint(20) unsigned NOT NULL,
  `total_sales` decimal(10,2) NOT NULL,
  `platform_commission` decimal(10,2) NOT NULL,
  `payout_amount` decimal(10,2) NOT NULL,
  `commission_percentage` decimal(5,2) NOT NULL,
  `currency` varchar(3) NOT NULL DEFAULT 'EUR',
  `period_start` date NOT NULL,
  `period_end` date NOT NULL,
  `status` enum('pending','processing','paid','failed','cancelled') NOT NULL DEFAULT 'pending',
  `payment_method` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `reference_number` varchar(255) DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `event_payouts_event_id_status_index` (`event_id`,`status`),
  KEY `event_payouts_organizer_id_status_index` (`organizer_id`,`status`),
  KEY `event_payouts_period_start_period_end_index` (`period_start`,`period_end`),
  CONSTRAINT `event_payouts_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `event_payouts_organizer_id_foreign` FOREIGN KEY (`organizer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_payouts`
--

LOCK TABLES `event_payouts` WRITE;
/*!40000 ALTER TABLE `event_payouts` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_payouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_transactions`
--

DROP TABLE IF EXISTS `event_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` int(10) unsigned NOT NULL,
  `submission_id` int(11) DEFAULT NULL,
  `transaction_id` int(10) unsigned NOT NULL,
  `payout_id` bigint(20) unsigned DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `platform_commission` decimal(10,2) NOT NULL,
  `gateway_commission` decimal(10,2) DEFAULT 0.00,
  `organizer_amount` decimal(10,2) NOT NULL,
  `commission_percentage` decimal(5,2) NOT NULL,
  `payment_gateway` varchar(255) NOT NULL,
  `billing_entity` varchar(255) NOT NULL,
  `currency` varchar(3) NOT NULL DEFAULT 'EUR',
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `event_transactions_submission_id_foreign` (`submission_id`),
  KEY `event_transactions_transaction_id_foreign` (`transaction_id`),
  KEY `event_transactions_event_id_transaction_date_index` (`event_id`,`transaction_date`),
  KEY `event_transactions_payment_gateway_billing_entity_index` (`payment_gateway`,`billing_entity`),
  KEY `event_transactions_payout_id_index` (`payout_id`),
  CONSTRAINT `event_transactions_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `event_transactions_payout_id_foreign` FOREIGN KEY (`payout_id`) REFERENCES `event_payouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `event_transactions_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `event_transactions_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_transactions`
--

LOCK TABLES `event_transactions` WRITE;
/*!40000 ALTER TABLE `event_transactions` DISABLE KEYS */;
INSERT INTO `event_transactions` (`id`, `event_id`, `submission_id`, `transaction_id`, `payout_id`, `amount`, `platform_commission`, `gateway_commission`, `organizer_amount`, `commission_percentage`, `payment_gateway`, `billing_entity`, `currency`, `transaction_date`, `created_at`, `updated_at`) VALUES (1,84,79,11,NULL,7.00,0.56,0.29,6.44,8.00,'mollie','eu_company','EUR','2025-12-26 13:28:29','2025-12-26 12:24:37','2025-12-26 12:24:37'),(2,83,NULL,18,NULL,25.00,0.00,0.00,25.00,0.00,'mollie','eu_company','EUR','2025-12-27 17:43:12','2025-12-27 17:43:12','2025-12-27 17:43:12');
/*!40000 ALTER TABLE `event_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_types`
--

DROP TABLE IF EXISTS `event_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_types`
--

LOCK TABLES `event_types` WRITE;
/*!40000 ALTER TABLE `event_types` DISABLE KEYS */;
INSERT INTO `event_types` (`id`, `name`, `icon`, `order`) VALUES (1,'Film Festival','fas fa-film',1),(2,'Screenwriting Contest','fas fa-pen-alt',2),(3,'Music Contest','fas fa-music',3),(4,'Photography Contest','fa-camera',4),(5,'Online Festival / Awards Event','fas fa-globe',5),(6,'Art Contest','fas fa-thermometer-quarter',6),(7,'Other','fas fa-ellipsis-h',7);
/*!40000 ALTER TABLE `event_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(300) NOT NULL,
  `current_season_id` int(10) DEFAULT NULL,
  `seasons_count` int(10) NOT NULL DEFAULT 1,
  `approved` int(1) NOT NULL DEFAULT 0,
  `platform_commission` decimal(5,2) DEFAULT NULL,
  `event_verified_logo` int(1) NOT NULL DEFAULT 0,
  `slug` varchar(255) DEFAULT NULL,
  `subtitle` varchar(250) DEFAULT NULL,
  `logo` text DEFAULT NULL,
  `cover` varchar(500) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `images` text DEFAULT NULL,
  `overview` varchar(255) NOT NULL,
  `event_description` text DEFAULT NULL,
  `years_running` smallint(4) unsigned DEFAULT NULL,
  `audience_attendance` smallint(100) unsigned DEFAULT NULL,
  `estimated_submissions` smallint(100) unsigned DEFAULT NULL,
  `projects_selected` int(11) DEFAULT NULL,
  `price` decimal(15,2) DEFAULT NULL,
  `price_unit` varchar(120) DEFAULT NULL,
  `is_featured` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `country_id` int(10) unsigned DEFAULT NULL,
  `city_id` varchar(200) DEFAULT NULL,
  `period` varchar(30) NOT NULL DEFAULT 'month',
  `user_id` int(11) DEFAULT NULL,
  `user_type` varchar(255) NOT NULL DEFAULT 'App\\Models\\User',
  `category_id` int(10) unsigned DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `auto_renew` tinyint(1) NOT NULL DEFAULT 0,
  `never_expired` tinyint(1) NOT NULL DEFAULT 0,
  `latitude` varchar(25) DEFAULT NULL,
  `longitude` varchar(25) DEFAULT NULL,
  `type_event` varchar(20) DEFAULT NULL,
  `adress_event` varchar(100) DEFAULT NULL,
  `phone_event` varchar(20) DEFAULT NULL,
  `mail_event` varchar(50) DEFAULT NULL,
  `web_event` varchar(50) DEFAULT NULL,
  `facebook_event` varchar(50) DEFAULT NULL,
  `twiter_event` varchar(255) DEFAULT NULL,
  `twitter_event` varchar(50) DEFAULT NULL,
  `instagram_event` varchar(50) DEFAULT NULL,
  `linkedin_event` varchar(50) DEFAULT NULL,
  `imdb_event` varchar(50) DEFAULT NULL,
  `event_sessions` int(10) DEFAULT NULL,
  `awards_presented` int(10) DEFAULT NULL,
  `cash_awards` varchar(10) DEFAULT NULL,
  `awards_prizes` text DEFAULT NULL,
  `rules_terms` text DEFAULT NULL,
  `trailer` varchar(300) DEFAULT NULL,
  `percentage` varchar(20) DEFAULT NULL,
  `dd` text DEFAULT NULL,
  `cd` text DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT 1,
  `is_platform_owned` tinyint(1) NOT NULL DEFAULT 0,
  `tickets_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `tickets_require_approval` tinyint(1) NOT NULL DEFAULT 0,
  `ticket_instructions` text DEFAULT NULL,
  `payment_type` enum('platform_owned','marketplace') NOT NULL DEFAULT 'marketplace',
  `requires_payment_account` tinyint(1) NOT NULL DEFAULT 1,
  `mail_change_status` varchar(255) NOT NULL DEFAULT 'No',
  PRIMARY KEY (`id`),
  KEY `idx_events_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` (`id`, `name`, `current_season_id`, `seasons_count`, `approved`, `platform_commission`, `event_verified_logo`, `slug`, `subtitle`, `logo`, `cover`, `content`, `location`, `images`, `overview`, `event_description`, `years_running`, `audience_attendance`, `estimated_submissions`, `projects_selected`, `price`, `price_unit`, `is_featured`, `created_at`, `updated_at`, `description`, `currency_id`, `country_id`, `city_id`, `period`, `user_id`, `user_type`, `category_id`, `expire_date`, `auto_renew`, `never_expired`, `latitude`, `longitude`, `type_event`, `adress_event`, `phone_event`, `mail_event`, `web_event`, `facebook_event`, `twiter_event`, `twitter_event`, `instagram_event`, `linkedin_event`, `imdb_event`, `event_sessions`, `awards_presented`, `cash_awards`, `awards_prizes`, `rules_terms`, `trailer`, `percentage`, `dd`, `cd`, `status`, `is_platform_owned`, `tickets_enabled`, `tickets_require_approval`, `ticket_instructions`, `payment_type`, `requires_payment_account`, `mail_change_status`) VALUES (13,'FICYM',NULL,2,2,NULL,1,'ficym-mexico','Festival Internacional de Cine y Musica Ecatepec de Morelos.','events/13/guerreomexicofilmfestival-1.jpg',NULL,'<p><strong style=\"background-color:transparent;color:rgb(0,0,0);\">OBJETIVOS</strong></p><p>&nbsp;</p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>El Festival Internacional de Cine y Música de Ecatepec de Morelos (FICYM), tiene por objetivo la difusión y promoción de realizaciones de todo el mundo, potenciando el desarrollo para su comercialización en forma internacional en las distintas plataformas.&nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>Para el cumplimiento de estos objetivos propuestos el festival se realizará entre el 18 y 19 de Agosto de 2023.&nbsp; &nbsp;&nbsp;</span></span></p><p>&nbsp;</p><p><strong style=\"background-color:transparent;color:rgb(0,0,0);\">SECCIÓN DE CONTENIDOS CINE</strong></p><p>&nbsp;</p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>Largometrajes, mediometrajes, cortometrajes, videos musicales, guiones, miniseries de 5 capítulos de duración.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p>&nbsp;</p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>Se admite cualquier género.&nbsp; &nbsp;&nbsp;</span></span></p><p>&nbsp;</p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>Las realizaciones deben contar con subtítulos en español / inglés dependiendo del país del contenido. Se deberá contar con los correspondientes derechos de autor de las obras.&nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>Las versiones se proyectarán en su formato original con su correspondiente subtítulo.&nbsp; &nbsp;&nbsp;</span></span></p><p>&nbsp;</p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>Una vez que su obra sea seleccionada, el festival le solicitará y analizará las copias de proyección de los contenidos y ante alguna anomalía técnica informará de inmediato a los representantes de los contenidos audiovisuales en cualquiera de su formato para solicitar una nueva copia&nbsp; &nbsp;&nbsp;</span></span></p><p>&nbsp;</p><p><strong style=\"background-color:transparent;color:rgb(0,0,0);\">JURADO</strong></p><p>&nbsp;</p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>Los jurados para las distintas categorías estarán formados por los siguientes profesionales altamente calificados para la premiación de cada contenido audiovisual y guion:&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>Tino Cheschitz&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>Bob Isaacs Barria&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>Marco Urueta&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>Max Henriquez&nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>Daniela Torres&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>Gibran Bazán&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>Irene Arcila&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>Norma Gasca Hernández&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>&nbsp; &nbsp; &nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>La dirección del festival no podrá ser jurado, una vez seleccionado los premiados no hay ningún tipo de apelación, los jurados pueden otorgar una premiación especial si lo consideran.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>&nbsp; &nbsp; &nbsp;</span></span></p><p><strong style=\"background-color:transparent;color:rgb(0,0,0);\">RECONOCIMIENTOS Y TROFEOS</strong></p><p>&nbsp;</p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>MEJOR PELÍCULA MEXICANA&nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>MEJOR PELÍCULA EXTRANJERA&nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>MEJOR CORTOMETRAJE MEXICANO&nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>MEJOR CORTOMETRAJE EXTRANJERO&nbsp; &nbsp;&nbsp;</span></span></p><p>&nbsp;</p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>MEJOR PELÍCULA LATINA&nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>MEJOR CORTOMETRAJE LATINO&nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>MEJOR ACTRIZ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>MEJOR ACTOR&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>MEJOR DIRECCIÓN&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>MEJOR FOTOGRAFÍA&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>MEJOR EDICIÓN&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>MEJOR MÚSICA&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>MEJOR DIRECCIÓN DE ARTE&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>MEJOR VESTUARIO&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>MEJOR GUIÓN&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>MEJOR VIDEO MUSICAL&nbsp; &nbsp;&nbsp;</span></span></p><p>MEJOR OBRA COREOGRÁFICA</p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>MEJOR INTERPRETACIÓN MUSICAL&nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>MEJOR INTERPRETACIÓN JUVENIL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>MEJOR INTERPRETACIÓN INFANTIL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>MEJOR PINTURA&nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>MEJOR ESCULTURA&nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>MEJOR FOTOGRAFÍA&nbsp; &nbsp;&nbsp;</span></span></p><p>&nbsp;</p><p>&nbsp;</p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>EL JURADO PODRÁ OTORGAR NUEVAS MENCIONES SI LO CONSIDERA OPORTUNO&nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>TODOS LOS FINALISTAS&nbsp;RECIBIRÁN EL DIPLOMA DEL FESTIVAL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><strong style=\"background-color:transparent;color:rgb(0,0,0);\">INSCRIPCIÓN</strong></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>LA INSCRIPCIÓN PARA PARTICIPAR EN EL FESTIVAL FICYM COMIENZA A PARTIR DEL DÍA 1 DE ABRIL DEL 2023 HASTA EL DIA 31 DE JULIO DEL 2023.&nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>&nbsp; &nbsp; &nbsp;</span></span></p><p><strong style=\"background-color:transparent;color:rgb(0,0,0);\">COSTO</strong></p><p>&nbsp;</p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>Largometrajes 20 EUR&nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"color:rgb(0,0,0);\"><span>Cortometrajes 10 EUR&nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>Series 10 EUR&nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>Guiones 20 EUR&nbsp; &nbsp;&nbsp;</span></span></p><p><span style=\"background-color:transparent;color:rgb(0,0,0);\"><span>Pintura, Escultura, Fotografía 10 EUR&nbsp; &nbsp;&nbsp;</span></span></p><p>&nbsp;</p><p><a style=\"background-color:transparent;color:rgb(17,85,204);\" href=\"https://www.facebook.com/ficymexico/\" rel=\"noreferrer noopener\" target=\"_blank\">https://www.facebook.com/ficymexico/&nbsp;&nbsp;</a></p>','Ecatepec de Morelos (Estado de Mexico)','[\"events\\/13\\/images\\/57U1QVTdzckChdyWh7do5hAYFJkGUlXh0mUvaZGi.jpg\",\"events\\/13\\/images\\/JhLPbpQGO2pR5vb1ggiOMvcD1mKLBYD2HxjIyFY3.jpg\",\"events\\/13\\/images\\/5F4SwYXroXtKkIuBraFoH43P6MwK6sYTnxnZhHWU.jpg\",\"events\\/13\\/images\\/toFWa06BOs8Sjyfq3wWEhGV12iXhP5mIem4GJuJX.png\",\"events\\/13\\/images\\/hL3Cc1cdlllZiYTVIZH0cmlp3JmFEU0ToHzvqiUp.png\",\"events\\/13\\/images\\/84BfbM79wBTIUoz1LduEuwnRTqdepH5AilEckCAn.jpg\",\"events\\/13\\/images\\/WCSRQ63S0DuJPCEkNgvOPxnaFQbrTFWvGnl8VNvo.jpg\",\"events\\/13\\/images\\/fZsq9MdWEEazVRdtHU55VXMhnzURlFWbQtChIzi4.jpg\",\"events\\/13\\/images\\/usbyesln00e9zdXzGpZYHaCt2nTKJ8rLl0pbdxow.jpg\",\"events\\/13\\/images\\/cEDHAf4nA9YyIh9tkHfGOZEqpm1AYdvQJel1kZPw.png\",\"events\\/13\\/images\\/VYfTRW3qnOPo8sUEjI0gL6TQ1iVioEo6tzsAPmLo.png\",\"events\\/13\\/images\\/fkDqCELfz8WJ7c6gzzA5lmH10CVeIdQUCHj7TZv9.png\",\"events\\/13\\/images\\/uK6NwOJYsLU2RBjDQWGTJ3cZHtcasVeO2cJxf3iH.png\",\"events\\/13\\/images\\/OjKzwe7omrILyN9EMgeJCXREfYcr9fcOUElXkJ9Z.png\"]','0','<p><strong style=\"background-color: transparent; color: #000000;\">OBJETIVOS</strong></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">El Festival Internacional de Cine y M&uacute;sica de Ecatepec de Morelos (FICYM), tiene por objetivo la difusi&oacute;n y promoci&oacute;n de realizaciones de todo el mundo, potenciando el desarrollo para su comercializaci&oacute;n en forma internacional en las distintas plataformas.&nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">Para el cumplimiento de estos objetivos propuestos el festival se realizar&aacute; entre el 18 y 19 de Agosto de 2023.&nbsp; &nbsp;&nbsp;</span></p>\r\n<p>&nbsp;</p>\r\n<p><strong style=\"background-color: transparent; color: #000000;\">SECCI&Oacute;N DE CONTENIDOS CINE</strong></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">Largometrajes, mediometrajes, cortometrajes, videos musicales, guiones, miniseries de 5 cap&iacute;tulos de duraci&oacute;n.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">Se admite cualquier g&eacute;nero.&nbsp; &nbsp;&nbsp;</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">Las realizaciones deben contar con subt&iacute;tulos en espa&ntilde;ol / ingl&eacute;s dependiendo del pa&iacute;s del contenido. Se deber&aacute; contar con los correspondientes derechos de autor de las obras.&nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">Las versiones se proyectar&aacute;n en su formato original con su correspondiente subt&iacute;tulo.&nbsp; &nbsp;&nbsp;</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">Una vez que su obra sea seleccionada, el festival le solicitar&aacute; y analizar&aacute; las copias de proyecci&oacute;n de los contenidos y ante alguna anomal&iacute;a t&eacute;cnica informar&aacute; de inmediato a los representantes de los contenidos audiovisuales en cualquiera de su formato para solicitar una nueva copia&nbsp; &nbsp;&nbsp;</span></p>\r\n<p>&nbsp;</p>\r\n<p><strong style=\"background-color: transparent; color: #000000;\">JURADO</strong></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">Los jurados para las distintas categor&iacute;as estar&aacute;n formados por los siguientes profesionales altamente calificados para la premiaci&oacute;n de cada contenido audiovisual y guion:&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">Tino Cheschitz&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">Bob Isaacs Barria&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">Marco Urueta&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">Max Henriquez&nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">Daniela Torres&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">Gibran Baz&aacute;n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">Irene Arcila&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">Norma Gasca Hern&aacute;ndez&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">&nbsp; &nbsp; &nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">La direcci&oacute;n del festival no podr&aacute; ser jurado, una vez seleccionado los premiados no hay ning&uacute;n tipo de apelaci&oacute;n, los jurados pueden otorgar una premiaci&oacute;n especial si lo consideran.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">&nbsp; &nbsp; </span><span style=\"background-color: transparent; color: #000000;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; </span><span style=\"background-color: transparent; color: #000000;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; <br></span></p>\r\n<p><strong style=\"background-color: transparent; color: #000000;\">INSCRIPCI&Oacute;N</strong></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">LA INSCRIPCI&Oacute;N PARA PARTICIPAR EN EL FESTIVAL FICYM COMIENZA A PARTIR DEL D&Iacute;A 1 DE ABRIL DEL 2023 HASTA EL DIA 31 DE JULIO DEL 2023.&nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">&nbsp; &nbsp; &nbsp;</span></p>\r\n<p><strong style=\"background-color: transparent; color: #000000;\">COSTO</strong></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">Largometrajes 20 EUR&nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"color: #000000;\">Cortometrajes 10 EUR&nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">Series 10 EUR&nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">Guiones 20 EUR&nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">Pintura, Escultura, Fotograf&iacute;a 10 EUR&nbsp; &nbsp;&nbsp;</span></p>',2,NULL,NULL,NULL,300.00,NULL,1,'2023-05-26 19:56:52','2025-12-03 01:56:41',NULL,NULL,140,NULL,'month',13,'Botble\\RealEstate\\Models\\Account',0,'2024-06-08',0,0,NULL,NULL,NULL,NULL,NULL,'arcomexfilms@hotmail.com','https://cymlatino.com/','https://www.facebook.com/ficymexico/','',NULL,'https://instagram.com/ficymfestival',NULL,NULL,2,18,'100','<p><strong style=\"background-color: transparent; color: #000000;\">RECONOCIMIENTOS Y TROFEOS</strong></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">MEJOR PEL&Iacute;CULA MEXICANA&nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">MEJOR PEL&Iacute;CULA EXTRANJERA&nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">MEJOR CORTOMETRAJE MEXICANO&nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">MEJOR CORTOMETRAJE EXTRANJERO&nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">MEJOR PEL&Iacute;CULA LATINA&nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">MEJOR CORTOMETRAJE LATINO&nbsp; </span><span style=\"background-color: transparent; color: #000000;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; <br></span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">MEJOR ACTRIZ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">MEJOR ACTOR&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">MEJOR DIRECCI&Oacute;N&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">MEJOR FOTOGRAF&Iacute;A&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">MEJOR EDICI&Oacute;N&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">MEJOR M&Uacute;SICA&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">MEJOR DIRECCI&Oacute;N DE ARTE&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">MEJOR VESTUARIO&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">MEJOR GUI&Oacute;N&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">MEJOR VIDEO MUSICAL&nbsp; &nbsp;&nbsp;</span></p>\r\n<p>MEJOR OBRA COREOGR&Aacute;FICA</p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">MEJOR INTERPRETACI&Oacute;N MUSICAL&nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">MEJOR INTERPRETACI&Oacute;N JUVENIL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">MEJOR INTERPRETACI&Oacute;N INFANTIL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">MEJOR PINTURA&nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">MEJOR ESCULTURA&nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">MEJOR FOTOGRAF&Iacute;A&nbsp; &nbsp;&nbsp;</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">EL JURADO PODR&Aacute; OTORGAR NUEVAS MENCIONES SI LO CONSIDERA OPORTUNO&nbsp; &nbsp;&nbsp;</span></p>\r\n<p><span style=\"background-color: transparent; color: #000000;\">TODOS LOS FINALISTAS RECIBIR&Aacute;N EL DIPLOMA DEL FESTIVAL&nbsp;&nbsp;&nbsp;&nbsp; <br></span></p>\r\n<p>&nbsp;</p>',NULL,'https://www.youtube.com/watch?v=IVLIDM9fBxg',NULL,'[{\"id\":1,\"name\":\"Plazo Unico 2023\",\"unique_id\":\"11682714849975\",\"date\":\"2023-07-20\",\"configuracion\":false,\"categories\":[],\"option\":\"1\",\"bloquear\":true,\"checkedCategoriesTwo\":[{\"id\":1,\"name\":\"Category 1\",\"unique_id\":\"11682714849975\",\"description\":null,\"configuracion\":false,\"precio\":\"20\",\"bloquear\":false,\"deadlines\":[]},{\"id\":2,\"name\":null,\"unique_id\":\"21685012149419\",\"description\":null,\"configuracion\":false,\"precio\":10,\"bloquear\":false,\"deadlines\":[]},{\"id\":3,\"name\":null,\"unique_id\":\"31685012195259\",\"description\":null,\"configuracion\":false,\"precio\":10,\"bloquear\":false,\"deadlines\":[]},{\"id\":4,\"name\":null,\"unique_id\":\"41685012214044\",\"description\":null,\"configuracion\":false,\"precio\":10,\"bloquear\":false,\"deadlines\":[]},{\"id\":5,\"name\":null,\"unique_id\":\"51685012225538\",\"description\":null,\"configuracion\":false,\"precio\":10,\"bloquear\":false,\"deadlines\":[]},{\"id\":6,\"name\":null,\"unique_id\":\"61685012243754\",\"description\":null,\"configuracion\":false,\"precio\":10,\"bloquear\":false,\"deadlines\":[]},{\"id\":7,\"name\":null,\"unique_id\":\"71685012250371\",\"description\":null,\"configuracion\":false,\"precio\":10,\"bloquear\":false,\"deadlines\":[]},{\"id\":8,\"name\":null,\"unique_id\":\"81685012256443\",\"description\":null,\"configuracion\":false,\"precio\":10,\"bloquear\":false,\"deadlines\":[]},{\"id\":9,\"name\":null,\"unique_id\":\"91685012268876\",\"description\":null,\"configuracion\":false,\"precio\":10,\"bloquear\":false,\"deadlines\":[]}],\"cat\":null}]','[{\"id\":1,\"name\":\"Largometrajes Mexicanos\",\"unique_id\":\"11682714849975\",\"description\":null,\"configuracion\":true,\"precio\":10,\"bloquear\":true,\"deadlines\":[]},{\"id\":2,\"name\":\"Cortometrajes Mexicanos\",\"unique_id\":\"21685012149419\",\"description\":null,\"configuracion\":false,\"precio\":10,\"bloquear\":true,\"deadlines\":[]},{\"id\":3,\"name\":\"Series Mexicanas\",\"unique_id\":\"31685012195259\",\"description\":null,\"configuracion\":false,\"precio\":10,\"bloquear\":true,\"deadlines\":[]},{\"id\":4,\"name\":\"Largometrajes Internacionales\",\"unique_id\":\"41685012214044\",\"description\":null,\"configuracion\":true,\"precio\":10,\"bloquear\":true,\"deadlines\":[]},{\"id\":5,\"name\":\"Cortometrajes internacionales\",\"unique_id\":\"51685012225538\",\"description\":null,\"configuracion\":true,\"precio\":10,\"bloquear\":true,\"deadlines\":[]},{\"id\":6,\"name\":\"Series Internacionales\",\"unique_id\":\"61685012243754\",\"description\":null,\"configuracion\":true,\"precio\":10,\"bloquear\":false,\"deadlines\":[]},{\"id\":7,\"name\":\"Music Videos\",\"unique_id\":\"71685012250371\",\"description\":null,\"configuracion\":true,\"precio\":10,\"bloquear\":false,\"deadlines\":[]},{\"id\":8,\"name\":\"Guiones\",\"unique_id\":\"81685012256443\",\"description\":null,\"configuracion\":true,\"precio\":10,\"bloquear\":false,\"deadlines\":[]},{\"id\":9,\"name\":\"Pintura y Escultura\",\"unique_id\":\"91685012268876\",\"description\":null,\"configuracion\":true,\"precio\":10,\"bloquear\":true,\"deadlines\":[]}]',1,0,0,0,NULL,'marketplace',1,'No'),(77,'Ibestff',63,1,2,NULL,0,'ibestff','Indie Best Films Festival','events/77/TUIV242V3fDcM5D27uDzhRFuTPfzoKiSYcjnle7W.png','pJD0BoxVJFDSoYtHMg1tbqWItZArsv6mII3kaHRr.jpg','','Santa Monica','\"[]\"','','<p>Our mission is to help talented film artists, who create meaningful films that are worth seeing and sharing, but lack the backing of studios, expensive marketing campaigns or famous personalities.</p>',2,2000,200,60,NULL,NULL,0,'2023-07-23 17:54:16','2025-11-18 22:40:08','',NULL,1,NULL,'month',2440,'App\\Models\\User',NULL,NULL,0,0,NULL,NULL,'','','','ibestfilmsfestival@ibestff.com','https://ibestff.com/','https://www.facebook.com/ibestff',NULL,'https://twitter.com/Ibestfilmsfesti','https://www.instagram.com/ibestfilmsfestival/',NULL,NULL,NULL,20,NULL,'<p>&ndash; &ldquo;Best Indie Short Film&rdquo; Laurel, and a Certificate</p>\r\n<p>&ndash; &ldquo;Best Video Clip&rdquo; Laurel, and a Certificate</p>\r\n<p>&ndash; &ldquo;Best Ficction Short Film&rdquo; Laurel, and a Certificate</p>\r\n<p>&ndash; &ldquo;Best Animated Short Film&rdquo; Laurel, and a Certificate</p>\r\n<p>&ndash; &ldquo;Best Documentary Short Film&rdquo; Laurel, and a Certificate</p>\r\n<p>&ndash; &ldquo;Best Experimental Short Film&rdquo; Laurel, and a Certificate</p>','<p>&ndash; In this first year we only accept short films and music videos.</p>\r\n<p>&ndash; Fiction films, animation, documentary and experimental of any genre and subject are welcome.</p>\r\n<p>&ndash; The scope of the competition is international. An open competition with works of any country in the world produced from January 1st 2015 onwards.</p>\r\n<p>&ndash; The festival accepts films in any language from around the world.</p>\r\n<p>&ndash; All films in a foreign language (not English) must have subtitles in English.</p>\r\n<p>&ndash; The content must be submitted by a creator/producer aged 18 or older.</p>\r\n<p>&ndash; Multiple projects may be submitted for consideration provided that an additional submission fee is paid for each entry.</p>\r\n<p>&ndash; We are an online competition. Our mission is to recognize the talent of the filmmakers with our laurels and certificates.</p>\r\n<p>&ndash; Every three months, we choose nominees and winners so to give more opportunity to the filmmakers and the movies. 4 seasons per year.</p>\r\n<p>&ndash; At the end of the year we will have a party with a screening of the 4 winning shorts (4 Seasons) that obtain the &ldquo;Best Independent Short Film&rdquo; award and also the 4 winning videos.</p>\r\n<p>&ndash; This festival will be judged by award-winning filmmakers and industry experts.</p>\r\n<p>&ndash; All winners will have laurels and a digital certificate sent to them in jpg file format. No physical certificates, medals, or trophies will be handed out in order to keep entry fees as affordable as possible. &ndash; All submitters must submit their content to Ibestff through our festival registration platforms listed in the Film Submissions section of our website.</p>\r\n<p>&ndash; After a film has been officially selected, the filmmaker will be notified. Official selection does not mean that the filmmaker&rsquo;s film will be screened or awarded at the festival.</p>\r\n<p>&ndash; All submission fees are non-refundable.</p>\r\n<p>&ndash; The submitter must have obtained legal copyright to publicly screen their submitted content and all intellectual property contained therein including, but not limited to, music, lyrics, written work, photos, video content, artwork, and media excerpts.</p>\r\n<p>&ndash; By submitting your content, you represent that you have acquired all legal rights to publicly screen all content within your submission.</p>\r\n<p>&ndash; The festival is not responsible for any copyright infringement of the filmmaker&rsquo;s material. OFFICIAL SELECTION</p>\r\n<p>&ndash; If your film has been officially selected, you agree to provide us with a poster or promotional images and/or stills, as well as a logline and/or synopsis, for promotional purposes.</p>\r\n<p>&ndash; If your film has been officially selected, you agree that we are permitted to use excerpts from the film, up to a maximum of 30 seconds, worldwide, for promotional purposes.</p>\r\n<p>&ndash; If a submitter&rsquo;s content is selected, a Notice of Official Selection shall be emailed to the to the email address provided by the submitter in their registration form on the notification date.</p>\r\n<p>&ndash; Announcements identifying the Official Selections will be posted online on the Ibestff website and social media channels. &ndash; We do not return any materials submitted.</p>',NULL,NULL,NULL,NULL,1,0,1,0,NULL,'marketplace',1,'Yes'),(83,'Test',69,1,1,NULL,0,'test','Festival Test',NULL,NULL,'','Misuri','\"\"','','<p>Desripcion 1</p>',1,NULL,NULL,NULL,NULL,NULL,0,'2025-11-30 04:46:51','2025-12-26 16:42:11',NULL,NULL,1,NULL,'month',1,'App\\Models\\User',NULL,NULL,0,0,NULL,NULL,'','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,NULL,'platform_owned',0,'No'),(84,'Evento Test 2',70,1,0,NULL,0,'test2','Pruebas de envio',NULL,'events/84/a74ab198-78dc-4531-9ec1-ea00a1083eb7.jpg','',NULL,'\"\"','','<p>Una vez que hayas terminado la configuraci&oacute;n y est&eacute;s listo para que el evento sea visible en el directorio, puedes solicitar que se publique p&uacute;blicamente. Nuestro equipo de administradores revisar&aacute; la solicitud y, si todo est&aacute; en orden, aprobar&aacute;n que el evento aparezca en el directorio p&uacute;blico. Hasta que se apruebe la solicitud, el evento seguir&aacute; siendo accesible a trav&eacute;s de su slug (URL personalizada), lo que te permite seguir trabajando sin interrupciones.</p>',1,NULL,NULL,NULL,NULL,NULL,0,'2025-12-24 14:18:05','2025-12-26 10:35:19','',NULL,1,NULL,'month',1,'App\\Models\\User',NULL,NULL,0,0,NULL,NULL,'','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,NULL,'marketplace',1,'No');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flag_project`
--

DROP TABLE IF EXISTS `flag_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `flag_project` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `flag_id` int(10) DEFAULT NULL,
  `project_id` int(10) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `flag_id` (`flag_id`),
  KEY `project_id` (`project_id`),
  CONSTRAINT `flag_project_ibfk_1` FOREIGN KEY (`flag_id`) REFERENCES `flags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flag_project`
--

LOCK TABLES `flag_project` WRITE;
/*!40000 ALTER TABLE `flag_project` DISABLE KEYS */;
INSERT INTO `flag_project` (`id`, `flag_id`, `project_id`, `created_at`, `updated_at`) VALUES (21,79,38,'2025-12-26 17:50:43','2025-12-26 17:50:43'),(22,78,38,'2025-12-26 17:52:45','2025-12-26 17:52:45');
/*!40000 ALTER TABLE `flag_project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flags`
--

DROP TABLE IF EXISTS `flags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `flags` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `event_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  CONSTRAINT `flags_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flags`
--

LOCK TABLES `flags` WRITE;
/*!40000 ALTER TABLE `flags` DISABLE KEYS */;
INSERT INTO `flags` (`id`, `name`, `color`, `event_id`, `created_at`, `updated_at`) VALUES (6,'fas fa-flag','#fc6265',77,'2023-08-09 13:11:26','2023-08-09 15:12:49'),(7,'fas fa-flag','#ebcf34',77,'2023-08-09 13:11:26','2023-08-09 15:12:53'),(8,'fas fa-flag','#acd927',77,'2023-08-09 13:11:26','2023-08-09 15:12:59'),(9,'fas fa-flag','#65bbfc',77,'2023-08-09 13:11:26','2023-08-09 15:13:04'),(10,'fas fa-flag','#d481f7',77,'2023-08-09 13:11:26','2023-08-09 15:13:08'),(11,'fas fa-flag','#c8c8c8',77,'2023-08-09 13:11:26','2023-08-09 15:13:12'),(12,'fas fa-flag','#ea148c',77,'2023-08-09 13:11:26','2023-08-09 15:13:16'),(13,'fas fa-flag','#fcb32b',77,'2023-08-09 13:11:26','2023-08-09 15:13:20'),(14,'fas fa-flag','#000000',77,'2023-08-09 13:11:26','2023-08-09 15:13:23'),(15,'fas fa-flag','#ff0000',77,'2023-08-09 13:11:26','2023-08-09 15:13:32'),(17,'fas fa-flag','#fc6265',13,'2023-08-09 13:11:26','2023-08-09 15:12:49'),(18,'fas fa-flag','#ebcf34',13,'2023-08-09 13:11:26','2023-08-09 15:12:53'),(19,'fas fa-flag','#acd927',13,'2023-08-09 13:11:26','2023-08-09 15:12:59'),(20,'fas fa-flag','#65bbfc',13,'2023-08-09 13:11:26','2023-08-09 15:13:04'),(21,'fas fa-flag','#d481f7',13,'2023-08-09 13:11:26','2023-08-09 15:13:08'),(22,'fas fa-flag','#c8c8c8',13,'2023-08-09 13:11:26','2023-08-09 15:13:12'),(23,'fas fa-flag','#ea148c',13,'2023-08-09 13:11:26','2023-08-09 15:13:16'),(24,'fas fa-flag','#fcb32b',13,'2023-08-09 13:11:26','2023-08-09 15:13:20'),(25,'fas fa-flag','#000000',13,'2023-08-09 13:11:26','2023-08-09 15:13:23'),(26,'fas fa-flag','#ff0000',13,'2023-08-09 13:11:26','2023-08-09 15:13:32'),(77,'fas fa-flag','#fc6265',83,'2025-11-30 04:46:51','2025-11-30 04:46:51'),(78,'fas fa-flag','#ebcf34',83,'2025-11-30 04:46:51','2025-11-30 04:46:51'),(79,'fas fa-flag','#acd927',83,'2025-11-30 04:46:51','2025-11-30 04:46:51'),(80,'fas fa-flag','#65bbfc',83,'2025-11-30 04:46:51','2025-11-30 04:46:51'),(81,'fas fa-flag','#d481f7',83,'2025-11-30 04:46:51','2025-11-30 04:46:51'),(82,'fas fa-flag','#c8c8c8',83,'2025-11-30 04:46:51','2025-11-30 04:46:51'),(83,'fas fa-flag','#ea148c',83,'2025-11-30 04:46:51','2025-11-30 04:46:51'),(84,'fas fa-flag','#fcb32b',83,'2025-11-30 04:46:51','2025-11-30 04:46:51'),(85,'fas fa-flag','#000000',83,'2025-11-30 04:46:51','2025-11-30 04:46:51'),(86,'fas fa-flag','#ff0000',83,'2025-11-30 04:46:51','2025-11-30 04:46:51'),(87,'fas fa-flag','#fc6265',84,'2025-12-24 14:18:07','2025-12-24 14:18:07'),(88,'fas fa-flag','#ebcf34',84,'2025-12-24 14:18:07','2025-12-24 14:18:07'),(89,'fas fa-flag','#acd927',84,'2025-12-24 14:18:07','2025-12-24 14:18:07'),(90,'fas fa-flag','#65bbfc',84,'2025-12-24 14:18:07','2025-12-24 14:18:07'),(91,'fas fa-flag','#d481f7',84,'2025-12-24 14:18:07','2025-12-24 14:18:07'),(92,'fas fa-flag','#c8c8c8',84,'2025-12-24 14:18:07','2025-12-24 14:18:07'),(93,'fas fa-flag','#ea148c',84,'2025-12-24 14:18:07','2025-12-24 14:18:07'),(94,'fas fa-flag','#fcb32b',84,'2025-12-24 14:18:07','2025-12-24 14:18:07'),(95,'fas fa-flag','#000000',84,'2025-12-24 14:18:07','2025-12-24 14:18:07'),(96,'fas fa-flag','#ff0000',84,'2025-12-24 14:18:07','2025-12-24 14:18:07');
/*!40000 ALTER TABLE `flags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ip_blocks`
--

DROP TABLE IF EXISTS `ip_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ip_blocks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(255) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `failed_attempts` int(11) NOT NULL DEFAULT 0,
  `blocked_until` timestamp NULL DEFAULT NULL,
  `permanent` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ip_blocks_ip_address_index` (`ip_address`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip_blocks`
--

LOCK TABLES `ip_blocks` WRITE;
/*!40000 ALTER TABLE `ip_blocks` DISABLE KEYS */;
INSERT INTO `ip_blocks` (`id`, `ip_address`, `reason`, `failed_attempts`, `blocked_until`, `permanent`, `created_at`, `updated_at`) VALUES (1,'141.101.76.95','Honeypot triggered',1,NULL,0,'2025-12-06 21:25:53','2025-12-06 21:25:53'),(2,'172.71.95.66','Honeypot triggered',1,NULL,0,'2025-12-13 00:36:56','2025-12-13 00:36:57'),(3,'162.159.113.88','Honeypot triggered',1,NULL,0,'2025-12-13 09:27:10','2025-12-13 09:27:10'),(4,'172.71.103.226','Honeypot triggered',1,NULL,0,'2025-12-13 09:27:11','2025-12-13 09:27:11'),(5,'172.71.99.147','Honeypot triggered',1,NULL,0,'2025-12-16 19:09:34','2025-12-16 19:09:34'),(6,'172.69.234.162','Rate limit exceeded on login',2,NULL,0,'2025-12-16 19:09:43','2026-02-18 14:08:57'),(8,'104.23.199.20','Honeypot triggered',1,NULL,0,'2025-12-25 05:40:05','2025-12-25 05:40:05'),(9,'104.23.170.71','Honeypot triggered',1,NULL,0,'2026-01-02 11:45:44','2026-01-02 11:45:44'),(10,'162.158.87.92','Honeypot triggered',1,NULL,0,'2026-01-09 17:22:26','2026-01-09 17:22:26'),(11,'104.23.253.22','Form submitted too quickly',1,NULL,0,'2026-02-03 14:38:13','2026-02-03 14:38:13'),(12,'104.23.199.228','Honeypot triggered',1,NULL,0,'2026-02-09 10:20:11','2026-02-09 10:20:11'),(13,'172.69.234.163','Rate limit exceeded on login',2,NULL,0,'2026-03-16 14:17:26','2026-03-16 14:18:15');
/*!40000 ALTER TABLE `ip_blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `judges`
--

DROP TABLE IF EXISTS `judges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `judges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(10) DEFAULT NULL,
  `judge_id` bigint(20) DEFAULT NULL,
  `submission_id` int(10) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_event_id` (`event_id`),
  KEY `fk_judge_id` (`judge_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `judges`
--

LOCK TABLES `judges` WRITE;
/*!40000 ALTER TABLE `judges` DISABLE KEYS */;
/*!40000 ALTER TABLE `judges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `key_casts`
--

DROP TABLE IF EXISTS `key_casts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `key_casts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `character_name` varchar(255) DEFAULT NULL,
  `prior_credits` text DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `key_casts`
--

LOCK TABLES `key_casts` WRITE;
/*!40000 ALTER TABLE `key_casts` DISABLE KEYS */;
INSERT INTO `key_casts` (`id`, `first_name`, `middle_name`, `last_name`, `character_name`, `prior_credits`, `project_id`, `created_at`, `updated_at`) VALUES (4,'Macarena','https://www.imdb.com/name/nm1296762/','Gomez','Michelle',NULL,38,'2023-07-22 08:33:48','2023-07-22 10:17:02'),(7,'Bruno',NULL,'Lastra','Esteban',NULL,38,'2023-07-22 08:42:42','2023-07-22 08:42:53');
/*!40000 ALTER TABLE `key_casts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `languages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `abbreviation` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` (`id`, `name`, `abbreviation`) VALUES (1,'English','en'),(2,'Español','es');
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `laurel_settings`
--

DROP TABLE IF EXISTS `laurel_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `laurel_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` int(10) unsigned NOT NULL,
  `access_token` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `require_password` tinyint(1) NOT NULL DEFAULT 0,
  `is_public` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `laurel_settings_event_id_unique` (`event_id`),
  UNIQUE KEY `laurel_settings_access_token_unique` (`access_token`),
  CONSTRAINT `laurel_settings_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `laurel_settings`
--

LOCK TABLES `laurel_settings` WRITE;
/*!40000 ALTER TABLE `laurel_settings` DISABLE KEYS */;
INSERT INTO `laurel_settings` (`id`, `event_id`, `access_token`, `password`, `require_password`, `is_public`, `created_at`, `updated_at`) VALUES (1,77,'JVdEmwhJMaMTfqrNXQ7VE6d3cUzXAXLZ',NULL,0,1,'2025-11-18 23:47:55','2025-11-18 23:47:55'),(4,83,'WelenHMG38NkJSgftJf1XR9u9wuojCDs',NULL,0,1,'2025-11-30 05:39:51','2025-11-30 05:39:51'),(5,84,'YCsHcqeRMS0hs1cQP2sjza3Ii7yWTF4J',NULL,0,1,'2025-12-26 15:09:35','2025-12-26 15:09:35');
/*!40000 ALTER TABLE `laurel_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `laurels`
--

DROP TABLE IF EXISTS `laurels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `laurels` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `line_1` varchar(255) NOT NULL DEFAULT 'OFFICIAL SELECTION',
  `line_2` varchar(255) NOT NULL,
  `line_3` varchar(255) DEFAULT NULL,
  `line_1_font` varchar(255) NOT NULL DEFAULT 'cinzel-bold',
  `line_1_x` int(11) NOT NULL DEFAULT 400,
  `line_1_y` int(11) NOT NULL DEFAULT 280,
  `line_1_size` int(11) NOT NULL DEFAULT 36,
  `line_2_font` varchar(255) NOT NULL DEFAULT 'cinzel-regular',
  `line_2_x` int(11) NOT NULL DEFAULT 400,
  `line_2_y` int(11) NOT NULL DEFAULT 400,
  `line_2_size` int(11) NOT NULL DEFAULT 28,
  `line_3_font` varchar(255) NOT NULL DEFAULT 'cinzel-bold',
  `line_3_x` int(11) NOT NULL DEFAULT 400,
  `line_3_y` int(11) NOT NULL DEFAULT 520,
  `line_3_size` int(11) NOT NULL DEFAULT 32,
  `template_style` enum('classic_circle','classic_wreath','modern_minimal','elegant_leaves','film_reel','star_badge') NOT NULL DEFAULT 'classic_wreath',
  `color_style` enum('black_on_white','white_on_black','gold_on_black') NOT NULL DEFAULT 'black_on_white',
  `image_path` varchar(255) DEFAULT NULL,
  `custom_image_path` varchar(255) DEFAULT NULL,
  `is_custom_image` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `laurels_event_id_is_active_index` (`event_id`,`is_active`),
  CONSTRAINT `laurels_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `laurels`
--

LOCK TABLES `laurels` WRITE;
/*!40000 ALTER TABLE `laurels` DISABLE KEYS */;
/*!40000 ALTER TABLE `laurels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `likes`
--

DROP TABLE IF EXISTS `likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `likes` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `review_id` int(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `review_id` (`review_id`),
  CONSTRAINT `likes_ibfk_1` FOREIGN KEY (`review_id`) REFERENCES `reviews` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `likes`
--

LOCK TABLES `likes` WRITE;
/*!40000 ALTER TABLE `likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2025_11_16_105215_add_avatar_to_admins_table',2),(6,'2025_01_17_000001_add_status_to_seasons_table',3),(7,'2025_01_17_000002_add_date_preferences_to_users_table',4),(8,'2025_01_17_000003_add_locale_to_users_table',5),(9,'2025_11_18_add_payment_status_to_submissions',6),(10,'2025_11_18_create_payment_system_tables',7),(11,'2025_11_18_create_support_tickets_table',8),(12,'2025_11_18_create_tickets_system_tables',9),(14,'2025_11_19_000001_add_ticket_instructions_to_events',10),(15,'2025_11_19_000002_create_ticket_coupons_table',11),(16,'2025_11_19_000003_create_laurels_table',12),(17,'2025_11_19_000004_add_custom_image_and_positions_to_laurels',13),(20,'2025_11_19_000005_create_notification_settings_table',14),(21,'2025_11_19_000006_create_notification_templates_table',14),(22,'2025_11_18_173900_create_diploma_templates_table',12),(23,'2025_11_18_173901_create_diplomas_table',12),(24,'2025_11_18_173902_create_diploma_logs_table',12),(25,'2025_11_19_000007_create_notification_logs_table',13),(26,'2025_11_19_000010_create_custom_form_fields_table',13),(27,'2025_11_19_000011_create_custom_form_responses_table',13),(28,'2025_11_19_000009_create_submission_confirmation_messages_table',13),(29,'2025_11_19_000008_add_notification_fields_to_submissions',15),(30,'2025_11_19_193515_add_season_id_to_categories_table',14),(31,'2025_11_19_193522_add_soft_deletes_to_deadlines_and_categories',16),(32,'2025_11_19_193616_migrate_existing_categories_season_data',16),(33,'2025_11_29_000001_create_security_settings_table',17),(34,'2025_11_30_005128_add_celebration_end_date_to_seasons_table',18),(35,'2025_11_30_170408_add_billing_fields_to_users_table',19),(37,'2025_11_30_120000_add_factubase_settings',20),(38,'2025_11_30_120001_add_factubase_fields_to_transactions_table',20),(40,'2025_12_01_031046_add_provider_column_to_transactions_table',21),(41,'2025_12_01_224901_add_email_notifications_enabled_to_notification_settings_table',22),(42,'2025_12_02_161927_modify_unit_price_precision_in_transactions_table',23),(43,'2025_12_03_133136_create_translations_table',24),(44,'2025_12_04_001843_add_order_to_categories_and_event_tables',25),(47,'2025_12_05_164731_add_platform_commission_to_events_table',26),(48,'2025_12_05_164742_create_event_transactions_table',26),(49,'2025_12_05_164748_create_event_payouts_table',26),(50,'2025_12_05_195744_add_payout_id_to_event_transactions_table',27);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_logs`
--

DROP TABLE IF EXISTS `notification_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` int(10) unsigned NOT NULL,
  `submission_id` int(11) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `judging_status` varchar(255) NOT NULL,
  `email_subject` varchar(255) NOT NULL,
  `email_body` text NOT NULL,
  `status` enum('sent','failed','pending') NOT NULL DEFAULT 'sent',
  `error_message` text DEFAULT NULL,
  `sent_by` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notification_logs_event_id_judging_status_index` (`event_id`,`judging_status`),
  KEY `notification_logs_submission_id_index` (`submission_id`),
  KEY `notification_logs_user_id_index` (`user_id`),
  CONSTRAINT `notification_logs_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `notification_logs_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `notification_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_logs`
--

LOCK TABLES `notification_logs` WRITE;
/*!40000 ALTER TABLE `notification_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_settings`
--

DROP TABLE IF EXISTS `notification_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` int(10) unsigned NOT NULL,
  `notification_mode` enum('on_date','immediate') NOT NULL DEFAULT 'on_date',
  `notification_date` date DEFAULT NULL,
  `auto_notifications_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `email_notifications_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notification_settings_event_id_unique` (`event_id`),
  CONSTRAINT `notification_settings_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_settings`
--

LOCK TABLES `notification_settings` WRITE;
/*!40000 ALTER TABLE `notification_settings` DISABLE KEYS */;
INSERT INTO `notification_settings` (`id`, `event_id`, `notification_mode`, `notification_date`, `auto_notifications_enabled`, `email_notifications_enabled`, `created_at`, `updated_at`) VALUES (1,77,'on_date','2026-02-19',1,1,'2025-11-19 01:06:48','2025-11-19 01:06:48'),(3,83,'on_date','2026-03-02',1,1,'2025-11-30 05:40:49','2025-11-30 05:40:49'),(4,84,'on_date','2026-03-26',1,1,'2025-12-26 10:42:43','2025-12-26 10:42:43');
/*!40000 ALTER TABLE `notification_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_templates`
--

DROP TABLE IF EXISTS `notification_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_templates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` int(10) unsigned NOT NULL,
  `judging_status` varchar(255) NOT NULL,
  `template_type` enum('default','custom') NOT NULL DEFAULT 'default',
  `email_subject` varchar(255) DEFAULT NULL,
  `custom_message` text DEFAULT NULL,
  `last_modified` timestamp NULL DEFAULT NULL,
  `last_sent_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notification_templates_event_id_judging_status_unique` (`event_id`,`judging_status`),
  CONSTRAINT `notification_templates_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_templates`
--

LOCK TABLES `notification_templates` WRITE;
/*!40000 ALTER TABLE `notification_templates` DISABLE KEYS */;
INSERT INTO `notification_templates` (`id`, `event_id`, `judging_status`, `template_type`, `email_subject`, `custom_message`, `last_modified`, `last_sent_at`, `created_at`, `updated_at`) VALUES (1,77,'Selected','default','[Project Title] - Selected for',NULL,'2025-11-20 01:36:50',NULL,'2025-11-19 01:06:48','2025-11-20 01:36:50'),(2,77,'Not Selected','default','[Project Title] -  Update',NULL,NULL,NULL,'2025-11-19 01:06:48','2025-11-19 01:06:48'),(3,77,'Award Winner','default','🏆 [Project Title] - Award Winner at !',NULL,NULL,NULL,'2025-11-19 01:06:48','2025-11-19 01:06:48'),(4,77,'Finalist','default','🎉 [Project Title] - Finalist at !',NULL,NULL,NULL,'2025-11-19 01:06:48','2025-11-19 01:06:48'),(5,77,'Semi-Finalist','default','[Project Title] - Semi-Finalist at !',NULL,NULL,NULL,'2025-11-19 01:06:48','2025-11-19 01:06:48'),(6,77,'Quarter-Finalist','default','[Project Title] - Quarter-Finalist at !',NULL,NULL,NULL,'2025-11-19 01:06:48','2025-11-19 01:06:48'),(7,77,'Nominee','default','[Project Title] - Nominated at !',NULL,NULL,NULL,'2025-11-19 01:06:48','2025-11-19 01:06:48'),(8,77,'Honorable Mention','default','[Project Title] - Honorable Mention at !',NULL,NULL,NULL,'2025-11-19 01:06:48','2025-11-19 01:06:48'),(17,83,'Selected','default','[Project Title] - Selected for ',NULL,NULL,NULL,'2025-11-30 05:40:49','2025-11-30 05:40:49'),(18,83,'Not Selected','default','[Project Title] -  Update',NULL,NULL,NULL,'2025-11-30 05:40:49','2025-11-30 05:40:49'),(19,83,'Award Winner','default','🏆 [Project Title] - Award Winner at !',NULL,NULL,NULL,'2025-11-30 05:40:49','2025-11-30 05:40:49'),(20,83,'Finalist','default','🎉 [Project Title] - Finalist at !',NULL,NULL,NULL,'2025-11-30 05:40:49','2025-11-30 05:40:49'),(21,83,'Semi-Finalist','default','[Project Title] - Semi-Finalist at !',NULL,NULL,NULL,'2025-11-30 05:40:49','2025-11-30 05:40:49'),(22,83,'Quarter-Finalist','default','[Project Title] - Quarter-Finalist at !',NULL,NULL,NULL,'2025-11-30 05:40:49','2025-11-30 05:40:49'),(23,83,'Nominee','default','[Project Title] - Nominated at !',NULL,NULL,NULL,'2025-11-30 05:40:49','2025-11-30 05:40:49'),(24,83,'Honorable Mention','default','[Project Title] - Honorable Mention at !',NULL,NULL,NULL,'2025-11-30 05:40:49','2025-11-30 05:40:49'),(25,84,'Selected','default','[Project Title] - Selected for ',NULL,NULL,NULL,'2025-12-26 10:42:43','2025-12-26 10:42:43'),(26,84,'Not Selected','default','[Project Title] -  Update',NULL,NULL,NULL,'2025-12-26 10:42:43','2025-12-26 10:42:43'),(27,84,'Award Winner','default','🏆 [Project Title] - Award Winner at !',NULL,NULL,NULL,'2025-12-26 10:42:43','2025-12-26 10:42:43'),(28,84,'Finalist','default','🎉 [Project Title] - Finalist at !',NULL,NULL,NULL,'2025-12-26 10:42:43','2025-12-26 10:42:43'),(29,84,'Semi-Finalist','default','[Project Title] - Semi-Finalist at !',NULL,NULL,NULL,'2025-12-26 10:42:43','2025-12-26 10:42:43'),(30,84,'Quarter-Finalist','default','[Project Title] - Quarter-Finalist at !',NULL,NULL,NULL,'2025-12-26 10:42:43','2025-12-26 10:42:43'),(31,84,'Nominee','default','[Project Title] - Nominated at !',NULL,NULL,NULL,'2025-12-26 10:42:43','2025-12-26 10:42:43'),(32,84,'Honorable Mention','default','[Project Title] - Honorable Mention at !',NULL,NULL,NULL,'2025-12-26 10:42:43','2025-12-26 10:42:43');
/*!40000 ALTER TABLE `notification_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('page') NOT NULL DEFAULT 'page',
  `title` varchar(150) NOT NULL,
  `content` mediumtext DEFAULT NULL,
  `slug` varchar(100) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `lang` char(10) NOT NULL DEFAULT 'en',
  `access` varchar(50) NOT NULL DEFAULT 'all',
  `status` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` (`id`, `type`, `title`, `content`, `slug`, `image`, `description`, `keywords`, `lang`, `access`, `status`, `created_at`, `updated_at`) VALUES (2,'page','Terms of Service','<p><strong>Terms &amp; Conditions</strong><br />\r\n<br />\r\nUpdated at 2021-09-24<br />\r\n<br />\r\n<br />\r\n<strong>General Terms</strong><br />\r\n<br />\r\nBy accessing and placing an order with Festgate, you confirm that you are in agreement with and bound by the terms of service contained in the Terms &amp; Conditions outlined below. These terms apply to the entire website and any email or other type of communication between you and Festgate.<br />\r\n<br />\r\nUnder no circumstances shall Festgate team be liable for any direct, indirect, special, incidental or consequential damages, including, but not limited to, loss of data or profit, arising out of the use, or the inability to use, the materials on this site, even if Festgate team or an authorized representative has been advised of the possibility of such damages. If your use of materials from this site results in the need for servicing, repair or correction of equipment or data, you assume any costs thereof.<br />\r\n<br />\r\nFestgate will not be responsible for any outcome that may occur during the course of usage of our resources. We reserve the rights to change prices and revise the resources usage policy in any moment.<br />\r\n<br />\r\n<br />\r\n<strong>License</strong><br />\r\n<br />\r\nFestgate grants you a revocable, non-exclusive, non-transferable, limited license to download, install and use the website strictly in accordance with the terms of this Agreement.<br />\r\n<br />\r\nThese Terms &amp; Conditions are a contract between you and Festgate (referred to in these Terms &amp; Conditions as &quot;Festgate&quot;, &quot;us&quot;, &quot;we&quot; or &quot;our&quot;), the provider of the Festgate website and the services accessible from the Festgate website (which are collectively referred to in these Terms &amp; Conditions as the &quot;Festgate Service&quot;).<br />\r\n<br />\r\nYou are agreeing to be bound by these Terms &amp; Conditions. If you do not agree to these Terms &amp; Conditions, please do not use the Festgate Service. In these Terms &amp; Conditions, &quot;you&quot; refers both to you as an individual and to the entity you represent. If you violate any of these Terms &amp; Conditions, we reserve the right to cancel your account or block access to your account without notice.<br />\r\n<br />\r\n<br />\r\n<br />\r\n<strong>Definitions and key terms</strong><br />\r\n<br />\r\nTo help explain things as clearly as possible in this Terms &amp; Conditions, every time any of these terms are referenced, are strictly defined as:</p>\r\n\r\n<p><br />\r\n<strong>Restrictions</strong><br />\r\n<br />\r\nYou agree not to, and you will not permit others to:</p>\r\n\r\n<p><br />\r\n<strong>Return and Refund Policy</strong><br />\r\n<br />\r\nThanks for shopping at Festgate. We appreciate the fact that you like to buy the stuff we build. We also want to make sure you have a rewarding experience while you&rsquo;re exploring, evaluating, and purchasing our products.<br />\r\n<br />\r\nAs with any shopping experience, there are terms and conditions that apply to transactions at Festgate. We&rsquo;ll be as brief as our attorneys will allow. The main thing to remember is that by placing an order or making a purchase at Festgate, you agree to the terms along with Festgate&#39;s&nbsp;Privacy Policy.<br />\r\n<br />\r\nIf, for any reason, You are not completely satisfied with any good or service that we provide, don&#39;t hesitate to contact us and we will discuss any of the issues you are going through with our product.<br />\r\n<br />\r\n<br />\r\n<strong>Your Suggestions</strong><br />\r\n<br />\r\nAny feedback, comments, ideas, improvements or suggestions (collectively, &quot;Suggestions&quot;) provided by you to Festgate with respect to the website shall remain the sole and exclusive property of Festgate.<br />\r\n<br />\r\nFestgate shall be free to use, copy, modify, publish, or redistribute the Suggestions for any purpose and in any way without any credit or any compensation to you.<br />\r\n<br />\r\n<br />\r\n<strong>Your Consent</strong><br />\r\n<br />\r\nWe&#39;ve updated our&nbsp;Terms &amp; Conditions&nbsp;to provide you with complete transparency into what is being set when you visit our site and how it&#39;s being used. By using our website, registering an account, or making a purchase, you hereby consent to our Terms &amp; Conditions.<br />\r\n<br />\r\n<br />\r\n<strong>Links to Other Websites</strong><br />\r\n<br />\r\nThis Terms &amp; Conditions applies only to the Services. The Services may contain links to other websites not operated or controlled by Festgate. We are not responsible for the content, accuracy or opinions expressed in such websites, and such websites are not investigated, monitored or checked for accuracy or completeness by us. Please remember that when you use a link to go from the Services to another website, our Terms &amp; Conditions are no longer in effect. Your browsing and interaction on any other website, including those that have a link on our platform, is subject to that website&rsquo;s own rules and policies. Such third parties may use their own cookies or other methods to collect information about you.<br />\r\n<br />\r\n<br />\r\n<strong>Cookies</strong><br />\r\n<br />\r\nFestgate uses &quot;Cookies&quot; to identify the areas of our website that you have visited. A Cookie is a small piece of data stored on your computer or mobile device by your web browser. We use Cookies to enhance the performance and functionality of our website but are non-essential to their use. However, without these cookies, certain functionality like videos may become unavailable or you would be required to enter your login details every time you visit the website as we would not be able to remember that you had logged in previously. Most web browsers can be set to disable the use of Cookies. However, if you disable Cookies, you may not be able to access functionality on our website correctly or at all. We never place Personally Identifiable Information in Cookies.<br />\r\n<br />\r\nMore about our cookie policy: <a href=\"https://festgate.com/pg/cookies\">https://festgate.com/pg/cookies</a><br />\r\n<br />\r\n<br />\r\n<strong>Changes To Our Terms &amp; Conditions</strong><br />\r\n<br />\r\nYou acknowledge and agree that&nbsp;may stop (permanently or temporarily) providing the Service (or any features within the Service) to you or to users generally at&nbsp;&rsquo;s sole discretion, without prior notice to you. You may stop using the Service at any time. You do not need to specifically inform&nbsp;when you stop using the Service. You acknowledge and agree that if&nbsp;disables access to your account, you may be prevented from accessing the Service, your account details or any files or other materials which is contained in your account.<br />\r\n<br />\r\nIf we decide to change our Terms &amp; Conditions, we will post those changes on this page, and/or update the Terms &amp; Conditions modification date below.<br />\r\n<br />\r\n<br />\r\n<strong>Modifications to Our website</strong><br />\r\n<br />\r\nFestgate reserves the right to modify, suspend or discontinue, temporarily or permanently, the website or any service to which it connects, with or without notice and without liability to you.<br />\r\n<br />\r\n<br />\r\n<strong>Updates to Our website</strong><br />\r\n<br />\r\nFestgate may from time to time provide enhancements or improvements to the features/ functionality of the website, which may include patches, bug fixes, updates, upgrades and other modifications (&quot;Updates&quot;).<br />\r\n<br />\r\nUpdates may modify or delete certain features and/or functionalities of the website. You agree that Festgate has no obligation to (i) provide any Updates, or (ii) continue to provide or enable any particular features and/or functionalities of the website to you.<br />\r\n<br />\r\nYou further agree that all Updates will be (i) deemed to constitute an integral part of the website, and (ii) subject to the terms and conditions of this Agreement.<br />\r\n<br />\r\n<br />\r\n<strong>Third-Party Services</strong><br />\r\n<br />\r\nWe may display, include or make available third-party content (including data, information, applications and other products services) or provide links to third-party websites or services (&quot;Third- Party Services&quot;).<br />\r\n<br />\r\nYou acknowledge and agree that Festgate shall not be responsible for any Third-Party Services, including their accuracy, completeness, timeliness, validity, copyright compliance, legality, decency, quality or any other aspect thereof. Festgate does not assume and shall not have any liability or responsibility to you or any other person or entity for any Third-Party Services.<br />\r\n<br />\r\nThird-Party Services and links thereto are provided solely as a convenience to you and you access and use them entirely at your own risk and subject to such third parties&#39; terms and conditions.<br />\r\n<br />\r\n<br />\r\n<strong>Term and Termination</strong><br />\r\n<br />\r\nThis Agreement shall remain in effect until terminated by you or Festgate.<br />\r\nFestgate may, in its sole discretion, at any time and for any or no reason, suspend or terminate this Agreement with or without prior notice.<br />\r\nThis Agreement will terminate immediately, without prior notice from Festgate, in the event that you fail to comply with any provision of this Agreement. You may also terminate this Agreement by deleting the website and all copies thereof from your computer.<br />\r\nUpon termination of this Agreement, you shall cease all use of the website and delete all copies of the website from your computer.<br />\r\nTermination of this Agreement will not limit any of Festgate&#39;s rights or remedies at law or in equity in case of breach by you (during the term of this Agreement) of any of your obligations under the present Agreement.<br />\r\n<br />\r\n<br />\r\n<strong>Copyright Infringement Notice</strong><br />\r\n<br />\r\nIf you are a copyright owner or such owner&rsquo;s agent and believe any material on our website constitutes an infringement on your copyright, please contact us setting forth the following information: (a) a physical or electronic signature of the copyright owner or a person authorized to act on his behalf; (b) identification of the material that is claimed to be infringing; (c) your contact information, including your address, telephone number, and an email; (d) a statement by you that you have a good faith belief that use of the material is not authorized by the copyright owners; and (e) the a statement that the information in the notification is accurate, and, under penalty of perjury you are authorized to act on behalf of the owner.<br />\r\n<br />\r\n<br />\r\n<strong>Indemnification</strong><br />\r\n<br />\r\nYou agree to indemnify and hold Festgate and its parents, subsidiaries, affiliates, officers, employees, agents, partners and licensors (if any) harmless from any claim or demand, including reasonable attorneys&#39; fees, due to or arising out of your: (a) use of the website; (b) violation of this Agreement or any law or regulation; or (c) violation of any right of a third party.<br />\r\n<br />\r\n<br />\r\n<strong>No Warranties</strong><br />\r\n<br />\r\nThe website is provided to you &quot;AS IS&quot; and &quot;AS AVAILABLE&quot; and with all faults and defects without warranty of any kind. To the maximum extent permitted under applicable law, Festgate, on its own behalf and on behalf of its affiliates and its and their respective licensors and service providers, expressly disclaims all warranties, whether express, implied, statutory or otherwise, with respect to the website, including all implied warranties of merchantability, fitness for a particular purpose, title and non-infringement, and warranties that may arise out of course of dealing, course of performance, usage or trade practice. Without limitation to the foregoing, Festgate provides no warranty or undertaking, and makes no representation of any kind that the website will meet your requirements, achieve any intended results, be compatible or work with any other software, , systems or services, operate without interruption, meet any performance or reliability standards or be error free or that any errors or defects can or will be corrected.<br />\r\n<br />\r\nWithout limiting the foregoing, neither Festgate nor any Festgate&#39;s provider makes any representation or warranty of any kind, express or implied: (i) as to the operation or availability of the website, or the information, content, and materials or products included thereon; (ii) that the website will be uninterrupted or error-free; (iii) as to the accuracy, reliability, or currency of any information or content provided through the website; or (iv) that the website, its servers, the content, or e-mails sent from or on behalf of Festgate are free of viruses, scripts, trojan horses, worms, malware, timebombs or other harmful components.<br />\r\n<br />\r\nSome jurisdictions do not allow the exclusion of or limitations on implied warranties or the limitations on the applicable statutory rights of a consumer, so some or all of the above exclusions and limitations may not apply to you.<br />\r\n<br />\r\n<br />\r\n<strong>Limitation of Liability</strong><br />\r\n<br />\r\nNotwithstanding any damages that you might incur, the entire liability of Festgate and any of its suppliers under any provision of this Agreement and your exclusive remedy for all of the foregoing shall be limited to the amount actually paid by you for the website.<br />\r\n<br />\r\nTo the maximum extent permitted by applicable law, in no event shall Festgate or its suppliers be liable for any special, incidental, indirect, or consequential damages whatsoever (including, but not limited to, damages for loss of profits, for loss of data or other information, for business interruption, for personal injury, for loss of privacy arising out of or in any way related to the use of or inability to use the website, third-party software and/or third-party hardware used with the website, or otherwise in connection with any provision of this Agreement), even if Festgate or any supplier has been advised of the possibility of such damages and even if the remedy fails of its essential purpose.<br />\r\n<br />\r\nSome states/jurisdictions do not allow the exclusion or limitation of incidental or consequential damages, so the above limitation or exclusion may not apply to you.<br />\r\n<br />\r\n<br />\r\n<strong>Severability</strong><br />\r\n<br />\r\nIf any provision of this Agreement is held to be unenforceable or invalid, such provision will be changed and interpreted to accomplish the objectives of such provision to the greatest extent possible under applicable law and the remaining provisions will continue in full force and effect.<br />\r\n<br />\r\nThis Agreement, together with the Privacy Policy and any other legal notices published by Festgate on the Services, shall constitute the entire agreement between you and Festgate concerning the Services. If any provision of this Agreement is deemed invalid by a court of competent jurisdiction, the invalidity of such provision shall not affect the validity of the remaining provisions of this Agreement, which shall remain in full force and effect. No waiver of any term of this Agreement shall be deemed a further or continuing waiver of such term or any other term, and Festgate&#39;s failure to assert any right or provision under this Agreement shall not constitute a waiver of such right or provision. YOU AND Festgate AGREE THAT ANY CAUSE OF ACTION ARISING OUT OF OR RELATED TO THE SERVICES MUST COMMENCE WITHIN ONE (1) YEAR AFTER THE CAUSE OF ACTION ACCRUES. OTHERWISE, SUCH CAUSE OF ACTION IS PERMANENTLY BARRED.<br />\r\n<br />\r\n<br />\r\n<strong>Waiver</strong><br />\r\n<br />\r\nExcept as provided herein, the failure to exercise a right or to require performance of an obligation under this Agreement shall not effect a party&#39;s ability to exercise such right or require such performance at any time thereafter nor shall be the waiver of a breach constitute waiver of any subsequent breach.<br />\r\n<br />\r\no failure to exercise, and no delay in exercising, on the part of either party, any right or any power under this Agreement shall operate as a waiver of that right or power. Nor shall any single or partial exercise of any right or power under this Agreement preclude further exercise of that or any other right granted herein. In the event of a conflict between this Agreement and any applicable purchase or other terms, the terms of this Agreement shall govern.<br />\r\n<br />\r\n<br />\r\n<strong>Amendments to this Agreement</strong><br />\r\n<br />\r\nFestgate reserves the right, at its sole discretion, to modify or replace this Agreement at any time. If a revision is material we will provide at least 30 days&#39; notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.<br />\r\n<br />\r\nBy continuing to access or use our website after any revisions become effective, you agree to be bound by the revised terms. If you do not agree to the new terms, you are no longer authorized to use Festgate.<br />\r\n<br />\r\n<br />\r\n<strong>Entire Agreement</strong><br />\r\n<br />\r\nThe Agreement constitutes the entire agreement between you and Festgate regarding your use of the website and supersedes all prior and contemporaneous written or oral agreements between you and Festgate.<br />\r\n<br />\r\nYou may be subject to additional terms and conditions that apply when you use or purchase other Festgate&#39;s services, which Festgate will provide to you at the time of such use or purchase.<br />\r\n<br />\r\n<br />\r\n<strong>Updates to Our Terms</strong><br />\r\n<br />\r\nWe may change our Service and policies, and we may need to make changes to these Terms so that they accurately reflect our Service and policies. Unless otherwise required by law, we will notify you (for example, through our Service) before we make changes to these Terms and give you an opportunity to review them before they go into effect. Then, if you continue to use the Service, you will be bound by the updated Terms. If you do not want to agree to these or any updated Terms, you can delete your account.<br />\r\n<br />\r\n<br />\r\n<strong>Intellectual Property</strong><br />\r\n<br />\r\nThe website and its entire contents, features and functionality (including but not limited to all information, software, text, displays, images, video and audio, and the design, selection and arrangement thereof), are owned by Festgate, its licensors or other providers of such material and are protected by ES and international copyright, trademark, patent, trade secret and other intellectual property or proprietary rights laws. The material may not be copied, modified, reproduced, downloaded or distributed in any way, in whole or in part, without the express prior written permission of Festgate, unless and except as is expressly provided in these Terms &amp; Conditions. Any unauthorized use of the material is prohibited.<br />\r\n<br />\r\n<br />\r\n<strong>Agreement to Arbitrate</strong><br />\r\n<br />\r\nThis section applies to any dispute EXCEPT IT DOESN&rsquo;T INCLUDE A DISPUTE RELATING TO CLAIMS FOR INJUNCTIVE OR EQUITABLE RELIEF REGARDING THE ENFORCEMENT OR VALIDITY OF YOUR OR Festgate&#39;s INTELLECTUAL PROPERTY RIGHTS. The term &ldquo;dispute&rdquo; means any dispute, action, or other controversy between you and Festgate concerning the Services or this agreement, whether in contract, warranty, tort, statute, regulation, ordinance, or any other legal or equitable basis. &ldquo;Dispute&rdquo; will be given the broadest possible meaning allowable under law.<br />\r\n<br />\r\n<br />\r\n<strong>Notice of Dispute</strong><br />\r\n<br />\r\nIn the event of a dispute, you or Festgate must give the other a Notice of Dispute, which is a written statement that sets forth the name, address, and contact information of the party giving it, the facts giving rise to the dispute, and the relief requested. You must send any Notice of Dispute via email to: webmaster@festgate.com Festgate will send any Notice of Dispute to you by mail to your address if we have it, or otherwise to your email address. You and Festgate will attempt to resolve any dispute through informal negotiation within sixty (60) days from the date the Notice of Dispute is sent. After sixty (60) days, you or Festgate may commence arbitration.<br />\r\n<br />\r\n<br />\r\n<strong>Binding Arbitration</strong><br />\r\n<br />\r\nIf you and Festgate don&rsquo;t resolve any dispute by informal negotiation, any other effort to resolve the dispute will be conducted exclusively by binding arbitration as described in this section. You are giving up the right to litigate (or participate in as a party or class member) all disputes in court before a judge or jury. The dispute shall be settled by binding arbitration in accordance with the commercial arbitration rules of the American Arbitration Association. Either party may seek any interim or preliminary injunctive relief from any court of competent jurisdiction, as necessary to protect the party&rsquo;s rights or property pending the completion of arbitration. Any and all legal, accounting, and other costs, fees, and expenses incurred by the prevailing party shall be borne by the non-prevailing party.<br />\r\n<br />\r\n<br />\r\n<strong>Submissions and Privacy</strong><br />\r\n<br />\r\nIn the event that you submit or post any ideas, creative suggestions, designs, photographs, information, advertisements, data or proposals, including ideas for new or improved products, services, features, technologies or promotions, you expressly agree that such submissions will automatically be treated as non-confidential and non-proprietary and will become the sole property of Festgate without any compensation or credit to you whatsoever. Festgate and its affiliates shall have no obligations with respect to such submissions or posts and may use the ideas contained in such submissions or posts for any purposes in any medium in perpetuity, including, but not limited to, developing, manufacturing, and marketing products and services using such ideas.<br />\r\n<br />\r\n<br />\r\n<strong>Promotions</strong><br />\r\n<br />\r\nFestgate may, from time to time, include contests, promotions, sweepstakes, or other activities (&ldquo;Promotions&rdquo;) that require you to submit material or information concerning yourself. Please note that all Promotions may be governed by separate rules that may contain certain eligibility requirements, such as restrictions as to age and geographic location. You are responsible to read all Promotions rules to determine whether or not you are eligible to participate. If you enter any Promotion, you agree to abide by and to comply with all Promotions Rules.<br />\r\n<br />\r\nAdditional terms and conditions may apply to purchases of goods or services on or through the Services, which terms and conditions are made a part of this Agreement by this reference.<br />\r\n<br />\r\n<br />\r\n<strong>Typographical Errors</strong><br />\r\n<br />\r\n<br />\r\nIn the event a product and/or service is listed at an incorrect price or with incorrect information due to typographical error, we shall have the right to refuse or cancel any orders placed for the product and/or service listed at the incorrect price. We shall have the right to refuse or cancel any such order whether or not the order has been confirmed and your credit card charged. If your credit card has already been charged for the purchase and your order is canceled, we shall immediately issue a credit to your credit card account or other payment account in the amount of the charge.<br />\r\n<br />\r\n<br />\r\n<strong>Miscellaneous</strong><br />\r\n<br />\r\nIf for any reason a court of competent jurisdiction finds any provision or portion of these Terms &amp; Conditions to be unenforceable, the remainder of these Terms &amp; Conditions will continue in full force and effect. Any waiver of any provision of these Terms &amp; Conditions will be effective only if in writing and signed by an authorized representative of Festgate. Festgate will be entitled to injunctive or other equitable relief (without the obligations of posting any bond or surety) in the event of any breach or anticipatory breach by you. Festgate operates and controls the Festgate Service from its offices in US. The Service is not intended for distribution to or use by any person or entity in any jurisdiction or country where such distribution or use would be contrary to law or regulation. Accordingly, those persons who choose to access the Festgate Service from other locations do so on their own initiative and are solely responsible for compliance with local laws, if and to the extent local laws are applicable. These Terms &amp; Conditions (which include and incorporate the Festgate Privacy Policy) contains the entire understanding, and supersedes all prior understandings, between you and Festgate concerning its subject matter, and cannot be changed or modified by you. The section headings used in this Agreement are for convenience only and will not be given any legal import.<br />\r\n<br />\r\n<br />\r\n<strong>Disclaimer</strong><br />\r\n<br />\r\nFestgate is not responsible for any content, code or any other imprecision.<br />\r\n<br />\r\nFestgate does not provide warranties or guarantees.<br />\r\n<br />\r\nIn no event shall Festgate be liable for any special, direct, indirect, consequential, or incidental damages or any damages whatsoever, whether in an action of contract, negligence or other tort, arising out of or in connection with the use of the Service or the contents of the Service. The Company reserves the right to make additions, deletions, or modifications to the contents on the Service at any time without prior notice.<br />\r\n<br />\r\nThe Festgate Service and its contents are provided &quot;as is&quot; and &quot;as available&quot; without any warranty or representations of any kind, whether express or implied. Festgate is a distributor and not a publisher of the content supplied by third parties; as such, Festgate exercises no editorial control over such content and makes no warranty or representation as to the accuracy, reliability or currency of any information, content, service or merchandise provided through or accessible via the Festgate Service. Without limiting the foregoing, Festgate specifically disclaims all warranties and representations in any content transmitted on or in connection with the Festgate Service or on sites that may appear as links on the Festgate Service, or in the products provided as a part of, or otherwise in connection with, the Festgate Service, including without limitation any warranties of merchantability, fitness for a particular purpose or non-infringement of third party rights. No oral advice or written information given by Festgate or any of its affiliates, employees, officers, directors, agents, or the like will create a warranty. Price and availability information is subject to change without notice. Without limiting the foregoing, Festgate does not warrant that the Festgate Service will be uninterrupted, uncorrupted, timely, or error-free.<br />\r\n<br />\r\n<br />\r\n<strong>Contact Us</strong><br />\r\n<br />\r\nDon&#39;t hesitate to contact us if you have any questions.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Cookie:&nbsp;small amount of data generated by a website and saved by your web browser. It is used to identify your browser, provide analytics, remember information about you such as your language preference or login information.</p>\r\n\r\n<p>Company: when this policy mentions &ldquo;Company,&rdquo; &ldquo;we,&rdquo; &ldquo;us,&rdquo; or &ldquo;our,&rdquo; it refers to Festgate LLC, 120 Madeira Dr NE, Ste 220, Albuquerque (New Mexico) that is responsible for your information under this Terms &amp; Conditions.</p>\r\n\r\n<p>Country: where Festgate or the owners/founders of Festgate are based, in this case is USA.</p>\r\n\r\n<p>Device:&nbsp;any internet connected device such as a phone, tablet, computer or any other device that can be used to visit Festgate and use the services.</p>\r\n\r\n<p>Service: refers to the service provided by Festgate as described in the relative terms (if available) and on this platform.</p>\r\n\r\n<p>Third-party service:&nbsp;refers to advertisers, contest sponsors, promotional and marketing partners, and others who provide our content or whose products or services we think may interest you.</p>\r\n\r\n<p>Website: Festgate&#39;s site, which can be accessed via this URL: https://festgate.com</p>\r\n\r\n<p>You: a person or entity that is registered with Festgate to use the Services.</p>\r\n\r\n<p>License, sell, rent, lease, assign, distribute, transmit, host, outsource, disclose or otherwise commercially exploit the website or make the platform available to any third party.</p>\r\n\r\n<p>Modify, make derivative works of, disassemble, decrypt, reverse compile or reverse engineer any part of the website.</p>\r\n\r\n<p>Remove, alter or obscure any proprietary notice (including any notice of copyright or trademark) of Festgate or its affiliates, partners, suppliers or the licensors of the website.</p>\r\n\r\n<p>Via Email: webmaster@festgate.com or festgatellc@gmail.com</p>','terms-of-service',NULL,'Terminos y servicios de Cine Autor','terms, Terms of Service','en','all','1',NULL,'2023-07-24 20:31:42'),(3,'page','Privacy','<p><strong>Privacy Policy</strong><br />\r\n<br />\r\nUpdated at 2021-09-24<br />\r\n<br />\r\nFestgate (&ldquo;we,&rdquo; &ldquo;our,&rdquo; or &ldquo;us&rdquo;) is committed to protecting your privacy. This Privacy Policy explains how your personal information is collected, used, and disclosed by Festgate.<br />\r\n<br />\r\nThis Privacy Policy applies to our website, and its associated subdomains (collectively, our &ldquo;Service&rdquo;) alongside our application, Festgate.<br />\r\n<br />\r\nBy accessing or using our Service, you signify that you have read, understood, and agree to our collection, storage, use, and disclosure of your personal information as described in this Privacy Policy and our Terms of Service.<br />\r\n<br />\r\n<br />\r\n<strong>Definitions and key terms</strong><br />\r\n<br />\r\nTo help explain things as clearly as possible in this Privacy Policy, every time any of these terms are referenced, are strictly defined as:</p>\r\n\r\n<ul>\r\n	<li>Cookie:&nbsp;small amount of data generated by a website and saved by your web browser. It is used to identify your browser, provide analytics, remember information about you such as your language preference or login information.</li>\r\n	<li>Company: when this policy mentions &ldquo;Company,&rdquo; &ldquo;we,&rdquo; &ldquo;us,&rdquo; or &ldquo;our,&rdquo; it refers to Festgate LLC, 120 Madeira Dr NE, Ste 220, Albuquerque (New Mexico) that is responsible for your information under this Privacy Policy.</li>\r\n	<li>Country: where Festgate or the owners/founders of Festgate are based, in this case is USA.</li>\r\n	<li>Customer:&nbsp;refers to the company, organization or person that signs up to use the Festgate Service to manage the relationships with your consumers or service users.</li>\r\n	<li>Device:&nbsp;any internet connected device such as a phone, tablet, computer or any other device that can be used to visit Festgate and use the services.</li>\r\n	<li>IP address: Every device connected to the Internet is assigned a number known as an Internet protocol (IP) address. These numbers are usually assigned in geographic blocks. An IP address can often be used to identify the location from which a device is connecting to the Internet.</li>\r\n	<li>Personnel:&nbsp;refers to those individuals who are employed by Festgate or are under contract to perform a service on behalf of one of the parties.</li>\r\n	<li>Personal Data: any information that directly, indirectly, or in connection with other information &mdash; including a personal identification number &mdash; allows for the identification or identifiability of a natural person.</li>\r\n	<li>Service: refers to the service provided by Festgate as described in the relative terms (if available) and on this platform.</li>\r\n	<li>Third-party service:&nbsp;refers to advertisers, contest sponsors, promotional and marketing partners, and others who provide our content or whose products or services we think may interest you.</li>\r\n	<li>Website: Festgate&#39;s site, which can be accessed via this URL: <a href=\"https://festgate.com\">https://festgate.com</a></li>\r\n	<li>You: a person or entity that is registered with Festgate to use the Services.</li>\r\n</ul>\r\n\r\n<p><br />\r\n<strong>What Information Do We Collect?</strong><br />\r\n<br />\r\nWe collect information from you when you visit our website, register on our site, place an order, subscribe to our newsletter, respond to a survey or fill out a form.</p>\r\n\r\n<ul>\r\n	<li>Name / Username</li>\r\n	<li>Email Addresses</li>\r\n	<li>Job Titles</li>\r\n	<li>Billing Addresses</li>\r\n	<li>Debit/credit card numbers</li>\r\n	<li>Age</li>\r\n	<li>Password</li>\r\n</ul>\r\n\r\n<p>We also collect information from mobile devices for a better user experience, although these features are completely optional:</p>\r\n\r\n<ul>\r\n	<li>Camera (Pictures): Granting camera&nbsp;permission&nbsp;allows the user to upload any picture straight from the website, you can safely deny camera permissions for this website.</li>\r\n	<li>Photo Gallery (Pictures): Granting photo gallery access&nbsp;allows the user to upload any picture from their photo gallery, you can safely deny photo gallery access for this website.</li>\r\n</ul>\r\n\r\n<p><br />\r\n<strong>How Do We Use The Information We Collect?</strong><br />\r\n<br />\r\nAny of the information we collect from you may be used in one of the following ways:</p>\r\n\r\n<ul>\r\n	<li>To personalize your experience (your information helps us to better respond to your individual needs)</li>\r\n	<li>To improve our website (we continually strive to improve our website offerings based on the information and feedback we receive from you)</li>\r\n	<li>To improve customer service (your information helps us to more effectively respond to your customer service requests and support needs)</li>\r\n	<li>To process transactions</li>\r\n	<li>To administer a contest, promotion, survey or other site feature</li>\r\n	<li>To send periodic emails</li>\r\n</ul>\r\n\r\n<p><br />\r\n<strong>When does Festgate use end user information from third parties?</strong><br />\r\n<br />\r\nFestgate will collect End User Data necessary to provide the Festgate services to our customers.<br />\r\nEnd users may voluntarily provide us with information they have made available on social media websites. If you provide us with any such information, we may collect publicly available information from the social media websites you have indicated. You can control how much of your information social media websites make public by visiting these websites and changing your privacy settings.<br />\r\n<br />\r\n<br />\r\n<strong>When does Festgate use customer information from third parties?</strong><br />\r\n<br />\r\nWe receive some information from the third parties when you contact us. For example, when you submit your email address to us to show interest in becoming a Festgate customer, we receive information from a third party that provides automated fraud detection services to Festgate. We also occasionally collect information that is made publicly available on social media websites. You can control how much of your information social media websites make public by visiting these websites and changing your privacy settings.<br />\r\n<br />\r\n<br />\r\n<strong>Do we share the information we collect with third parties?</strong><br />\r\n<br />\r\nWe may share the information that we collect, both personal and non-personal, with third parties such as advertisers, contest sponsors, promotional and marketing partners, and others who provide our content or whose products or services we think may interest you. We may also share it with our current and future affiliated companies and business partners, and if we are involved in a merger, asset sale or other business reorganization, we may also share or transfer your personal and non-personal information to our successors-in-interest.<br />\r\n<br />\r\nWe may engage trusted third party service providers to perform functions and provide services to us, such as hosting and maintaining our servers and the website, database storage and management, e-mail management, storage marketing, credit card processing, customer service and fulfilling orders for products and services you may purchase through the website. We will likely share your personal information, and possibly some non-personal information, with these third parties to enable them to perform these services for us and for you.<br />\r\n<br />\r\nWe may share portions of our log file data, including IP addresses, for analytics purposes with third parties such as web analytics partners, application developers, and ad networks. If your IP address is shared, it may be used to estimate general location and other technographics such as connection speed, whether you have visited the website in a shared location, and type of the device used to visit the website. They may aggregate information about our advertising and what you see on the website and then provide auditing, research and reporting for us and our advertisers.&nbsp;  We may also disclose personal and non-personal information about you to government or law enforcement officials or private parties as we, in our sole discretion, believe necessary or appropriate in order to respond to claims, legal process (including subpoenas), to protect our rights and interests or those of a third party, the safety of the public or any person, to prevent or stop any illegal, unethical, or legally actionable activity, or to otherwise comply with applicable court orders, laws, rules and regulations.<br />\r\n<br />\r\n<br />\r\n<strong>Where and when is information collected from customers and end users?</strong><br />\r\n<br />\r\nFestgate will collect personal information that you submit to us. We may also receive personal information about you from third parties as described above.<br />\r\n<br />\r\n<br />\r\n<strong>How Do We Use Your Email Address?</strong><br />\r\n<br />\r\nBy submitting your email address on this website, you agree to receive emails from us. You can cancel your participation in any of these email lists at any time by clicking on the opt-out link or other unsubscribe option that is included in the respective email. We only send emails to people who have authorized us to contact them, either directly, or through a third party. We do not send unsolicited commercial emails, because we hate spam as much as you do. By submitting your email address, you also agree to allow us to use your email address for customer audience targeting on sites like Facebook, where we display custom advertising to specific people who have opted-in to receive communications from us. Email addresses submitted only through the order processing page will be used for the sole purpose of sending you information and updates pertaining to your order. If, however, you have provided the same email to us through another method, we may use it for any of the purposes stated in this Policy. Note: If at any time you would like to unsubscribe from receiving future emails, we include detailed unsubscribe instructions at the bottom of each email.<br />\r\n<br />\r\n<br />\r\n<strong>How Long Do We Keep Your Information?</strong><br />\r\n<br />\r\nWe keep your information only so long as we need it to provide Festgate to you and fulfill the purposes described in this policy. This is also the case for anyone that we share your information with and who carries out services on our behalf. When we no longer need to use your information and there is no need for us to keep it to comply with our legal or regulatory obligations, we&rsquo;ll either remove it from our systems or depersonalize it so that we can&#39;t identify you.<br />\r\n<br />\r\n<br />\r\n<strong>How Do We Protect Your Information?</strong><br />\r\n<br />\r\nWe implement a variety of security measures to maintain the safety of your personal information when you place an order or enter, submit, or access your personal information. We offer the use of a secure server. All supplied sensitive/credit information is transmitted via Secure Socket Layer (SSL) technology and then encrypted into our Payment gateway providers database only to be accessible by those authorized with special access rights to such systems, and are required to keep the information confidential. After a transaction, your private information (credit cards, social security numbers, financials, etc.) is never kept on file. We cannot, however, ensure or warrant the absolute security of any information you transmit to Festgate or guarantee that your information on the Service may not be accessed, disclosed, altered, or destroyed by a breach of any of our physical, technical, or managerial safeguards.<br />\r\n<br />\r\n<br />\r\n<strong>Could my information be transferred to other countries?</strong><br />\r\n<br />\r\nFestgate is incorporated in United States. Information collected via our website, through direct interactions with you, or from use of our help services may be transferred from time to time to our offices or personnel, or to third parties, located throughout the world, and may be viewed and hosted anywhere in the world, including countries that may not have laws of general applicability regulating the use and transfer of such data. To the fullest extent allowed by applicable law, by using any of the above, you voluntarily consent to the trans-border transfer and hosting of such information.<br />\r\n<br />\r\n<br />\r\n<strong>Is the information collected through the Festgate Service secure?</strong><br />\r\n<br />\r\nWe take precautions to protect the security of your information. We have physical, electronic, and managerial procedures to help safeguard, prevent unauthorized access, maintain data security, and correctly use your information. However, neither people nor security systems are foolproof, including encryption systems. In addition, people can commit intentional crimes, make mistakes or fail to follow policies. Therefore, while we use reasonable efforts to protect your personal information, we cannot guarantee its absolute security. If applicable law imposes any non-disclaimable duty to protect your personal information, you agree that intentional misconduct will be the standards used to measure our compliance with that duty.<br />\r\n<br />\r\n<br />\r\n<strong>Can I update or correct my information?</strong><br />\r\n<br />\r\nThe rights you have to request updates or corrections to the information Festgate collects depend on your relationship with Festgate. Personnel may update or correct their information as detailed in our internal company employment policies.<br />\r\n<br />\r\nCustomers have the right to request the restriction of certain uses and disclosures of personally identifiable information as follows. You can&nbsp;contact us in order to (1) update or correct your personally identifiable information, (2) change your preferences with respect to communications and other information you receive from us, or (3) delete the personally identifiable information maintained about you on our systems (subject to the following paragraph), by&nbsp;cancelling your account. Such updates, corrections, changes and deletions will have no effect on other information that we maintain, or information that we have provided to third parties in accordance with this Privacy Policy prior to such update, correction, change or deletion. To protect your privacy and security, we may take reasonable steps (such as requesting a unique password) to verify your identity before granting you profile access or making corrections. You are responsible for maintaining the secrecy of your unique password and account information at all times.<br />\r\n<br />\r\nYou should be aware that it is not technologically possible to remove each and every record of the information you have provided to us from our system. The need to back up our systems to protect information from inadvertent loss means that a copy of your information may exist in a non-erasable form that will be difficult or impossible for us to locate. Promptly after receiving your request, all personal information stored in databases we actively use, and other readily searchable media will be updated, corrected, changed or deleted, as appropriate, as soon as and to the extent reasonably and technically practicable.<br />\r\n<br />\r\nIf you are an end user and wish to update, delete, or receive any information we have about you, you may do so by contacting the organization of which you are a customer.<br />\r\n<br />\r\n<br />\r\n<strong>Personnel</strong><br />\r\n<br />\r\nIf you are a Festgate worker or applicant, we collect information you voluntarily provide to us. We use the information collected for Human Resources purposes in order to administer benefits to workers and screen applicants.<br />\r\nYou may contact us in order to (1) update or correct your information, (2) change your preferences with respect to communications and other information you receive from us, or (3) receive a record of the information we have relating to you. Such updates, corrections, changes and deletions will have no effect on other information that we maintain, or information that we have provided to third parties in accordance with this Privacy Policy prior to such update, correction, change or deletion.<br />\r\n<br />\r\n<br />\r\n<strong>Sale of Business</strong><br />\r\n<br />\r\nWe reserve the right to transfer information to a third party in the event of a sale, merger or other transfer of all or substantially all of the assets of Festgate or any of its Corporate Affiliates (as defined herein), or that portion of Festgate or any of its Corporate Affiliates to which the Service relates, or in the event that we discontinue our business or file a petition or have filed against us a petition in bankruptcy, reorganization or similar proceeding, provided that the third party agrees to adhere to the terms of this Privacy Policy.<br />\r\n<br />\r\n<br />\r\n<strong>Affiliates</strong><br />\r\n<br />\r\nWe may disclose information (including personal information) about you to our Corporate Affiliates. For purposes of this Privacy Policy, &quot;Corporate Affiliate&quot; means any person or entity which directly or indirectly controls, is controlled by or is under common control with Festgate, whether by ownership or otherwise. Any information relating to you that we provide to our Corporate Affiliates will be treated by those Corporate Affiliates in accordance with the terms of this Privacy Policy.<br />\r\n<br />\r\n<br />\r\n<strong>Governing Law</strong><br />\r\n<br />\r\nThis Privacy Policy is governed by the laws of United States without regard to its conflict of laws provision. You consent to the exclusive jurisdiction of the courts in connection with any action or dispute arising between the parties under or in connection with this Privacy Policy except for those individuals who may have rights to make claims under Privacy Shield, or the Swiss-US framework.<br />\r\nThe laws of United States, excluding its conflicts of law rules, shall govern this Agreement and your use of the website. Your use of the website may also be subject to other local, state, national, or international laws.</p>\r\n\r\n<p><br />\r\nBy using Festgate or contacting us directly, you signify your acceptance of this Privacy Policy. If you do not agree to this Privacy Policy, you should not engage with our website, or use our services. Continued use of the website, direct engagement with us, or following the posting of changes to this Privacy Policy that do not significantly affect the use or disclosure of your personal information will mean that you accept those changes.<br />\r\n<br />\r\n<br />\r\n<strong>Your Consent</strong><br />\r\n<br />\r\nWe&#39;ve updated our&nbsp;Privacy Policy&nbsp;to provide you with complete transparency into what is being set when you visit our site and how it&#39;s being used. By using our website, registering an account, or making a purchase, you hereby consent to our Privacy Policy and agree to its terms.<br />\r\n<br />\r\n<br />\r\n<strong>Links to Other Websites</strong><br />\r\n<br />\r\nThis Privacy Policy applies only to the Services. The Services may contain links to other websites not operated or controlled by Festgate. We are not responsible for the content, accuracy or opinions expressed in such websites, and such websites are not investigated, monitored or checked for accuracy or completeness by us. Please remember that when you use a link to go from the Services to another website, our Privacy Policy is no longer in effect. Your browsing and interaction on any other website, including those that have a link on our platform, is subject to that website&rsquo;s own rules and policies. Such third parties may use their own cookies or other methods to collect information about you.<br />\r\n<br />\r\n<br />\r\n<strong>Advertising</strong><br />\r\n<br />\r\nThis website may contain third party advertisements and links to third party sites. Festgate does not make any representation as to the accuracy or suitability of any of the information contained in those advertisements or sites and does not accept any responsibility or liability for the conduct or content of those advertisements and sites and the offerings made by the third parties.<br />\r\n<br />\r\nAdvertising keeps Festgate and many of the websites and services you use free of charge. We work hard to make sure that ads are safe, unobtrusive, and as relevant as possible.<br />\r\n<br />\r\nThird party advertisements and links to other sites where goods or services are advertised are not endorsements or recommendations by Festgate of the third party sites, goods or services. Festgate takes no responsibility for the content of any of the ads, promises made, or the quality/reliability of the products or services offered in all advertisements.<br />\r\n<br />\r\n<br />\r\n<strong>Cookies for Advertising</strong><br />\r\n<br />\r\nThese cookies collect information over time about your online activity on the website and other online services to make online advertisements more relevant and effective to you. This is known as interest-based advertising. They also perform functions like preventing the same ad from continuously reappearing and ensuring that ads are properly displayed for advertisers. Without cookies, it&rsquo;s really hard for an advertiser to reach its audience, or to know how many ads were shown and how many clicks they received.<br />\r\n<br />\r\n<br />\r\n<strong>Cookies</strong><br />\r\n<br />\r\nFestgate uses &quot;Cookies&quot; to identify the areas of our website that you have visited. A Cookie is a small piece of data stored on your computer or mobile device by your web browser. We use Cookies to enhance the performance and functionality of our website but are non-essential to their use. However, without these cookies, certain functionality like videos may become unavailable or you would be required to enter your login details every time you visit the website as we would not be able to remember that you had logged in previously. Most web browsers can be set to disable the use of Cookies. However, if you disable Cookies, you may not be able to access functionality on our website correctly or at all. We never place Personally Identifiable Information in Cookies.<br />\r\n<br />\r\nMore about our cookie policy: <a href=\"https://festgate.com/pg/cookies\">https://festgate.com/pg/cookies</a><br />\r\n<br />\r\n<br />\r\n<strong>Blocking and disabling cookies and similar technologies</strong><br />\r\n<br />\r\nWherever you&#39;re located you may also set your browser to block cookies and similar technologies, but this action may block our essential cookies and prevent our website from functioning properly, and you may not be able to fully utilize all of its features and services. You should also be aware that you may also lose some saved information (e.g. saved login details, site preferences) if you block cookies on your browser. Different browsers make different controls available to you. Disabling a cookie or category of cookie does not delete the cookie from your browser, you will need to do this yourself from within your browser, you should visit your browser&#39;s help menu for more information.<br />\r\n<br />\r\n<br />\r\n<strong>Payment Details</strong><br />\r\n<br />\r\nIn respect to any credit card or other payment processing details you have provided us, we commit that this confidential information will be stored in the most secure manner possible.<br />\r\n<br />\r\n<br />\r\n<strong>Kids&#39; Privacy</strong><br />\r\n<br />\r\nWe do not address anyone under the age of 13. We do not knowingly collect personally identifiable information from anyone under the age of 13. If You are a parent or guardian and You are aware that Your child has provided Us with Personal Data, please contact Us. If We become aware that We have collected Personal Data from anyone under the age of 13 without verification of parental consent, We take steps to remove that information from Our servers.<br />\r\n<br />\r\n<br />\r\n<strong>Changes To Our Privacy Policy</strong><br />\r\n<br />\r\nWe may change our Service and policies, and we may need to make changes to this Privacy Policy so that they accurately reflect our Service and policies. Unless otherwise required by law, we will notify you (for example, through our Service) before we make changes to this Privacy Policy and give you an opportunity to review them before they go into effect. Then, if you continue to use the Service, you will be bound by the updated Privacy Policy. If you do not want to agree to this or any updated Privacy Policy, you can delete your account.<br />\r\n<br />\r\n<br />\r\n<strong>Third-Party Services</strong><br />\r\n<br />\r\nWe may display, include or make available third-party content (including data, information, applications and other products services) or provide links to third-party websites or services (&quot;Third- Party Services&quot;).<br />\r\n<br />\r\nYou acknowledge and agree that Festgate shall not be responsible for any Third-Party Services, including their accuracy, completeness, timeliness, validity, copyright compliance, legality, decency, quality or any other aspect thereof. Festgate does not assume and shall not have any liability or responsibility to you or any other person or entity for any Third-Party Services.<br />\r\n<br />\r\nThird-Party Services and links thereto are provided solely as a convenience to you and you access and use them entirely at your own risk and subject to such third parties&#39; terms and conditions.<br />\r\n<br />\r\n<br />\r\n<strong>Tracking Technologies</strong></p>\r\n\r\n<ul>\r\n	<li>Cookies<br />\r\n	<br />\r\n	We use Cookies to enhance the performance and functionality of our $platform but are non-essential to their use. However, without these cookies, certain functionality like videos may become unavailable or you would be required to enter your login details every time you visit the $platform as we would not be able to remember that you had logged in previously.</li>\r\n	<br />\r\n	<li>Local Storage<br />\r\n	<br />\r\n	Local Storage sometimes known as DOM storage, provides web apps with methods and protocols for storing client-side data. Web storage supports persistent data storage, similar to cookies but with a greatly enhanced capacity and no information stored in the HTTP request header.</li>\r\n	<br />\r\n	<li>Sessions<br />\r\n	<br />\r\n	$elnombre uses &quot;Sessions&quot; to identify the areas of our website that you have visited. A Session is a small piece of data stored on your computer or mobile device by your web browser.</li>\r\n</ul>\r\n\r\n<p>&nbsp;<br />\r\n<strong>Information about General Data Protection Regulation (GDPR)</strong><br />\r\n<br />\r\nWe may be collecting and using information from you if you are from the European Economic Area (EEA), and in this section of our Privacy Policy we are going to explain exactly how and why is this data collected, and how we maintain this data under protection from being replicated or used in the wrong way.<br />\r\n<br />\r\n<br />\r\n<strong>What is GDPR?</strong><br />\r\n<br />\r\nGDPR is an EU-wide privacy and data protection law that regulates how EU residents&#39; data is protected by companies and enhances the control&nbsp;the EU residents have, over their personal data.<br />\r\nThe GDPR is relevant to any globally operating company and not just the EU-based businesses and EU residents. Our customers&rsquo; data is important irrespective of where they are located, which is why we have implemented GDPR controls as our baseline standard for all our operations worldwide.<br />\r\n<br />\r\n<br />\r\n<strong>What is personal data?</strong><br />\r\n<br />\r\nAny data that relates to an identifiable or identified individual. GDPR covers a broad spectrum of information that could be used on its own, or in combination with other pieces of information, to identify a person. Personal data extends beyond a person&rsquo;s name or email address. Some examples include financial information, political opinions, genetic data, biometric data, IP addresses, physical address, sexual orientation, and ethnicity.<br />\r\nThe Data Protection Principles include requirements such as:</p>\r\n\r\n<ul>\r\n	<li>Personal data collected must be processed in a fair, legal, and transparent way and should only be used in a way that a person would reasonably expect.</li>\r\n	<li>Personal data should only be collected to fulfil a specific purpose and it should only be used for that purpose. Organizations must specify why they need the personal data when they collect it.</li>\r\n	<li>Personal data should be held no longer than necessary to fulfil its purpose.</li>\r\n	<li>People covered by the GDPR have the right to access their own personal data. They can also request a copy of their data, and that their data be updated, deleted, restricted, or moved to another organization.</li>\r\n</ul>\r\n\r\n<p><br />\r\n<strong>Why is GDPR important?</strong><br />\r\n<br />\r\nGDPR adds some new requirements regarding how companies should protect individuals&#39; personal data that they collect and process. It also raises the stakes for compliance by increasing enforcement and imposing greater fines for breach. Beyond these facts it&#39;s simply the right thing to do. At Festgate we strongly believe that your data privacy is very important and we already have solid security and privacy practices in place that go beyond the requirements of this new regulation.<br />\r\n<br />\r\n<br />\r\n<strong>Individual Data Subject&#39;s Rights - Data Access, Portability and Deletion</strong><br />\r\n<br />\r\nWe are committed to helping our customers meet the&nbsp;data subject rights requirements of GDPR. Festgate processes or stores all personal data in fully vetted, DPA compliant vendors. We do store all conversation and personal data for up to 6 years unless your account is deleted. In which case, we dispose of all data in accordance with our Terms of Service and Privacy Policy, but we will not hold it longer than 60 days.<br />\r\n<br />\r\nWe are aware that if you are working with EU customers, you need to be able to provide them with the ability to access, update, retrieve and remove personal data. We got you! We&#39;ve been set up as self service from the start and have always given you access to your data and your customers data. Our customer&nbsp;support team is here for you to answer any questions you might have about working with the API.<br />\r\n<br />\r\n<br />\r\n<strong>California Residents</strong><br />\r\n<br />\r\nThe California Consumer Privacy Act (CCPA) requires us to disclose categories of Personal Information we collect and how we use it, the categories of sources from whom we collect Personal Information, and the third parties with whom we share it, which we have explained above.<br />\r\n<br />\r\nWe are also required to communicate information about rights California residents have under California law. You may exercise the following rights:</p>\r\n\r\n<ul>\r\n	<li>Right to Know and Access. You may submit a verifiable request for information regarding the: (1) categories of Personal Information we collect, use, or share; (2) purposes for which categories of Personal Information are collected or used by us; (3) categories of sources from which we collect Personal Information; and (4) specific pieces of Personal Information we have collected about you.</li>\r\n	<li>Right to Equal Service. We will not discriminate against you if you exercise your privacy rights.</li>\r\n	<li>Right to Delete. You may submit a verifiable request to close your account and we will delete Personal Information about you that we have collected.</li>\r\n	<li>Request that a business that sells a consumer&#39;s personal data, not sell the consumer&#39;s personal data.</li>\r\n</ul>\r\n\r\n<p>If you make a request, we have one month to respond to you. If you would like to exercise any of these rights, please contact us.<br />\r\n<br />\r\nWe do not sell the Personal Information of our users.<br />\r\n<br />\r\nFor more information about these rights, please contact us.<br />\r\n<br />\r\n<br />\r\n<strong>California Online Privacy Protection Act (CalOPPA)</strong><br />\r\n<br />\r\nCalOPPA requires us to disclose categories of Personal Information we collect and how we use it, the categories of sources from whom we collect Personal Information, and the third parties with whom we share it, which we have explained above.<br />\r\n<br />\r\nCalOPPA users have the following rights:</p>\r\n\r\n<ul>\r\n	<li>Right to Know and Access. You may submit a verifiable request for information regarding the: (1) categories of Personal Information we collect, use, or share; (2) purposes for which categories of Personal Information are collected or used by us; (3) categories of sources from which we collect Personal Information; and (4) specific pieces of Personal Information we have collected about you.</li>\r\n	<li>Right to Equal Service. We will not discriminate against you if you exercise your privacy rights.</li>\r\n	<li>Right to Delete. You may submit a verifiable request to close your account and we will delete Personal Information about you that we have collected.</li>\r\n	<li>Right to request that a business that sells a consumer&#39;s personal data, not sell the consumer&#39;s personal data.</li>\r\n</ul>\r\n\r\n<p>If you make a request, we have one month to respond to you. If you would like to exercise any of these rights, please contact us.<br />\r\n<br />\r\nWe do not sell the Personal Information of our users.<br />\r\n<br />\r\nFor more information about these rights, please contact us.<br />\r\n<br />\r\n<br />\r\n<strong>Contact Us</strong><br />\r\n<br />\r\nDon&#39;t hesitate to contact us if you have any questions.</p>\r\n\r\n<ul>\r\n	<li>Via Email: webmaster@festgate.com or festgatellc@gmail.com</li>\r\n</ul>','privacy',NULL,'','','en','all','1',NULL,'2023-07-24 20:23:36'),(5,'page','About us','<p style=\"margin-left:0; margin-right:0; text-align:start\"><span style=\"font-size:16px\"><strong>Festgate: Unleashing Creativity, Empowering Creators</strong></span></p>\r\n\r\n<p style=\"margin-left:0; margin-right:0; text-align:start\">Festgate, a brand under Festgate LLC, is a pioneering platform born from a collaboration between Spain and Mexico. Our journey began in 2020, following the closure of the major festival submission platform, Withoutabox, previously owned by Amazon, in 2019. This led a dedicated group of festivals and filmmakers to craft our unique platform to meet our specific needs. Despite the existence of other major platforms, we chose to create an environment that fosters personalized experiences, a vision we now share with creators worldwide.</p>\r\n\r\n<p style=\"margin-left:0; margin-right:0; text-align:start\">As a submission platform for festivals, Festgate is committed to serving a diverse array of events and contests. Whether it&#39;s film, music, art competitions, photography, scriptwriting, literature, and more, our mission is to provide an organized, efficient, and user-friendly space for both creators and event organizers.</p>\r\n\r\n<p style=\"margin-left:0; margin-right:0; text-align:start\">At Festgate, we&#39;re always looking to the future. We&#39;re dedicated to developing innovative and unique tools for our associated events, continually refining our platform to better suit the needs of our growing community. After three years of a successful beta version, we&#39;re proud to announce the launch of our stable 2.0.2 version in 2024. This milestone is a testament to our commitment to growth and improvement.</p>\r\n\r\n<p style=\"margin-left:0; margin-right:0; text-align:start\">By combining the values of collaboration, innovation, and user-centric design, Festgate serves as a bridge between creators and opportunities. As we continue to expand and adapt, our goal remains consistent: to facilitate creative expression and connect it with the perfect audience.</p>\r\n\r\n<p style=\"margin-left:0; margin-right:0; text-align:start\">Join us on this journey. With Festgate, your creative aspirations are just a click away.</p>','about',NULL,'','','en','all','1',NULL,'2023-07-24 19:09:35'),(8,'page','How it works','<p style=\"margin-left:0; margin-right:0; text-align:start\"><span style=\"font-size:16px\"><strong>Festgate: Empowering Filmmakers and Creators of All Kinds</strong></span></p>\r\n\r\n<p style=\"margin-left:0; margin-right:0; text-align:start\">Festgate is a free and user-friendly service designed to help filmmakers and event organizers streamline the process of submitting and receiving films or projects. Our advanced management system ensures organized submissions and a hassle-free experience.</p>\r\n\r\n<p style=\"margin-left:0; margin-right:0; text-align:start\">We offer a unique advantage: Our platform doesn&#39;t charge creators any fees to have their projects registered and ready in our database for submission to current or future events hosted on our platform.</p>\r\n\r\n<p style=\"margin-left:0; margin-right:0; text-align:start\">The only cost incurred by creators is the submission fee required by events that activate paid categories for project entry. Festgate will receive a minimal percentage of this final payment. Rest assured, Festgate will not charge any additional fees to creators.</p>\r\n\r\n<p style=\"margin-left:0; margin-right:0; text-align:start\"><strong>Why Choose Festgate?</strong></p>\r\n\r\n<ul style=\"margin-left:0; margin-right:0\">\r\n	<li>\r\n	<p style=\"margin-left:0; margin-right:0\"><strong>Unlimited Creativity</strong>: Create unlimited projects and submit Films, Videos, Scripts, Texts, Artworks, Music, and Photography to associated events.</p>\r\n	</li>\r\n	<li>\r\n	<p style=\"margin-left:0; margin-right:0\"><strong>Enhanced Visibility</strong>: Boost your exposure with our optional inclusion in our movie database.</p>\r\n	</li>\r\n	<li>\r\n	<p style=\"margin-left:0; margin-right:0\"><strong>Exclusive Opportunities</strong>: Get direct invitations and discounts from event organizers.</p>\r\n	</li>\r\n</ul>\r\n\r\n<p style=\"margin-left:0; margin-right:0; text-align:start\">Embark on your creative journey with Festgate, the platform that makes your work simpler and your dreams bigger.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><span style=\"font-size:16px\"><strong>Step-by-Step Guide: Creating and Submitting a Project to a Festival or Event</strong></span></p>\r\n\r\n<ol style=\"margin-left:0; margin-right:0\">\r\n	<li>\r\n	<p style=\"margin-left:0; margin-right:0\"><strong>Registration</strong>: To embark on your creative journey, you first need to register as a creator on our platform through our form at: <a href=\"https://festgate.com/register\" style=\"border: 0px solid rgb(217, 217, 227); box-sizing: border-box; --tw-border-spacing-x: 0; --tw-border-spacing-y: 0; --tw-translate-x: 0; --tw-translate-y: 0; --tw-rotate: 0; --tw-skew-x: 0; --tw-skew-y: 0; --tw-scale-x: 1; --tw-scale-y: 1; --tw-pan-x: ; --tw-pan-y: ; --tw-pinch-zoom: ; --tw-scroll-snap-strictness: proximity; --tw-gradient-from-position: ; --tw-gradient-via-position: ; --tw-gradient-to-position: ; --tw-ordinal: ; --tw-slashed-zero: ; --tw-numeric-figure: ; --tw-numeric-spacing: ; --tw-numeric-fraction: ; --tw-ring-inset: ; --tw-ring-offset-width: 0px; --tw-ring-offset-color: #fff; --tw-ring-color: rgba(69,89,164,.5); --tw-ring-offset-shadow: 0 0 transparent; --tw-ring-shadow: 0 0 transparent; --tw-shadow: 0 0 transparent; --tw-shadow-colored: 0 0 transparent; --tw-blur: ; --tw-brightness: ; --tw-contrast: ; --tw-grayscale: ; --tw-hue-rotate: ; --tw-invert: ; --tw-saturate: ; --tw-sepia: ; --tw-drop-shadow: ; --tw-backdrop-blur: ; --tw-backdrop-brightness: ; --tw-backdrop-contrast: ; --tw-backdrop-grayscale: ; --tw-backdrop-hue-rotate: ; --tw-backdrop-invert: ; --tw-backdrop-opacity: ; --tw-backdrop-saturate: ; --tw-backdrop-sepia: ; color: var(--tw-prose-links); text-decoration: underline; font-weight: 500; text-underline-offset: 2px;\" target=\"_new\">FestGate Registration</a>.</p>\r\n	</li>\r\n	<li>\r\n	<p style=\"margin-left:0; margin-right:0\"><strong>Project Creation</strong>: After registration, you&#39;ll gain access to the control panel. Here, you can create your project by selecting the &quot;My Projects&quot; option. You have the ability to create different types of projects such as Film Video, Script, Artwork, Music, and Photography.</p>\r\n	</li>\r\n	<li>\r\n	<p style=\"margin-left:0; margin-right:0\"><strong>Filling in Project Details</strong>: When setting up your new project, you&#39;ll need to complete a form with all necessary information. Once filled out, you can save and view it in the &quot;show&quot; section of the project list. Here, you can attach links from Vimeo or YouTube for your film or video. For a script, you can upload your written work in PDF format, for music, upload your piece in WAV or MP3 format, and for Artworks or Photography, simply upload the corresponding image. Don&#39;t forget to add a poster and some images to round out your project profile. If the link to your Film or Video is password-protected, be sure to fill out the &quot;password&quot; field. This will allow the jurors of the events you&#39;re submitting to, to access and evaluate your work.</p>\r\n	</li>\r\n	<li>\r\n	<p style=\"margin-left:0; margin-right:0\"><strong>Submitting your Project to an Event or Festival</strong>: Navigate to the &quot;Festivals and Events&quot; section on our platform and choose the event that interests you. On the event&#39;s page, you can submit your project within the deadlines specified in the dropdown categories available on the right-hand side of the page. If you don&#39;t see any deadlines, it might be because they&#39;ve already passed or are not currently active for the event.</p>\r\n	</li>\r\n	<li>\r\n	<p style=\"margin-left:0; margin-right:0\"><strong>Project Submission</strong>: Select the category or categories in which you want your work to participate, add them to your cart and finalize the submission. Be sure to look out for discount coupons provided by the event. For paid categories, you can pay via debit or credit card through Stripe. Your data will be secure as our system only displays an iFrame and all payment processing takes place on Stripe&#39;s servers.</p>\r\n	</li>\r\n	<li>\r\n	<p style=\"margin-left:0; margin-right:0\"><strong>Confirmation and Tracking of the Project</strong>: After completing the transaction, you&#39;ll receive a confirmation message. You can check the status of your submission in the &quot;My Submissions&quot; section. As the jurors or selectors of the event update the status of your submission, we&#39;ll send you an email with the corresponding information.</p>\r\n	</li>\r\n</ol>\r\n\r\n<p style=\"margin-left:0; margin-right:0; text-align:start\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; We&#39;re excited to see your creations and wish you the utmost success at the events!</p>\r\n\r\n<p style=\"margin-left:0; margin-right:0; text-align:start\">&nbsp;</p>\r\n\r\n<hr />\r\n<p><span style=\"font-size:14px\">For any doubt or question you can write to us at contact@festgate.com</span></p>','how-it-works',NULL,'','','en','all','1',NULL,'2023-07-24 18:50:13'),(9,'page','Cookies Policy','<p><strong>Cookie Policy</strong><br />\r\n<br />\r\nUpdated at 2021-09-24<br />\r\n<br />\r\n<br />\r\n<strong>Definitions and key terms</strong><br />\r\n<br />\r\nTo help explain things as clearly as possible in this Cookie Policy, every time any of these terms are referenced, are strictly defined as:</p>\r\n\r\n<ul>\r\n	<li>Cookie: small amount of data generated by a website and saved by your web browser. It is used to identify your browser, provide analytics, remember information about you such as your language preference or login information.</li>\r\n	<li>Company: when this policy mentions &ldquo;Company,&rdquo; &ldquo;we,&rdquo; &ldquo;us,&rdquo; or &ldquo;our,&rdquo; it refers to Festgate, that is responsible for your information under this Cookie Policy.</li>\r\n	<li>Device: any internet connected device such as a phone, tablet, computer or any other device that can be used to visit Festgate and use the services.</li>\r\n	<li>Personal Data: any information that directly, indirectly, or in connection with other information &mdash; including a personal identification number &mdash; allows for the identification or identifiability of a natural person.</li>\r\n	<li>Service: refers to the service provided by Festgate as described in the relative terms (if available) and on this platform.</li>\r\n	<li>Third-party service: refers to advertisers, contest sponsors, promotional and marketing partners, and others who provide our content or whose products or services we think may interest you.</li>\r\n	<li>Website: site, which can be accessed via this URL: <a href=\"https://festgate.com\">https://festgate.com</a></li>\r\n</ul>\r\n\r\n<p><br />\r\n<strong>Introduction</strong><br />\r\n<br />\r\nThis Cookie Policy explains how Festgate and its affiliates (collectively &quot;Festgate&quot;, &quot;we&quot;, &quot;us&quot;, and &quot;ours&quot;), use cookies and similar technologies to recognize you when you visit our website/app, including without limitation <a href=\"https://festgate.com\">https://festgate.com</a> and any related URLs, mobile or localized versions and related domains / sub-domains (&quot;Websites&quot;). It explains what these technologies are and why we use them, as well as the choices for how to control them.<br />\r\n<br />\r\n<br />\r\n<strong>What is a cookie?</strong><br />\r\n<br />\r\n<br />\r\nA cookie is a small text file that is stored on your computer or other internet connected device in order to identify your browser, provide analytics, remember information about you such as your language preference or login information. They&#39;re completely safe and can&#39;t be used to run programs or deliver viruses to your device.<br />\r\n<br />\r\nWhy do we use cookies?<br />\r\n<br />\r\nWe use first party and/or third party cookies on our website/app for various purposes such as:</p>\r\n\r\n<ul>\r\n	<li>To facilitate the operation and functionality of our website/app;</li>\r\n	<li>To improve your experience of our website/app and make navigating around them quicker and easier;</li>\r\n	<li>To allow us to make a bespoke user experience for you and for us to understand what is useful or of interest to you;</li>\r\n	<li>To analyze how our website/app is used and how best we can customize it;</li>\r\n	<li>To identify future prospects and personalize marketing and sales interactions with it;</li>\r\n	<li>To facilitate the tailoring of online advertising to your interests.</li>\r\n	<li>You: a person or entity that is registered with Festgate to use the Services.</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><br />\r\n<strong>What type of cookies does Festgate use?</strong><br />\r\n<br />\r\nCookies can either be session cookies or persistent cookies. A session cookie expires automatically when you close your browser. A persistent cookie will remain until it expires or you delete your cookies. Expiration dates are set in the cookies themselves; some may expire after a few minutes while others may expire after multiple years. Cookies placed by the website you&rsquo;re visiting are called &ldquo;first party cookies&rdquo;.<br />\r\nStrictly Necessary cookies are necessary for our website/app to function and cannot be switched off in our systems. They are essential in order to enable you to navigate around the website/app and use its features. If you remove or disable these cookies, we cannot guarantee that you will be able to use our website/app.<br />\r\n<br />\r\n<br />\r\n<strong>Essential Cookies</strong><br />\r\n<br />\r\nWe use essential cookies to make our website/app work. These cookies are strictly necessary to enable core functionality such as security, network management, your cookie preferences and accessibility. Without them you wouldn&#39;t be able to use basic services. You may disable these by changing your browser settings, but this may affect how the Websites function.<br />\r\n<br />\r\n<br />\r\n<strong>Performance and Functionality Cookies</strong><br />\r\n<br />\r\nThese cookies are used to enhance the performance and functionality of our website/app but are non-essential to their use. However, without these cookies, certain functionality like videos may become unavailable or you would be required to enter your login details every time you visit the website/app as we would not be able to remember that you had logged in previously.<br />\r\n<br />\r\n<br />\r\n<strong>Analytics and Customization Cookies</strong><br />\r\n<br />\r\nThese cookies collect information that is used to help us understand how our website/app is being used or how effective our marketing campaigns are, or to help us customize our website/app for you.<br />\r\n<br />\r\nWe use cookies served by Google Analytics to collect limited data directly from end-user browsers to enable us to better understand your use of our website/app. Further information on how Google collects and uses this data can be found at: https://www.google.com/policies/privacy/partners/. You can opt-out of all Google supported analytics on our Websites by visiting: https://tools.google.com/dlpage/gaoptout.<br />\r\n<br />\r\n<br />\r\n<strong>Advertising Cookies</strong><br />\r\n<br />\r\nThese cookies collect information over time about your online activity on the website/app and other online services to make online advertisements more relevant and effective to you. This is known as interest-based advertising. They also perform functions like preventing the same ad from continuously reappearing and ensuring that ads are properly displayed for advertisers. Without cookies, it&rsquo;s really hard for an advertiser to reach its audience, or to know how many ads were shown and how many clicks they received.<br />\r\n<br />\r\n<br />\r\n<strong>Third Party Cookies</strong><br />\r\n<br />\r\nSome cookies that have been set on our website/app are not set on a first party basis by Festgate. The Websites can be embedded with content from third parties to serve advertising. These third party service providers may set their own cookies on your web browser. Third party service providers control many of the performance and functionality, advertising, marketing and analytics cookies described above. We do not control the use of these third party cookies as cookies can only be accessed by the third party that originally set them.<br />\r\n<br />\r\n<br />\r\n<strong>How you can manage cookies?</strong><br />\r\n<br />\r\nMost browsers allow you to control cookies through their &#39;settings&#39; preferences. However, if you limit the ability of websites to set cookies, you may worsen your overall user experience, since it will no longer be personalized to you. It may also stop you from saving customized settings like login information. Browser manufacturers provide help pages relating to cookie management in their products.<br />\r\nBrowser manufacturers provide help pages relating to cookie management in their products. Please see below for more information.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ul>\r\n	<li>Google Chrome</li>\r\n	<li>Internet Explorer</li>\r\n	<li>Mozilla Firefox</li>\r\n	<li>Safari (Desktop)</li>\r\n	<li>Safari (Mobile)</li>\r\n	<li>Android Browser</li>\r\n	<li>Opera</li>\r\n	<li>Opera Mobile</li>\r\n</ul>\r\n\r\n<p><br />\r\n<strong>Blocking and disabling cookies and similar technologies</strong><br />\r\n<br />\r\nWherever you&#39;re located you may also set your browser to block cookies and similar technologies, but this action may block our essential cookies and prevent our website from functioning properly, and you may not be able to fully utilize all of its features and services. You should also be aware that you may also lose some saved information (e.g. saved login details, site preferences) if you block cookies on your browser. Different browsers make different controls available to you. Disabling a cookie or category of cookie does not delete the cookie from your browser, you will need to do this yourself from within your browser, you should visit your browser&#39;s help menu for more information.<br />\r\n<br />\r\n<strong>How to Delete Cookies</strong><br />\r\n<br />\r\nHere are the steps for deleting cookies from modern web browsers.<br />\r\n<br />\r\n<em>How to delete cookies on Google Chrome (Windows)</em></p>\r\n\r\n<ol>\r\n	<li>Open the menu from the top right (three dots)</li>\r\n	<li>Click Settings</li>\r\n	<li>Click Privacy and security</li>\r\n	<li>Click Clear browsing data</li>\r\n	<li>Select either Basic or Advanced</li>\r\n	<li>Click Clear data</li>\r\n</ol>\r\n\r\n<p><em>How to delete cookies on Edge (Windows)</em></p>\r\n\r\n<ol>\r\n	<li>Open the Menu (three dots)</li>\r\n	<li>Click Settings</li>\r\n	<li>Click Privacy and services</li>\r\n	<li>Click Choose what to clear at the Clear browsing data</li>\r\n	<li>Make your selection</li>\r\n	<li>Click Clear now</li>\r\n</ol>\r\n\r\n<p><em>How to delete cookies on Mozilla Firefox (Windows)</em></p>\r\n\r\n<ol>\r\n	<li>Click the Menu (three lines)</li>\r\n	<li>Click Options</li>\r\n	<li>Click Privacy &amp; Security</li>\r\n	<li>Go to the Cookies and Site Data section</li>\r\n	<li>Click Clear Data</li>\r\n</ol>\r\n\r\n<p><em>How to delete cookies on Opera (Windows)</em></p>\r\n\r\n<ol>\r\n	<li>Click Settings</li>\r\n	<li>Click Advanced</li>\r\n	<li>Click Privacy &amp; security</li>\r\n	<li>Click Clear browsing data</li>\r\n	<li>Click Clear data after selecting either Basic or Advanced</li>\r\n</ol>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><br />\r\n<strong>Changes To Our Cookie Policy</strong><br />\r\n<br />\r\nWe may change our Service and policies, and we may need to make changes to this Cookie Policy so that they accurately reflect our Service and policies. Unless otherwise required by law, we will notify you (for example, through our Service) before we make changes to this Cookie Policy and give you an opportunity to review them before they go into effect. Then, if you continue to use the Service, you will be bound by the updated Cookie Policy. If you do not want to agree to this or any updated Cookie Policy, you can delete your account.<br />\r\n<br />\r\n<br />\r\n<strong>Your Consent</strong><br />\r\n<br />\r\nBy using our website/app, registering an account, or making a purchase, you hereby consent to our Cookie Policy and agree to its terms.<br />\r\n<br />\r\n<br />\r\n<br />\r\n<strong>Contact Us</strong><br />\r\n<br />\r\nDon&#39;t hesitate to contact us if you have any questions regarding our Cookie Policy.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ul>\r\n	<li>Via Email: webmaster@festgate.com or festgatellc@gmail.com</li>\r\n</ul>','cookies',NULL,'Page Cookies Policy','cookies, policy','en','all','1',NULL,'2023-07-24 20:26:59'),(39,'page','Payment Methods','<p style=\"margin-left:0; margin-right:0; text-align:start\"><span style=\"font-size:16px\"><strong>Payment Methods</strong></span></p>\r\n\r\n<p style=\"margin-left:0; margin-right:0; text-align:start\">At Festgate, we prioritize the security and convenience of our users. For paid categories, we currently facilitate payments through Stripe, a globally recognized and trusted payment processing service.</p>\r\n\r\n<p style=\"margin-left:0; margin-right:0; text-align:start\">When you proceed to make a payment, an iFrame is displayed, which is a secure window directly connecting to Stripe&#39;s servers. This window allows you to enter your credit or debit card details directly onto Stripe&#39;s secure platform.</p>\r\n\r\n<p style=\"margin-left:0; margin-right:0; text-align:start\">Please note that the entire payment process, from data input to final transaction, is executed on Stripe&#39;s servers. Stripe adheres to the highest standards of security compliance, ensuring that your sensitive card information is always protected.</p>\r\n\r\n<p style=\"margin-left:0; margin-right:0; text-align:start\">Importantly, Festgate does not store any of your card information on our servers. Our system is designed such that we handle the facilitation of the payment process while leaving the data security and transaction handling to the experts at Stripe.</p>\r\n\r\n<p style=\"margin-left:0; margin-right:0; text-align:start\">Looking forward, we aim to expand our payment methods to include PayPal and various cryptocurrencies to provide you with a wider range of options.</p>\r\n\r\n<p style=\"margin-left:0; margin-right:0; text-align:start\">As for the payment of fees to events, this is carried out monthly, either by bank transfer or via PayPal. Please note that Stripe does charge a transaction fee, which is deducted from each fee payment.</p>\r\n\r\n<p style=\"margin-left:0; margin-right:0; text-align:start\">Our method offers you a safe, efficient, and worry-free payment experience, allowing you to focus on what truly matters &ndash; showcasing your creativity and passion.</p>','payment-methods',NULL,NULL,NULL,'en','all','1',NULL,'2023-07-24 18:59:18');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES ('ivanlowenberg@gmail.com','$2y$10$TA9KN0LV9XavlqHAbYb4nuOYc6gfU.dw3FcTO1/EZoY8iBfM7mkcS','2023-07-26 13:37:20'),('barrihans709@gmail.com','$2y$10$7GWglIJTDiaGraKLpfnMtO3YhHHs9SHkMhDkIwWsu8mdLaW11Q6hG','2024-04-14 14:23:38'),('aikenstommy1986@yahoo.com','$2y$10$2yX7h7Ljb6hmuZ/1UWjOc.aCJpccb3COxgOpD2J9lf27HQ4IlQsMq','2024-04-16 02:04:14'),('edrislacy@outlook.com','$2y$10$1IGwa9AxzE2fQG7yogw2fOki.i5/ulhY6B0RkqoycO9O5EbBqSHbO','2024-04-19 08:48:51'),('arey7zll@outlook.com','$2y$10$NkKN/PYqerJcXq6s.mg28u2vOGPtmzsgZ5zLjcaYQu3Iuo61f4VSi','2024-04-20 22:31:55'),('horasni1982@gmail.com','$2y$10$QnVsBPKfXSYacRVrObgW4ukDMazBga7jJ1z4UiXNm0ggTUkAEjGyC','2024-05-13 23:06:01'),('olson.tammy751213@aol.com','$2y$10$kK8kWzvcaoT6bVULtnWPtedMyubv2VjGieC6frdfmRR5iwZcDABcS','2024-05-22 07:55:16'),('elizabeth.gottschalk1988@yahoo.com','$2y$10$F6NT8yXcF5Ptw7s6FPtjN.MK97Hc44j1wpU2smjqXANUnWqutgjC.','2024-05-25 18:26:42'),('karinortx360@gmail.com','$2y$10$q8vnpr3a05QQbtWJyCJ8Q.Qh3aLZ8vPofKdkOMYXkPMFm9BFCU2Zu','2024-06-04 18:15:13'),('wfredaexw159o8i23@outlook.com','$2y$10$R/16YQt4xy8sLNi.dXcJc.A0OTU77kRw.b4sa8rMeqB.lTy2pxUni','2024-06-21 17:13:58'),('wt41sbp21rqcthr@yahoo.com','$2y$10$a0a4Qd/YCTIfBfLTkp7c6O400JdTqM7GjHahOJ.seeyFFUmQks/iu','2024-10-30 17:52:44'),('gnmvxxx0cr@yahoo.com','$2y$10$/PU55Wq86Tk0eMp5Oh8KWe0QyCvkzQvTjEnm3O2vgl9/2pUxU/pxK','2024-11-09 23:47:45'),('rejucqinwtf@yahoo.com','$2y$10$nzBITKNAhLAbb4dOW7c6v.bc5aZaN959cwPxJh6n7f8T6IHL5dEkO','2024-11-18 01:10:13'),('goitinh.1980@yahoo.com','$2y$10$RTvLQHIi3Q5P4jZpcR0.vO2if2qGgZXK6vOsqy./d4ieAnGfqCuS.','2024-11-21 02:29:21'),('mashate_said@yahoo.com','$2y$10$yy/OIhxo9dEWQiWmUqLkL.dGRGept1F.nyrPgjK/HKi24oiKToZyK','2024-11-22 08:42:57'),('ycyvxpnkuycp@yahoo.com','$2y$10$muJll9btE10Bex2Osvqjt.25a0Gr7yuBaXrsgL4lwYvzrEiZj5YQK','2024-11-27 20:08:55'),('prtgkkksvk@yahoo.com','$2y$10$nv6G71qmupTd0Ss5fdNeYOuC2Rqk9BuZ3jx/Krf0jVOgYM4JPJsZS','2024-12-03 08:06:35'),('lllbnwidgqeerdyi@yahoo.com','$2y$10$JhSxhslSf0fQuGCJmi6onuS9tiHq2mAoHgfhk0XV/iMB.2KOXKUTi','2024-12-04 20:02:19'),('phantomey95delveue@gmail.com','$2y$10$Q834Usm5k6Oic6pczkEWVeftYOQJKqqDpFfw0cGj/GZpT64hFqgdy','2024-12-08 07:23:06'),('henepanzki@yahoo.com','$2y$10$b8q9ilj.2MpwjXikjida6uzGW69MLhBYDuGq/tZ0RoiyNHZ3DItt2','2024-12-11 04:50:29'),('adisonlevine4@gmail.com','$2y$10$jil5KMKRVzRab61FgJKMtuRNj.zQeOk0Lr9MumhvWhItng1fJLcP.','2024-12-13 22:39:20'),('mcintoshrokiv@gmail.com','$2y$10$Kd/fd8ALLv56k3fIBTpNuenbcos/1aaYjHVJnmusIPvWUpWtDNvLu','2024-12-15 04:33:45'),('akujibemo469@gmail.com','$2y$10$AW11JSP4Xpe6bZ0bi1KbneTf2hS4WjnbVZMgFrp4ROhyv9zlEDC9G','2024-12-19 21:05:19'),('fsphtmiqp@yahoo.com','$2y$10$bt87kfdz1mhMZDhrrPun8ulTyC.dggzVrL4nNz99SDFCR5R.5kGQi','2024-12-20 20:21:21'),('tolicedu22@gmail.com','$2y$10$pRK4KvQYzDPG7befCJZsQu8cC01OQZpQbBpJGERlzf8G7sP.I8OGu','2024-12-26 20:14:42'),('dqib0huq5o@yahoo.com','$2y$10$cjdrrH3vLMo18AqmB2NM7O1LFS/dJM8BgoE8QDJY2LcavLc9narfO','2025-01-04 05:47:35'),('batilderickson@gmail.com','$2y$10$0UIyl96YWsuwJeb0g1yiWOBd/1kRSIbStUJm5J2pukvMTl9HK6sPG','2025-01-14 15:46:21'),('cykbevnjtmlpqy@yahoo.com','$2y$10$kmAv87ASdjBpl/TGuYB/pOgdm0TKDwHIiCvrqlw6N.GgR9rnzMWlK','2025-01-15 19:43:52'),('mementooonexus@gmail.com','$2y$10$3Oo9/2j2Y3xMLtBZ5bSi.evQW0WjcfKfHFI5LS6e45tcwr67w.6N2','2025-01-15 23:04:20'),('crescenteorift@gmail.com','$2y$10$AUiUKSpHOYZpSLFmAsdnnO/HIHIn6ZCJiwRa2Kgw3y8vB4SxQ9Zuy','2025-01-18 15:41:42'),('hvospoim1987@gmail.com','$2y$10$L38HBcdzGu66RO0gGmqCbuI4/VUoi3QZ8Z5FnQcNm1JaUa/zy0d3y','2025-06-02 23:16:17'),('cuevasadrinna@gmail.com','$2y$10$m48VfGsz4yEK0vP3g9PIQugxhh8RzScBD6tL3qEm1sv7zZYk79lAO','2025-07-07 23:28:10'),('zixivexiqom81@gmail.com','$2y$10$1BNbsg1PsjrGO4NJA6Ancej7K5L58isQPZ/OkIuEUTttYR/044bIa','2025-07-20 15:37:57'),('ihumuzucar85@gmail.com','$2y$10$aIDTFXLHYUGb28UIDTiT4umN1Y8uAdBuGc8KsiuUfep0fPDKrwSwq','2025-08-20 07:58:50'),('efuhedoja636@gmail.com','$2y$10$zml1vquFXWIQaBMEhW6dGe69xUXECFj3W2PgegAi6Kq9qNi0gl73S','2025-08-21 00:10:20'),('oqipomowu89@gmail.com','$2y$10$ymsh73nphMRBjxe.EprHie1CTJDHgbHCMoPsc..tP0jR1qmKa3GgK','2025-08-30 01:31:26'),('meqekiyaziw59@gmail.com','$2y$10$fk09YxMIZxePJCldh7g5veGn2n.3Ru48C3NZhtqfK741LoHbdi2jO','2025-08-30 09:01:39'),('qijudonabo94@gmail.com','$2y$10$dOdCMCB05DD9b/SQ4lk8dO2nwxDZVlpzkxNuaqZ.4nV3IODmmjdua','2025-09-01 05:37:42'),('akejuyow05@gmail.com','$2y$10$qKZm4CxGNGL4Ad1lfDaU6.KeLxKwVIhc4bWFWL.8NbXB5zx8Fe2fe','2025-09-01 05:50:13'),('oveqawet24@gmail.com','$2y$10$RyrL.9vkrWBC50gjIHcm6OiJw4ZzJLuS9hXSCBbcMIxNP7v5IcDYO','2025-09-02 08:05:10'),('hoxuboni83@gmail.com','$2y$10$KZUJDN44NNzZa8qWYWJKou/ZnKRqnm/SgrT/oRe/OgoLCb1OjVAuW','2025-09-03 20:35:17'),('azefisasowo953@gmail.com','$2y$10$lYQVj9WfqCajXkdLW1zDGu1ASJuvDDAC4/1h6IG1tUr2Q90Q7oV72','2025-09-07 21:29:58'),('urutifeyaq74@gmail.com','$2y$10$Ens2irxNnovjvLlnxPdjT.0/6KjQ0yZ9Jvy64WkLWhtrE7yTuRlua','2025-09-13 08:55:59'),('cuzofop300@gmail.com','$2y$10$s.MPvszK.4S75Jec0N5BLu3NvkuB/rsS3y5./jZ0VBfnXVvYCQmkq','2025-09-13 10:34:04'),('ufaqebubiwe908@gmail.com','$2y$10$/k4rI9KLTZe5zWiICnWLy.dAMYw6yyTDgc34e1XMEwZu21p3nMxbG','2025-09-14 19:01:27'),('izayobese434@gmail.com','$2y$10$vy6GGaKQ4mqRjb15kt8Cu.XjJIQUl7Npb3KBUMsftTWrrcITU13.u','2025-09-15 05:02:56');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_accounts`
--

DROP TABLE IF EXISTS `payment_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_accounts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `provider` enum('stripe','mollie') NOT NULL,
  `provider_account_id` varchar(255) DEFAULT NULL,
  `provider_customer_id` varchar(255) DEFAULT NULL,
  `status` enum('pending','active','incomplete','restricted','disabled') NOT NULL DEFAULT 'pending',
  `charges_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `payouts_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `capabilities` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`capabilities`)),
  `requirements` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`requirements`)),
  `onboarding_url` text DEFAULT NULL,
  `connected_at` timestamp NULL DEFAULT NULL,
  `verified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payment_accounts_user_id_provider_unique` (`user_id`,`provider`),
  KEY `payment_accounts_provider_account_id_index` (`provider_account_id`),
  KEY `payment_accounts_status_index` (`status`),
  CONSTRAINT `payment_accounts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_accounts`
--

LOCK TABLES `payment_accounts` WRITE;
/*!40000 ALTER TABLE `payment_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_categories`
--

DROP TABLE IF EXISTS `project_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_categories`
--

LOCK TABLES `project_categories` WRITE;
/*!40000 ALTER TABLE `project_categories` DISABLE KEYS */;
INSERT INTO `project_categories` (`id`, `name`, `created_at`, `updated_at`) VALUES (1,'Short','2023-07-14 20:17:24','2023-07-14 20:17:24'),(2,'Feature','2023-07-14 20:17:46','2023-07-14 20:17:46'),(3,'Fiction','2023-07-20 15:00:27','2023-07-20 15:00:27'),(4,'Animation','2023-07-20 15:00:27','2023-07-20 15:00:27'),(5,'Documentary','2023-07-20 15:00:46','2023-07-20 15:00:46'),(6,'Experimental','2023-07-20 15:00:46','2023-07-20 15:00:46'),(7,'Music Video','2023-07-20 15:01:00','2023-07-20 15:01:00'),(8,'Student','2023-07-20 15:01:00','2023-07-20 15:01:00'),(9,'Television','2023-07-20 15:01:17','2023-07-20 15:01:17'),(10,'Web / New Media','2023-07-20 15:01:17','2023-07-20 15:01:17'),(11,'Screenplay','2023-07-20 15:01:51','2023-07-20 15:01:51'),(12,'Short Script','2023-07-20 15:01:51','2023-07-20 15:01:51'),(13,'Stage Play','2023-07-20 15:02:07','2023-07-20 15:02:07'),(14,'Television Script','2023-07-20 15:02:07','2023-07-20 15:02:07'),(15,'Treatment','2023-07-20 15:02:13','2023-07-20 15:02:13'),(16,'Song','2023-07-20 15:02:31','2023-07-20 15:02:31'),(17,'Film Score','2023-07-20 15:02:31','2023-07-20 15:02:31'),(18,'Lyrics Only','2023-07-20 15:02:56','2023-07-20 15:02:56'),(19,'Virtual Reality','2023-07-20 15:02:56','2023-07-20 15:02:56'),(20,'Performance','2023-07-20 15:03:09','2023-07-20 15:03:09'),(21,'Installation','2023-07-20 15:03:09','2023-07-20 15:03:09'),(22,'Game','2023-07-20 15:03:21','2023-07-20 15:03:21'),(23,'Interactive Film','2023-07-20 15:03:21','2023-07-20 15:03:21'),(24,'360 Video','2023-07-20 15:03:33','2023-07-20 15:03:33'),(25,'Augmented Reality','2023-07-20 15:03:33','2023-07-20 15:03:33'),(26,'Artwork','2023-07-20 15:03:41','2023-07-20 15:30:29'),(27,'Photography','2023-07-20 15:30:36','2023-07-20 21:27:53'),(28,'Other','2023-07-20 21:27:31','2023-07-20 21:27:31');
/*!40000 ALTER TABLE `project_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_project` varchar(50) DEFAULT NULL,
  `name` varchar(300) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `approved` int(1) NOT NULL DEFAULT 0,
  `file` text DEFAULT NULL,
  `title_year` smallint(6) DEFAULT NULL,
  `imdb` text DEFAULT NULL,
  `running_time` varchar(100) DEFAULT NULL,
  `artwork_size` varchar(255) DEFAULT NULL,
  `film_poster` text DEFAULT NULL,
  `content` text DEFAULT NULL,
  `images` text DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `is_featured` tinyint(1) NOT NULL DEFAULT 0,
  `date_finish` date DEFAULT NULL,
  `status` varchar(60) NOT NULL DEFAULT 'Running',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `synopsis` text DEFAULT NULL,
  `country_id` int(11) unsigned DEFAULT NULL,
  `country_filming_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_type` varchar(255) NOT NULL DEFAULT 'App\\Models\\User',
  `categories` text DEFAULT NULL,
  `link_video` varchar(200) DEFAULT NULL,
  `video_password` varchar(200) DEFAULT NULL,
  `director` varchar(50) DEFAULT NULL,
  `director_photo` text DEFAULT NULL,
  `screenwriter` varchar(100) DEFAULT NULL,
  `producer_film` varchar(100) DEFAULT NULL,
  `artist` varchar(255) DEFAULT NULL,
  `biography` text DEFAULT NULL,
  `web_link` text DEFAULT NULL,
  `facebook` varchar(200) DEFAULT NULL,
  `twitter` varchar(200) DEFAULT NULL,
  `instagram` varchar(200) DEFAULT NULL,
  `linkendin` varchar(200) DEFAULT NULL,
  `moderation_status` varchar(60) NOT NULL DEFAULT 'pending',
  `receive_discounts` tinyint(1) NOT NULL DEFAULT 1,
  `trailer` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=216 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` (`id`, `type_project`, `name`, `slug`, `approved`, `file`, `title_year`, `imdb`, `running_time`, `artwork_size`, `film_poster`, `content`, `images`, `location`, `is_featured`, `date_finish`, `status`, `created_at`, `updated_at`, `synopsis`, `country_id`, `country_filming_id`, `user_id`, `user_type`, `categories`, `link_video`, `video_password`, `director`, `director_photo`, `screenwriter`, `producer_film`, `artist`, `biography`, `web_link`, `facebook`, `twitter`, `instagram`, `linkendin`, `moderation_status`, `receive_discounts`, `trailer`) VALUES (38,'Film video','Ma Belle','film-ma-belle',2,'',2017,'https://www.imdb.com/name/nm4107453/','17',NULL,'iqt30tsyH4.jpg',NULL,'[]','Palma de Mallorca',0,'2017-07-25','not_available','2021-11-01 13:24:41','2023-08-11 11:41:27','<p>Michelle, una mujer obsesionada por la belleza, se ve envuelta en su propio laberinto. Un arma de doble filo que le hace transformar su leitmotiv en una obstinaci&oacute;n m&aacute;s que aterradora. Un cortometraje producido por Macarena Gomez y Antoni Caimari Caldes. Un Guion de Tery Logan</p>',199,199,4,'Botble\\RealEstate\\Models\\Account','[\"1\",\"3\",\"6\"]','https://vimeo.com/469232082',NULL,'Antoni Caimari Caldes','dr9DN8MGdd.jpg','Tery Logan','Macarena Gomez & Antoni Caimari Caldes',NULL,'<p>Antoni Caimari Cald&eacute;s 22-12-1976</p>\r\n<p>De formaci&oacute;n autodidacta.</p>\r\n<p>A la edad de 12 a&ntilde;os realiza sus primeros trabajos en escultura bajo la influencia de Jean Tinguely y David Smith. Entre 1996 y 2014 realiza m&aacute;s de 150 esculturas, 3 de ellas en emplazamientos p&uacute;blicos y una gran cantidad de pinturas, piezas musicales y fotograf&iacute;a art&iacute;stica. En 2007 empieza su vocaci&oacute;n como cineasta y hasta el momento ha realizado 17 cortometrajes y 3 largometrajes.</p>\r\n<p>Podemos destacar su &uacute;ltimo cortometraje \"Ma Belle (2017)\" protagonizado por la estrella de cine espa&ntilde;ola Macarena G&oacute;mez, que ha recibido m&aacute;s de 14 premios internacionales. Ahora mismo est&aacute; en la post-producci&oacute;n de su tercer largometraje titulado \"Walk-In\" y con la elaboraci&oacute;n del tercer cortometraje que finaliza su trilog&iacute;a sobre la obsesi&oacute;n de la belleza. En el 2018 fue nombrado director del festival de cine independiente de cine de Londres &ldquo;London International Motion Pictures Awards ( L I M P A)&rdquo; y es el creador de los festivales Films Infest (Festival de cine de autor) y Shorts In-Fest (Festival de cortometrajes de &aacute;mbito Iberoamericano) que se han celebrado en Madrid, Palma de Mallorca y Nueva York desde el 2016.</p>\r\n<p>En el 2018 funda la Asociaci&oacute;n Nacional de Cineastas y Artistas Unidos (Cine Art) (Espa&ntilde;a) como materializaci&oacute;n del Manifiesto para el est&iacute;mulo al crecimiento del cine de autor, escrito por &eacute;l y el artista pl&aacute;stico Jaume Roig de Diego como defensa y apoyo a la cultura y a los artistas de cualquier disciplina que cuentan con poco apoyo. En la primera edici&oacute;n del festival Films Infest de Palma de Mallorca, el manifiesto fue firmado y amadrinado por la gran actriz y mito internacional Claudia Cardinale.</p>\r\n<p>En ediciones posteriores del Films Infest, el manifiesto ha sido firmado por Ventura Pons y Laura Zapata. Tambi&eacute;n existe el libro de firmas de los festivales, con el apoyo de centenares de artistas internacionales.</p>\r\n<p>Enlaces de inter&eacute;s;</p>\r\n<p><a href=\"https://www.imdb.com/name/nm4107453/\">https://www.imdb.com/name/nm4107453/ </a></p>\r\n<p><a href=\"https://es.wikipedia.org/wiki/Antoni_Caimari_Cald%C3%A9s\">https://es.wikipedia.org/wiki/Antoni_Caimari_Cald%C3%A9s </a></p>\r\n<p>https://cineart.es/pages/manifiesto-artistico/</p>','https://caimari.com','https://www.facebook.com/caimari','https://twitter.com/caimaricaldes','https://www.instagram.com/acaimari/','https://www.linkedin.com/in/caimari','approved',1,'https://www.youtube.com/watch?v=UdT7FOKwYcE'),(41,'Film video','a dead sea',NULL,0,'',2021,NULL,NULL,NULL,'accounts/girl-under-water-movie-poster-8.jpg','<div class=\"Projects-sidebarHeader\" aria-role=\"heading\" role=\"heading\" readability=\"-18\"><br>&nbsp;</div><div data-press-kit-statement=\"\" readability=\"16\"><p style=\"margin-left:0px;\">This is a film written inspired by a true story that took place in Israel in the city of Jerusalem. The case of the killing of Iyad al-Khalak is an incident from May 30, 2020, in which a resident of East Jerusalem, Iyad al-Khalak, a young autistic Palestinian Arab, was shot dead by Border Police officers who suspected him of being a terrorist.<br>It was a very sad case that moved me to tears. Following this case, I decided to go into research to understand what causes a person to kill an autistic person? the lack of communication and lack of awareness are good enough reasons for such an act?<br>These and many more questions still resonate in my mind.<br>look at the link below:<br>https://en.wikipedia.org/wiki/Shooting_of_Eyad_al-Hallaq</p></div>','[\"accounts/2021-10-05-125325.png\",\"accounts/3-2.png\"]','maghar',0,'2021-10-01','Running','2021-11-11 20:56:46','2021-11-12 09:07:40','Kamel, a Palestinian man in his 50s, suffers from autism and travels with his paralyzed sister to the Dead Sea to receive medical treatment in seawater in the hope that it will help him treat psoriasis that has spread through his body.',104,104,17,'Botble\\RealEstate\\Models\\Account','0','https://vimeo.com/637519824','123456','Nahd bashir',NULL,'Nahd bashir','eyad fadil',NULL,NULL,NULL,'https://www.facebook.com/A-DEAD-SEA-108966421534888',NULL,NULL,NULL,'pending',1,NULL),(42,'Film video','Rehearsal',NULL,0,'',2020,'https://www.imdb.com/title/tt6188844/?ref_=nm_knf_i1',NULL,NULL,'accounts/updated-poster-laurels-2.jpg',NULL,'[\"accounts/5-1.jpg\",\"accounts/4-1.jpg\",\"accounts/3-1.jpg\",\"accounts/2-1.jpg\"]','Alsenblawin',0,'2020-09-01','Running','2021-11-11 21:08:40','2021-11-11 21:15:17','An actor trying to go deep into his passion , Some fears and memories trying to hinder him',63,63,16,'Botble\\RealEstate\\Models\\Account','0','https://drive.google.com/file/d/17Ar_1djA-eAG_sIK-ADUuL6TWFWBZ0Rw/view?usp=sharing',NULL,'Omar Aziz',NULL,'Omar Aziz','Omar Aziz',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',1,NULL),(43,'Film video','HOUSE OF FORTUNE',NULL,0,'',2021,'https://www.imdb.com/title/tt15809358/?ref_=ext_shr_lnk',NULL,NULL,NULL,NULL,'[\"accounts/02.jpg\",\"accounts/03.jpg\",\"accounts/04.jpg\",\"accounts/05.jpg\",\"accounts/06.jpg\",\"accounts/07.jpg\"]','tehran',0,'2021-02-27','not_available','2021-11-11 21:16:38','2021-11-11 21:16:38','Rahil mohajer was buried alive by her husband and her father on her wedding night because they thought she wasn\'t a virgin.',101,101,18,'Botble\\RealEstate\\Models\\Account','0','https://drive.google.com/file/d/1Mf7pB14ly9A6SpEzTTInr5xNfDIckYds/view?usp=sharing',NULL,'adel mashoori',NULL,'nassim afsharpor','alireza mashooori',NULL,NULL,NULL,NULL,NULL,'https://www.instagram.com/houseoffortuneshortfilm/',NULL,'pending',1,NULL),(46,'Film video','Mi alma en tus manos',NULL,0,'',2021,NULL,NULL,NULL,'accounts/mi-alma-en-tus-manos-presentacion.jpeg','<p>-</p>','[]','Acapulco',0,'2021-09-06','not_available','2021-11-12 20:53:08','2021-11-12 21:40:02','La desgracia llega a la vida de Carlos y al pasar unos años un extraño llega a su casa en una noche tormentosa.',140,140,22,'Botble\\RealEstate\\Models\\Account','0',NULL,NULL,'Carlos Mateus',NULL,'Carlos M Mateus','High Entertainment Filma',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',1,NULL),(47,'Film video','Encuentro',NULL,0,'',2019,'https://www.imdb.com/name/nm3280256',NULL,NULL,NULL,NULL,NULL,NULL,0,'2019-10-24','not_available','2021-11-12 23:14:00','2021-11-12 23:18:56','Araceli takes care of her lifetime partner Lulu. Julian, a teenager exploring his identity, lives under the watch of his conservative mother. A sudden event will draw an unexpected path between the old couple and Julian.',140,140,24,'Botble\\RealEstate\\Models\\Account','0','https://vimeo.com/345136929','holahola','Ivan Lowenberg',NULL,'Ivan Lowenberg','Ivan Lowenberg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',1,NULL),(48,'Film video','Esmeralda',NULL,0,'',2021,'https://www.imdb.com/title/tt15040618/?ref_=nm_knf_t1',NULL,NULL,'accounts/poster-esmeralda-logonuevo-page-0001-min.jpg','<p>Password Film: &nbsp;<span style=\"background-color:rgb(255,255,255);color:rgb(34,34,34);font-family:Arial, Helvetica, sans-serif;\"><span>EternoEnamorado08&nbsp; &nbsp;</span></span></p>','[\"accounts/12.jpg\",\"accounts/1-2.jpg\",\"accounts/2-2.jpg\",\"accounts/3-3.jpg\",\"accounts/4-2.jpg\",\"accounts/5-2.jpg\",\"accounts/6-1.jpg\",\"accounts/7-1.jpg\",\"accounts/9-1.jpg\",\"accounts/11.jpg\"]','Hermosillo',0,'2021-04-13','Running','2021-11-13 18:56:20','2021-11-13 19:13:37','About 30 years ago in the city of Hermosillo, a man saw the reflection of his past on a mannequin in a wedding dress store. Little by little, we will enter this world whose reality depends on the side from which the crystal is viewed.',140,140,25,'Botble\\RealEstate\\Models\\Account','0','https://vimeo.com/541422919',NULL,'Samantha Orozco/ co-director:Francisco Machado',NULL,'Samantha Orozco','Francisco Machado',NULL,NULL,NULL,'https://www.facebook.com/esmeraldacortometraje',NULL,'@estudio651',NULL,'pending',1,NULL),(49,'Film video','Blood Skin',NULL,0,'',2021,NULL,NULL,NULL,NULL,'<p class=\"MsoNormal\" style=\"line-height:normal;margin-bottom:.0001pt;\"><span style=\"color:black;\"><b><span style=\"font-family:&quot;Times New Roman&quot;,serif;font-size:20.0pt;mso-ascii-theme-font:major-bidi;mso-bidi-language:FA;mso-bidi-theme-font:major-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:major-bidi;\" lang=\"EN-GB\"><strong>The reason for making the film:</strong></span></b></span></p><p class=\"MsoNormal\" style=\"line-height:normal;margin-bottom:.0001pt;\">&nbsp;</p><p class=\"MsoNormal\" style=\"line-height:normal;margin-bottom:.0001pt;\"><span style=\"color:black;\"><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">The Khi</span><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-language:FA;mso-bidi-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">n poost&nbsp;</span><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">ceremony is specific to the Lor region of the Zagros. This Iranian tribe has always been a farmer and rancher and changed their lands with summer and winter.</span></span></p><p class=\"MsoNormal\" style=\"line-height:normal;margin-bottom:.0001pt;\"><span style=\"color:black;\"><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">Due to the instability and mountainous areas of this land, science and knowledge have become less popular among them. Also, the governments did not take measures to address their health and medical deficiencies</span><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-language:FA;mso-bidi-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">&nbsp;</span><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" dir=\"RTL\" lang=\"AR-SA\">؛</span><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">Therefore, they were obliged to provide their food and medicine from the same facilities and medicinal plants of the mountains.</span></span></p><p class=\"MsoNormal\" style=\"line-height:normal;margin-bottom:.0001pt;\"><span style=\"color:black;\"><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">Among these tribes, some personalities infiltrated traditional medicine and tried and mistaken the treatment of people with plants.</span></span></p><p class=\"MsoNormal\" style=\"line-height:normal;margin-bottom:.0001pt;\"><span style=\"color:black;\"><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">This philosophy has had its customs in different tribes according to the specific vegetation of the same region.</span></span></p><p class=\"MsoNormal\" style=\"line-height:normal;margin-bottom:.0001pt;\"><span style=\"color:black;\"><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">The ritual of treachery has arisen from the heart of these events, albeit with a spice of superstition that is invented with these ceremonies.</span></span></p><p class=\"MsoNormal\" style=\"line-height:normal;margin-bottom:.0001pt;\"><span style=\"color:black;\"><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">Usually, people who fell from the mountain, people who were injured in fights and conflicts were very common at that time.</span></span><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-language:FA;mso-bidi-theme-font:minor-bidi;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">&nbsp;</span><span style=\"color:black;\"><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">Diseases such as jaundice, infection, snakebite and what was incurable among the people at that time were used to cure those people.</span></span></p><p class=\"MsoNormal\" style=\"line-height:normal;margin-bottom:.0001pt;\"><span style=\"color:black;\"><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">With the advent of technology and the migration of more of these people to the city and the advancement of medical science in Iran, these ceremonies have gradually faded.</span></span></p><p class=\"MsoNormal\" style=\"line-height:normal;margin-bottom:.0001pt;\"><span style=\"color:black;\"><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">So that the new generation of Iran has no knowledge of these ceremonies, so I, the filmmaker, considered it necessary to portray one of the traditional and therapeutic ceremonies of this border and region so that what our pasts inherited so that we can remember them well.</span></span></p><p class=\"MsoNormal\" style=\"line-height:85%;margin-bottom:.0001pt;\">&nbsp;</p><p class=\"MsoNormal\" style=\"line-height:85%;margin-bottom:.0001pt;\"><b><span style=\"font-family:&quot;Times New Roman&quot;,serif;font-size:20.0pt;line-height:85%;mso-ascii-theme-font:major-bidi;mso-bidi-language:FA;mso-bidi-theme-font:major-bidi;mso-hansi-theme-font:major-bidi;\" lang=\"EN-GB\"><strong>Terms of making the films:</strong></span></b></p><p class=\"MsoNormal\" style=\"line-height:85%;margin-bottom:.0001pt;\">&nbsp;</p><p class=\"MsoNormal\" style=\"line-height:normal;margin-bottom:.0001pt;\"><span style=\"color:black;\"><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">The ceremony was held in Bibi Zuleikhaei village of Kohgiluyeh and Boyer-Ahmad provinces.</span></span></p><p class=\"MsoNormal\" style=\"line-height:normal;margin-bottom:.0001pt;\"><span style=\"color:black;\"><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">The characters of the story are all real, and this ceremony, considering that it was made during the days of Covid 19\'s illness, each stage</span><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-language:FA;mso-bidi-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">&nbsp;</span><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">was depicted separately and for many days with few hours.</span></span></p><p class=\"MsoNormal\" style=\"line-height:normal;margin-bottom:.0001pt;\">&nbsp;</p><p class=\"MsoNormal\" style=\"line-height:normal;margin-bottom:.0001pt;\"><span style=\"color:black;\"><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">Mr. Ali Dad Peykari, the main character of the story, continues to do so and considers this method of treatment to be the most valuable of its kind, so that at this old age he is not willing to accept new treatment methods and continues to do so.</span></span></p><p class=\"MsoNormal\" style=\"line-height:normal;margin-bottom:.0001pt;\"><span style=\"color:black;\"><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">To attract the attention of this traditional healer, we asked many local people to cooperate so that this persuaded doctor would come in front of our camera.</span></span></p><p class=\"MsoNormal\" style=\"line-height:normal;margin-bottom:.0001pt;\"><span style=\"color:black;\"><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">During filming, we had to spend hours grazing to get this person to accept us at certain times.</span></span></p><p class=\"MsoNormal\" style=\"line-height:normal;margin-bottom:.0001pt;\"><span style=\"color:black;\"><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">The director may have decided to give up more than a hundred times, but each time a glimmer of hope appeared and dissuaded him.</span></span></p><p class=\"MsoNormal\" style=\"line-height:normal;margin-bottom:.0001pt;\"><span style=\"color:black;\"><span style=\"font-family:&quot;Arial&quot;,sans-serif;font-size:18.0pt;mso-ascii-theme-font:minor-bidi;mso-bidi-font-family:Arial;mso-bidi-theme-font:minor-bidi;mso-fareast-font-family:Arial;mso-hansi-theme-font:minor-bidi;\" lang=\"EN-GB\">Due to the traditional nature of this ceremony, we tried to choose the music from the heart of this ceremony and from the women of this country who deal with local blood singing. Although many sounds were recorded, they disappeared during editing.</span></span></p>','[\"accounts/img-1023-1.JPG\",\"accounts/img-e1019.JPG\",\"accounts/img-e1018-1.JPG\",\"accounts/photo1629655877.jpeg\",\"accounts/img-e1020-1.JPG\"]','Dehdasht',0,'2021-10-29','Filming','2021-11-14 08:58:10','2021-11-14 08:58:10','A mother and her sick son go to a local doctor to treat their child after doctors in big cities are disappointed with his treatment, and the local doctor asks him to perform a special ceremony called Khin poost (Blood Skin)',101,101,31,'Botble\\RealEstate\\Models\\Account','0','https://vimeo.com/638656178','Ebad123!','Ebad Adibpour',NULL,'Ebad Adibpour','Ebad Adibpour',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',1,NULL),(50,'Film video','Asam',NULL,0,'',2019,NULL,NULL,NULL,'accounts/zajpg.jpg','<p class=\"MsoNormal\" style=\"direction:ltr;line-height:150%;text-align:justify;unicode-bidi:embed;\"><b><span style=\"font-size:12.0pt;line-height:150%;\"><strong>The cause of the movie</strong></span>\r\n	\r\n	<span style=\"font-family:\"Arial\",sans-serif;font-size:12.0pt;line-height:150%;mso-ascii-font-family:Calibri;mso-ascii-theme-font:minor-latin;mso-hansi-font-family:Calibri;mso-hansi-theme-font:minor-latin;\" dir=\"RTL\" lang=\"FA\"><strong>:</strong></span>\r\n	\r\n	</b></p>\r\n	\r\n	<p class=\"MsoNormal\" style=\"direction:ltr;line-height:150%;text-align:justify;unicode-bidi:embed;\"><span style=\"font-size:12.0pt;line-height:150%;\">This narrative narrates the story of the late 1970s in Iran. In the villages poverty and lack of access to the city, life was very difficult. The only person who could travel to these villages were teachers, who used motorcycles because of the lack of roads. Children always have great aspirations, but these children could not see any technology, and could not be imagined, because of their lack of communication with the outside world. The umbrella was the only technology that the teacher brought to the village where the children could imagine it in their intellectual world. One child more than anyone else because he was the only man in the family, he loved the umbrella, thinking that all the bitterness would end with the story. At the end of the film, we happily saw the village people who continue to repeat their path, curvature and curvature. One of the reasons for making a film is the depiction of missing children\'s wishes, which today are faced with an emotional crisis in the family, greed, lack of use of these facilities and the ability to understand the right way of life</span>\r\n	\r\n	<span style=\"font-family:\"Arial\",sans-serif;font-size:12.0pt;line-height:150%;mso-ascii-font-family:Calibri;mso-ascii-theme-font:minor-latin;mso-hansi-font-family:Calibri;mso-hansi-theme-font:minor-latin;\" dir=\"RTL\" lang=\"FA\">.</span>\r\n	\r\n	</p>\r\n	\r\n	</undefined>','[\"accounts\\/sdjpg.jpg\",\"accounts\\/img-20180322-131929.jpg\"]','Dehdasht',0,'2019-06-10','Filming','2021-11-14 10:06:04','2021-11-14 10:06:25','An alone child without shelter,\r\n consider his teacher\'s umbrella the best shelter\r\nand he tries to achieve it.\r\nThe cause of the movie:',101,101,31,'Botble\\RealEstate\\Models\\Account','0','http://yekupload.ir/d97651ebc11b30cc/Asam.mp4',NULL,'Ebad Adibpour',NULL,'Ebad Adibpour','Ebad Adibpour',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',1,NULL),(51,'Film video','Six Home',NULL,0,'',2017,NULL,NULL,NULL,NULL,'<p>The cause of the film:<br>I am the child of my war. It\'s always a concern for children who unconsciously come into play with older adults who are incompletely enlarged. This pain has always been with me. These children are going to follow their path to the world they like but can they choose the route? Do our children know or can they make their own path?<br>Movie conditions:<br>The film was made in a mountainous region in an abandoned village. Beside this village there is a large river, on which there was no bridge for navigation. I had to use several young people to transfer cast and equipment because the water flow was so sharp that it could not be used as an ass or mule. Indigenous people knew the tracks that could flow through these waters. When we got there, it was spring, and the rain began to rain. We had to stay there for a week. Mobile phones were not installed and the indigenous people had gone before us. The gamblers were amateur and were fidgeting because their patrons were not behind them. We had to consume less food. Because of the fact that they were not familiar with such environments, the actors suffered from difficult exercises during the intensive exercises, and they were also in trouble. Due to the rugged path of a few people during filming. Also, a shotgun hit the water and a local person was charged with water and provided us with broken supplies.<br>&nbsp;</p>','[\"accounts/z-1.jpg\"]','Dehdasht',0,'2017-03-21','Filming','2021-11-14 10:16:21','2021-11-14 10:16:21','Many girls are playing and ...',101,101,31,'Botble\\RealEstate\\Models\\Account','0','https://www.dropbox.com/preview/Ebad%20Adibpour/Six%20Home.MP4',NULL,'Ebad Adibpour',NULL,'Mohammad Salimirad','Ebad Adibpour',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',1,NULL),(52,'Film video','N-Mare',NULL,0,'',2021,NULL,NULL,NULL,NULL,'<p style=\"margin-left:0px;\"><strong>Director\'s statement about abstract references:</strong><br><i>In this film, the first painting starts with a figure-drawing, a figure resembling a mythical goddess. But before the image gets its final touch, it gets attacked by irrational flows of ink. The skull represents the devil inside us, and when the smoke touches it, it is reborn. Its destruction brings so much black noise in the painting that the white brushes couldn\'t remove its blackness.</i></p><p style=\"margin-left:0px;\"><i>Then we see stabs representing ultimate destruction and a void-filled eye inside a masked face, expressing their sorrow. And at the last moment of the nightmare, we watch the devil smiling for its victory, surrounded by the candles, which is a symbol of people\'s devotion toward it.</i></p><p style=\"margin-left:0px;\"><i>Finally, the bicycle means this event\'s loop. The bike ultimately slows down over time, along with the nightmare watcher\'s tensed breath, meaning the event\'s normalization over time, rather than the authority\'s prevention steps.</i></p><p style=\"margin-left:0px;\"><i>Other references:</i><br><i>Dotted man\'s unheard speech: People\'s rebellion fading like sands.</i><br><i>Candles: devotion</i><br><i>Reddish color tone: Blood-ish atmosphere</i><br><i>Traffic: Daily circumstances</i><br><i>6:00 AM: 9/11(November) 2021\'s sunrise time</i><br><i>Backward movement in a dark old house: Backward footsteps in devil\'s area</i></p><p style=\"margin-left:0px;\"><i>The circumstances surrounding us feel like a nightmare, and it truly is- in many people\'s lives.</i></p>',NULL,'Chittagong',0,'2021-11-05','Running','2021-11-14 15:18:57','2021-11-14 15:18:57','N-Mare is an abstract short film primarily made to portray the conflicts and their results in our current society.',20,20,33,'Botble\\RealEstate\\Models\\Account','0','https://vimeo.com/642198716',NULL,'Ankon Dey Animesh',NULL,'Ankon Dey Animesh','Ankon Dey Animesh',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',1,NULL),(53,'Film video','Los Rezagados NO',NULL,0,'',2021,NULL,NULL,NULL,NULL,NULL,NULL,'La Paz',0,'2021-04-30','not_available','2021-11-14 19:09:23','2021-11-14 19:11:48','Los Rezagados narra la historia de dos casos de adopción de animales considerados “Poco probables de adopción” en la ciudad de La Paz, México. Así como la de los voluntarios que han podido reunir a dueños responsables con su compañero i',140,140,34,'Botble\\RealEstate\\Models\\Account','0','https://vimeo.com/571485098','Rezagados2021','Andrea B. Millán',NULL,'Andrea B. Millán','Andrea B. Millán',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',1,NULL),(54,'Film video','Los Rezagados',NULL,0,'',2021,NULL,NULL,NULL,NULL,NULL,NULL,'La Paz',0,'2021-04-30','Running','2021-11-14 19:10:07','2021-11-14 19:10:07','Los Rezagados narra la historia de dos casos de adopción de animales considerados “Poco probables de adopción” en la ciudad de La Paz, México. Así como la de los voluntarios que han podido reunir a dueños responsables con su compañero i',140,140,34,'Botble\\RealEstate\\Models\\Account','0','https://vimeo.com/571485098','Rezagados2021','Andrea B. Millán',NULL,'Andrea B. Millán','Andrea B. Millán',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',1,NULL),(55,'Film video','Work-A-Rama',NULL,0,'',NULL,NULL,NULL,NULL,'accounts/poster.png',NULL,'[]','CDMX',0,'2021-03-18','Running','2021-11-17 00:54:11','2023-05-26 14:31:55','Un empleado de oficina se enfrenta a su primer día de trabajo, dispuesto a sobrevivir en el mundo corporativo, sin imaginar lo que ocurrirá en su vida laboral y en su propia vida.',140,140,35,'Botble\\RealEstate\\Models\\Account','0','https://www.youtube.com/watch?v=6o5urQBerk8',NULL,'Gabriel Zúñiga González',NULL,NULL,NULL,NULL,NULL,'http://zeh.mx/','https://www.facebook.com/zehmx','https://www.twitter.com/zehmx','https://www.instagram.com/zehmx',NULL,'approved',1,NULL),(56,'Film video','Work-A-Rama',NULL,0,'',0,NULL,NULL,NULL,'accounts/poster-2.png',NULL,'[]','CDMX',0,'2021-03-18','not_available','2021-11-17 00:54:14','2023-05-27 20:46:58','Un empleado de oficina se enfrenta a su primer día de trabajo, dispuesto a sobrevivir en el mundo corporativo, sin imaginar lo que ocurrirá en su vida laboral y en su propia vida.',140,140,35,'Botble\\RealEstate\\Models\\Account','0','https://www.youtube.com/watch?v=6o5urQBerk8',NULL,'Gabriel Zúñiga González',NULL,NULL,NULL,NULL,NULL,'http://zeh.mx/','https://www.facebook.com/zehmx','https://www.twitter.com/zehmx','https://www.instagram.com/zehmx',NULL,'rejected',1,NULL),(57,'Film video','Blanche',NULL,0,'',2021,'https://www.imdb.com/title/tt13392306/?ref_=nm_flmg_act_2',NULL,NULL,NULL,'<div class=\"page\" style=\"-webkit-text-size-adjust:auto;-webkit-text-stroke-width:0px;caret-color:rgb(0, 0, 0);color:rgb(0, 0, 0);font-style:normal;font-variant-caps:normal;font-weight:normal;letter-spacing:normal;orphans:auto;text-align:start;text-decoration:none;text-indent:0px;text-transform:none;white-space:normal;widows:auto;word-spacing:0px;\" title=\"Page 1\"><div class=\"section\" style=\"background-color:rgb(255, 255, 255);\"><div class=\"layoutArea\"><div class=\"column\"><p><span style=\"font-family:Times;font-size:12pt;\">“Blanche\" is inspired by one of the most significant plays of the past and reimagined in the mad absurdity of our present. The short features Blanche, inspired by Tennessee Williams’ character of the same name in </span><i><span style=\"font-family:Times;font-size:12pt;\">A Streetcar Named Desire</span></i><span style=\"font-family:Times;font-size:12pt;\">. The flighty and feverishly vivacious woman suffers from a similar mental anguish and shares many of the same insecurities and traumas - but reimagined in 2020. This six-minute short aims to demonstrate one night Blanche plays host, and unfolds when her fantasies meet reality.</span></p><p><span style=\"font-family:Times;font-size:12pt;\">Connecting our film to a play of the past demonstrates how issues of mental illness and injustices against women have persisted throughout history. As we emerge from the worldwide pandemic and a year of societal distress, “Blanche” offers a look at how isolation affected us all, and especially those who suffer from mental health issues. “Blanche” is a story about women told by women - as over 75% of our crew identify as women. Our director, Layne Marie Williams, said, “‘Blanche’ is a deep dive into the tales we tell ourselves in order to get by. Utilizing a memorable color palette and tantalizing language, ‘Blanche’ immerses its audiences into the meaning of social butterfly.” Our film creates a look into Blanche’s isolated world that also reflects larger themes of our own world as we reflect on the past and look forward to the future.</span></p><p><span style=\"font-family:Times;font-size:12pt;\">We are humbled to submit our film to your festival and appreciate your consideration.</span></p><p><span style=\"font-family:Times;font-size:12pt;\">Best,</span><br><span style=\"font-family:Times;font-size:12pt;\">Alekandra Martin</span></p></div></div></div></div>','[\"accounts/blanche-stills-1631.jpg\",\"accounts/blanche-stills-251.jpg\",\"accounts/blanche-stills-171.jpg\",\"accounts/blanche-stills-131.jpg\"]',NULL,0,'2021-04-01','Running','2021-11-19 00:28:51','2021-11-19 00:28:51','A night in the life of a modern day Blanche DuBois as she plays host with old friends after isolation in quarantine. As her night unfolds, we are immersed into the fantasy world of Blanche\'s obsession with nostalgia.',1,1,38,'Botble\\RealEstate\\Models\\Account','0','https://vimeo.com/570080722','blanche13','Layne Marie Williams',NULL,'Alekandra Martin','Alekandra Martin',NULL,NULL,NULL,NULL,NULL,'@blanche_film',NULL,'pending',1,NULL),(58,'Film video','¿Quien Baja?',NULL,0,'',2020,NULL,'7',NULL,'accounts/whatsapp-image-2021-12-16-at-134611.jpeg','<p><span style=\"background-color:rgb(249,249,249);color:rgb(3,3,3);\"><span>Una persona...Un medio...Un destino.&nbsp;&nbsp;</span></span></p>',NULL,'Buenos Aires',0,'2020-08-29','Running','2021-12-03 02:31:10','2021-12-16 22:03:33','\"¿Quien Baja?\" Nos presenta una experiencia cinematografica única, donde enfrenta la voluntad de un hombre por llegar a su destino y un objeto, un simple medio, que puede ser mas hostil de lo que parece.\r\nGrabado bajo confinamiento por l',140,10,44,'Botble\\RealEstate\\Models\\Account','0','https://www.youtube.com/watch?v=XAmvowwqWgo&t=39s&ab_channel=VHS',NULL,'Santiago Lemar',NULL,'Santiago Lemar','Agusto Ghirardelli',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',1,NULL),(59,'Film video','¿Quien Baja?',NULL,0,'',2020,NULL,'7',NULL,NULL,'<p><span style=\"background-color:rgb(249,249,249);color:rgb(3,3,3);\"><span>Una persona ... Un medio ... Un destino.&nbsp;</span></span></p>',NULL,'Buenos Aires',0,'2020-08-29','Running','2021-12-03 02:57:47','2021-12-03 02:57:47','\"¿Quien Baja?\" Nos presenta una experiencia cinematografica única, donde enfrenta la voluntad de un hombre por llegar a su destino y un objeto, un simple medio, que puede ser mas hostil de lo que parece.\r\nGrabado bajo confinamiento por l',140,10,44,'Botble\\RealEstate\\Models\\Account','0',NULL,NULL,'Santiago Lemar',NULL,'Santiago Lemar','Agusto Ghirardelli',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',1,NULL),(60,'Film video','El Nero\'s Trip',NULL,0,'',2007,'https://www.imdb.com/title/tt3163476/?ref_=fn_al_tt_1','17',NULL,NULL,NULL,'[\"accounts\\/4-high-resolution-still-1-el-neros-trip-el-nero-stretches-1.jpeg\",\"accounts\\/4-high-resolution-still-2-el-neros-trip-conceptual-art-gallery-1.jpeg\",\"accounts\\/4-high-resolution-still-3-el-neros-trip-love-and-sand-castles-1.jpeg\"]','Mexico City',0,'2021-12-04','Running','2021-12-04 22:25:56','2021-12-10 15:49:59','El Ñero, an unscrupulous Mexican homeless, travels to Australia looking for the soccer boots of his dreams. On his way, he meets a series of bizarre characters who discriminate and stop him to achieve love at first sight.',140,14,43,'Botble\\RealEstate\\Models\\Account','0','https://www.youtube.com/watch?v=iiDWuy9Afnc',NULL,'Adrián Arce',NULL,'Adrián Arce','Judex / Adrián Arce',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',1,NULL),(62,'Film video','Luces',NULL,0,'',2017,'https://www.imdb.com/title/tt5526362/','128',NULL,'accounts/cartel-luces-edespecial-2019.jpg','<p>-</p>','[]','Valencia',0,'2017-11-24','Running','2021-12-09 19:02:39','2021-12-10 05:09:21','En 1984, Pablo, un joven y prometedor bailarín se enamora de Luz, también bailarina, pero su felicidad se verá truncada cuando Pablo es atracado y herido de muerte. Sin saber cómo, Pablo viajará en el tiempo.',199,199,49,'Botble\\RealEstate\\Models\\Account','0','https://youtu.be/KlbwQRPq_4I',NULL,'Alfredo Contreras',NULL,'José Luis Pedrero','Alicia Bel, José Luis Pedrero, Manuel Camacho',NULL,NULL,'https://www.asismaval.com/luces',NULL,NULL,NULL,NULL,'approved',1,NULL),(63,'Film video','Pirata',NULL,0,'',2021,'https://www.imdb.com/title/tt13948954/',NULL,NULL,'accounts/cartel-pirata.jpg','<p>-</p>','[]','Valencia',0,'2021-01-25','Running','2021-12-09 19:16:00','2021-12-10 05:08:54','Lidia es una mujer desesperada que lo ha perdido todo, así que un día decide quitarse la vida. Pero cuando está a punto de hacerlo, aparecerá una niña que le dará una lección de vida.',199,199,49,'Botble\\RealEstate\\Models\\Account','0','https://youtu.be/p9Ki-mhz3b0',NULL,'Manuel Camacho',NULL,'José Luis Pedrero','Alicia Bel, José Luis Pedrero',NULL,NULL,'https://www.asismaval.com/pirata',NULL,NULL,NULL,NULL,'approved',1,NULL),(64,'Film video','Fuera de foco',NULL,0,'',2013,'https://www.imdb.com/title/tt3998280/?ref_=fn_al_tt_2','36',NULL,'accounts/poster-ok-1.jpg','<p>-</p>','[\"accounts\\/4-high-resolution-stills-out-of-focus-still-1.jpg\",\"accounts\\/4-high-resolution-stills-out-of-focus-still-2-ok.jpg\"]','Mexico City',0,'2013-09-15','Running','2021-12-10 03:54:45','2021-12-10 17:19:27','This documentary was shot in collaboration with young inmates in a series of photo and video workshops at the San Fernando Community for Juvenile Specialized Treatment, an old prison for minors in South Mexico City.',140,140,43,'Botble\\RealEstate\\Models\\Account','0','https://www.youtube.com/watch?v=ZIwPpo6ZCYI',NULL,'Adrián Arce & Antonio Zirión',NULL,'Adrián Arce & Antonio Zirión','Adrián Arce, Antonio Zirión & Hugo Chávez Carvajal',NULL,NULL,NULL,'https://www.facebook.com/FueraDeFocoDocumental/',NULL,NULL,NULL,'approved',1,NULL),(65,'Film video','Filmando Batalla en el Cielo',NULL,0,'',2006,'https://www.imdb.com/title/tt0796975/?ref_=nv_sr_srsg_0','60',NULL,'accounts/filmando-batalla-en-el-cielo.jpg','<p>-</p>',NULL,'Mexico City',0,'2006-02-05','Running','2021-12-10 04:41:07','2021-12-10 15:51:31','This documentary shows the work of Carlos Reygadas during the shooting of his second fiction feature, \"Battle in Heaven\", in Mexico City.',140,140,43,'Botble\\RealEstate\\Models\\Account','0','https://www.youtube.com/watch?v=guT6bDIqAk0',NULL,'Adrián Arce & Manuel Mendez',NULL,'Manuel Mendez & Adrián Arce','Adrián Arce & Manuel Mendez',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',1,NULL),(66,'Film video','Metamorfosis',NULL,0,'',2016,NULL,'15',NULL,'accounts/metamorphosis-poster-100x70cms-english-10mb-1.jpg',NULL,'[\"accounts\\/metamorphosis-still-1-mountain-axolotl-1.jpg\",\"accounts\\/metamorphosis-still-3-sunrise-at-tecuan-1.jpg\"]','Isidro de Fabela, State of Mexico',0,'2016-09-01','Running','2021-12-10 04:59:20','2021-12-10 17:17:45','While an important home for the Otomí ethnic group, the Guadaluoe dam watershed also shelters a peculiar species: the mountain axolotl (Ambystoma altamirani), a micro-endemic, endangered amphibian, unique in the world.',140,140,43,'Botble\\RealEstate\\Models\\Account','0','https://www.youtube.com/watch?v=izwaV9WULCQ',NULL,'Adrián Arce',NULL,'Adrián Arce','Adrián Arce',NULL,NULL,NULL,'https://www.facebook.com/DocumentalMetamorfosis/',NULL,NULL,NULL,'approved',1,NULL),(67,'Film video','Agua pasa por tu casa',NULL,0,'',2021,NULL,'7',NULL,'accounts/poster-agua-pasa-por-tu-casa-1920-x-1080.jpg',NULL,'[\"accounts\\/water-running-by-your-house-film-still-1.jpg\",\"accounts\\/water-running-by-your-house-film-still-2-copy-ok.jpg\",\"accounts\\/water-running-by-your-house-film-still-3-copy-ok.jpg\"]','Tlazala de Fabela, State of Mexico',0,'2021-01-01','Running','2021-12-10 17:10:08','2021-12-10 17:11:43','Documentary short film that makes visible the problematic of poor wastewater treatment and management at the municipality of Isidro Fabela, better known as Tlazala, in the surroundings of Mexico City.',140,140,43,'Botble\\RealEstate\\Models\\Account','0','https://www.youtube.com/watch?v=u46NMotDgs4',NULL,'Adrián Arce & Josué Cruz del Corral',NULL,'Víctor Ávila Akerberg, Adrián Arce and Josué Cruz del Corral','Víctor Ávila Akerberg, Tanya González Martínez, Adrián Arce and Josué Cruz del Corral',NULL,NULL,NULL,'https://www.facebook.com/AguaPasaPorTuCasa/',NULL,NULL,NULL,'pending',1,NULL),(68,'Film video','Todos los años son 1999',NULL,0,'',2021,'https://www.imdb.com/title/tt14278834/','19',NULL,'accounts/captura-de-pantalla-2021-12-15-a-las-195806-1.png','<p>Enlace oculto YouTube</p><figure class=\"media\"><oembed url=\"https://www.youtube.com/watch?v=8GVGgqMsS8Q\"></oembed></figure><p>&nbsp;</p><figure>&nbsp;</figure><figure>&nbsp;</figure><figure>&nbsp;</figure>','[\"accounts\\/captura-de-pantalla-2021-12-15-a-las-195821.png\",\"accounts\\/captura-de-pantalla-2021-12-15-a-las-195841.png\",\"accounts\\/captura-de-pantalla-2021-12-15-a-las-195859.png\",\"accounts\\/captura-de-pantalla-2021-12-15-a-las-195917.png\"]','Valparaíso',0,'2020-06-01','Running','2021-12-15 23:01:21','2021-12-15 23:15:42','Lena, Vera y Gema aún creen que es 1999, año en que sus padres fallecieron en un trágico accidente automovilístico. Desconociendo el significado de la muerte, esperan inocentemente el regreso de sus progenitores.',44,44,53,'Botble\\RealEstate\\Models\\Account','0','https://drive.google.com/file/d/1HcL3BgMpr8gTtz0-AMzpddET3ytUzeTD/view?usp=sharing',NULL,'Pam Arias Gallardo',NULL,'Pam Arias Gallardo','Macarena Denisse',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',1,NULL),(69,'Film video','Crónicas de la conformidad tras vitrinas',NULL,0,'',2021,NULL,'15',NULL,'accounts/cro-poster.jpg',NULL,'[\"accounts\\/screen-shot-2021-12-15-at-71722-pm.png\",\"accounts\\/screen-shot-2021-12-15-at-71734-pm.png\",\"accounts\\/screen-shot-2021-12-15-at-71858-pm.png\",\"accounts\\/screen-shot-2021-12-15-at-71941-pm.png\",\"accounts\\/screen-shot-2021-12-15-at-72005-pm.png\"]','Lima',0,'2021-09-06','Running','2021-12-16 00:26:37','2021-12-16 00:28:51','Una sátira que, a través de tres breves viñetas, busca explorar ciertas actitudes adoptadas por la sociedad (inspirada particularmente en la sociedad Limeña) y cuestionar la dirección en la que estas la conducen.',170,170,55,'Botble\\RealEstate\\Models\\Account','0','https://www.youtube.com/watch?v=8uIv2uG0DTA&t=36s',NULL,'Patricio Ghezzi & Romina Osterling',NULL,'Patricio Ghezzi & Romina Osterling','Patricio Ghezzi & Romina Osterling',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',1,NULL),(70,'Film video','11',NULL,0,'',2021,NULL,'17',NULL,'accounts/afiche-oficial-111-1.png',NULL,'[\"accounts\\/banner-1.png\",\"accounts\\/frame-1.png\",\"accounts\\/frame-2.png\",\"accounts\\/frame-3.png\",\"accounts\\/frame-4.png\"]','Santiago',0,'2021-08-30','Filming','2021-12-16 01:24:11','2021-12-16 01:29:38','Un adulto mayor solitario (68) espera la visita de una persona a su casa y prepara una once para recibirlo. Esta misteriosa visita desencadena extraños sucesos en el interior de la casa y que trascienden al personaje.',44,44,56,'Botble\\RealEstate\\Models\\Account','0','https://vimeo.com/657245974/f5a2690442',NULL,'Luciano Besares',NULL,'Equipo 11','Javiera Astorga',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',1,NULL),(71,'Film video','Opal',NULL,0,'',2021,'https://www.imdb.com/title/tt16369444/?ref_=ext_shr_lnk','85',NULL,'accounts/poster-opal.jpg',NULL,'[\"accounts/still-01.jpg\",\"accounts/still-02.jpg\",\"accounts/still-03.jpg\",\"accounts/still-04.jpg\"]','Saint-Joeph',0,'2021-11-19','Running','2021-12-16 22:34:05','2021-12-16 22:34:05','Once upon a time a magic kingdom where summer lasted forever and where the animals and the inhabitants were immortal. The source of all magic was a young princess called Opal. Legends said that her joy would bring wonders and prosperity',138,138,60,'Botble\\RealEstate\\Models\\Account','0','https://vimeo.com/647907347','festival555','Alan Bidard',NULL,'Alan Bidard','Alan Bidard',NULL,NULL,NULL,'https://www.facebook.com/Opal.movie','angelking144','alainbidard',NULL,'pending',1,NULL),(72,'Film video','Stay in the Game (Sigue en el Juego)',NULL,0,'',2021,NULL,'7',NULL,'accounts/tennisposter.jpg',NULL,'[\"accounts/still-stayinthegame.jpg\"]','Los Angeles',0,'2021-12-17','Running','2021-12-17 19:04:36','2021-12-17 19:04:36','Five athletes discuss discuss their experiences playing wheelchair tennis.\r\nCinco deportistas hablan de sus experiencias jugando tenis en sillas de ruedas.',233,233,62,'Botble\\RealEstate\\Models\\Account','0','https://vimeo.com/657912672','StayGame','Jared Jacobsen',NULL,NULL,'Jared Jacobsen',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',1,NULL),(73,'Film video','Duelo',NULL,0,'',2021,NULL,'12',NULL,'accounts/whatsapp-image-2021-12-05-at-204130.jpeg',NULL,'[\"accounts\\/179117584-214234356792625-8893191665998159181-n.png\",\"accounts\\/179423176-1620128031525344-98767440362547135-n.png\",\"accounts\\/179546492-3993320584094350-5171604166666107840-n.png\",\"accounts\\/184889261-1122120918287285-3437925058256840631-n.jpg\",\"accounts\\/223860901-1169186156914094-6726698850105839835-n.jpg\",\"accounts\\/224790006-1169187230247320-6213711464190517326-n.jpg\",\"accounts\\/225483289-1169186933580683-6828842085138691614-n.jpg\",\"accounts\\/225513716-1169186426914067-3214769999185421434-n.jpg\",\"accounts\\/225673977-1169186043580772-5989205457886163553-n.jpg\",\"accounts\\/dueloooooooooooo.jpg\",\"accounts\\/ficha-tecnica-duelo.png\",\"accounts\\/186506317-105954205013074-5801532707632320392-n.jpg\",\"accounts\\/195067822-121805876761240-4014950753949159327-n.jpg\",\"accounts\\/267469105-1264805614018814-4023724533638784216-n.jpg\"]','Antofagasta',0,'2021-06-24','Running','2021-12-19 06:39:12','2021-12-19 06:51:46','Dos hermanos están en duelo, por la repentina muerte de su padre, victima de COVID-19. Por lo tanto, uno de los dos se ha contagiado, tras ir a una fiesta clandestina.',44,44,63,'Botble\\RealEstate\\Models\\Account','0','https://vimeo.com/633814382','dueloseleccion2021','Dann Nuñez',NULL,'Dann Nuñez','Dann Nuñez',NULL,NULL,NULL,'https://www.facebook.com/duelocortometraje.2021',NULL,'https://www.instagram.com/k.prytive/',NULL,'pending',1,NULL),(74,'Film video','El Altarcito',NULL,0,'',2021,NULL,'5',NULL,'accounts/264095434-10227106639188816-1671534149030641170-n.jpeg','<p>Un audiovisual, un cortometraje de videoarte o un clip musical. Filmado en el contexto del confinamiento pandémico esta puesta en escena cuenta con un gran elenco de músicas y músicos, actores, actrices y bailarines que ofrecen un recorrido emocional</p>','[\"accounts\\/captura-de-pantalla-2021-06-24-a-las-105146.jpg\",\"accounts\\/captura-de-pantalla-2021-06-24-a-las-105258.jpg\",\"accounts\\/captura-de-pantalla-2021-06-24-a-las-105709.jpg\",\"accounts\\/captura-de-pantalla-2021-06-24-a-las-110335.jpg\",\"accounts\\/captura-de-pantalla-2021-06-24-a-las-110501.jpg\"]','Buenos Aires',0,'2021-06-12','Running','2022-01-12 11:01:55','2022-01-12 11:03:05','Un audiovisual, un cortometraje de videoarte o un clip musical. Filmado en el contexto del confinamiento pandémico esta puesta en escena cuenta con un gran elenco de músicas y músicos, actores, actrices y bailarines',12,12,65,'Botble\\RealEstate\\Models\\Account','0','https://www.youtube.com/watch?v=0RjnNvG_KCM',NULL,'Luciano Ramos',NULL,'Luciano Ramos','Luciano Ramos',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',1,NULL),(75,'Film video','Nos vemos Fercito',NULL,0,'',2021,NULL,NULL,NULL,NULL,NULL,NULL,'Cdmx',0,'2021-10-01','Running','2022-01-14 22:30:23','2022-01-14 22:30:23','Un estudiante de la revuelta estudiantil de México 68 nos cuenta los momentos previos a la represión por parte del ejército.',140,140,41,'Botble\\RealEstate\\Models\\Account','0','https://youtu.be/2dSNIgpV0XQ',NULL,'Leonardo Cea',NULL,'Leonardo Cea','Leonardo Cea',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',1,NULL),(98,'Film video','Velvet',NULL,0,'',2022,NULL,'00:17:00',NULL,NULL,NULL,'','Palma de Mallorca',0,'2022-03-09','request','2022-03-02 10:20:57','2022-03-02 10:20:57',NULL,199,199,2409,'Botble\\RealEstate\\Models\\Account','0',NULL,NULL,'Antoni Caimari',NULL,'Sergio Torres','Screen Art Films',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'request',1,NULL),(100,'Film video','Candela',NULL,0,'',2022,'https://www.imdb.com/title/tt4059554/','01:35:00',NULL,'accounts/cartel-candela-2022.jpg',NULL,'[\"https://festgate.com/storage/accounts/fotograma01.jpg\",\"https://festgate.com/storage/accounts/fotograma10.jpg\",\"https://festgate.com/storage/accounts/fotograma04.jpg\",\"https://festgate.com/storage/accounts/fotograma07.jpg\",\"https://festgate.com/storage/accounts/fotograma06.jpg\"]','Valencia',0,'2022-09-04','request','2023-01-26 13:45:47','2023-01-26 13:46:49','Bea (Angie Alma) es una adolescente inmadura de 16 años que vive con su madre en un suburbio de una gran ciudad. Bea simplemente disfruta de la vida y se divierte con su mejor amiga, Sandra (Marta López) sin importarle lo que pase a su alrededor. Pero un día aparecerá una misteriosa niña de 7 años llamada Candela (Marta Villa). A partir de entonces, la vida de Bea cambiará, comenzando un proceso d',199,199,49,'Botble\\RealEstate\\Models\\Account','0','https://youtu.be/eho6ujtuJzE',NULL,'Manuel Camacho',NULL,'José Luis Pedrero','José Luis Pedrero/Juan José Alcázar',NULL,NULL,'https://www.asismaval.com/candela',NULL,NULL,NULL,NULL,'pending',1,'https://youtu.be/q2lyCOiKC6E'),(209,'Artwork','Hombre Cactus','artwork-hombre-cactus',1,'artwork-P2UuNJ3bXq.jpg',2017,NULL,NULL,'100x25x25 cm',NULL,NULL,'[]','Sa Pobla',0,'2007-08-01','Running','2023-07-21 18:27:31','2023-08-10 11:06:13',NULL,199,199,4,'App\\Models\\User','[\"26\"]',NULL,NULL,NULL,'NR3J3OYWj0.jpg',NULL,NULL,'Antoni Caimari Caldes',NULL,NULL,NULL,NULL,NULL,NULL,'pending',1,NULL),(210,'Script','Guion 22','guion-22',1,'script-mk2ftx8aJ8.pdf',2017,'https://caimari.com',NULL,'70',NULL,'<p>3e2e3e3</p>','[\"64baef8be4a84.jpg\"]','Sa Pobla',0,'2023-07-03','Running','2023-07-21 18:40:46','2023-07-22 15:54:33','e32e33e2',3,3,4,'App\\Models\\User','[\"3\",\"6\",\"9\",\"14\",\"15\"]',NULL,'carajo',NULL,'igf89XVwJ3.jpg',NULL,NULL,'Marcos de la Torre','<p>3e2e3e3</p>','https://caimari.com','https://twitter.com','https://twitter.com','https://twitter.com','https://caimari.com','pending',1,'https://www.youtube.com/watch?v=Xl3UYrNlriA'),(211,'Music','Pieza Orquestal','music-pieza-orquestal',1,'music-DjkSXFhqDn.wav',2018,'https://festgate.laraflex.org/dashboard/my-projects/create',NULL,'10',NULL,'<p>dasdas</p>',NULL,'Sa Pobla',0,'2023-07-21','Running','2023-07-21 19:06:09','2023-07-22 15:48:08','dsdsa',199,1,4,'App\\Models\\User','[\"16\"]',NULL,NULL,NULL,'Dk3d7aTA0z.jpg',NULL,NULL,'Antoni Caimari Caldes','sdads','https://caimari.com','https://caimari.com','https://festgate.laraflex.org/dashboard/my-projects/create','https://caimari.com','https://www.imdb.com/event/ev0005660/2022/1','pending',1,'https://www.youtube.com/watch?v=Xl3UYrNlriA'),(214,'Artwork','La Cometa Voladora','artwork-la-cometa-voladora',0,'projects/4/740cd414-250f-48b1-bb83-bce0a81ce1ea.jpg',2023,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'Running','2025-12-24 14:28:30','2025-12-24 15:25:06','<p>Una cometa surca los cielos</p>',199,NULL,4,'App\\Models\\User','[\"26\"]',NULL,NULL,NULL,'projects/4/directors/0adb7c6c-4b1b-4631-85d5-dc14deac52c3.jpg',NULL,NULL,'Juaquin Prats','<p>Artista multidisciplinar</p>',NULL,NULL,NULL,NULL,NULL,'pending',1,NULL),(215,'Photo','Fotografia1','photo-fotografia1',0,'projects/4/1b0e0c21-26c4-4217-b8a1-02e5627018ff.jpg',2012,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'Running','2025-12-26 17:19:34','2025-12-26 17:40:06',NULL,24,NULL,4,'App\\Models\\User','[\"27\"]',NULL,NULL,NULL,NULL,NULL,NULL,'Juan de la Torre',NULL,NULL,NULL,NULL,NULL,NULL,'pending',1,NULL);
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refunds`
--

DROP TABLE IF EXISTS `refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `refunds` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` bigint(20) unsigned NOT NULL,
  `provider_refund_id` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) NOT NULL DEFAULT 'EUR',
  `status` enum('pending','succeeded','failed','cancelled') NOT NULL DEFAULT 'pending',
  `reason` text DEFAULT NULL,
  `processed_by` bigint(20) unsigned DEFAULT NULL,
  `processed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refunds`
--

LOCK TABLES `refunds` WRITE;
/*!40000 ALTER TABLE `refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(11) NOT NULL,
  `event_id` int(10) DEFAULT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `screening_awards`
--

DROP TABLE IF EXISTS `screening_awards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `screening_awards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(10) unsigned NOT NULL,
  `award_type_id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `year` year(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `award_type_id` (`award_type_id`),
  CONSTRAINT `screening_awards_ibfk_1` FOREIGN KEY (`award_type_id`) REFERENCES `award_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `screening_awards`
--

LOCK TABLES `screening_awards` WRITE;
/*!40000 ALTER TABLE `screening_awards` DISABLE KEYS */;
INSERT INTO `screening_awards` (`id`, `project_id`, `award_type_id`, `name`, `description`, `year`, `created_at`, `updated_at`) VALUES (2,38,5,'NYC Films Awards','Mejor cortometraje Ma Belle',2017,'2023-07-22 07:46:25','2023-07-22 07:48:53');
/*!40000 ALTER TABLE `screening_awards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seasons`
--

DROP TABLE IF EXISTS `seasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `seasons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` int(10) unsigned DEFAULT NULL,
  `status` enum('active','closed','archived') NOT NULL DEFAULT 'active',
  `closed_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `celebration_date` date DEFAULT NULL,
  `celebration_end_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `notification_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `id` (`id`),
  CONSTRAINT `seasons_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seasons`
--

LOCK TABLES `seasons` WRITE;
/*!40000 ALTER TABLE `seasons` DISABLE KEYS */;
INSERT INTO `seasons` (`id`, `event_id`, `status`, `closed_at`, `name`, `start_date`, `celebration_date`, `celebration_end_date`, `end_date`, `notification_date`, `created_at`, `updated_at`) VALUES (53,77,'closed','2025-11-17 21:28:21','Ibestff','2023-07-01','2023-09-21',NULL,'2023-11-11','2023-09-06','2023-07-23 17:54:16','2025-11-17 21:28:21'),(62,13,'active',NULL,'FICYM','2023-04-01','2023-08-18',NULL,'2023-08-18','2023-08-10','2023-08-09 20:12:04','2023-08-10 09:05:30'),(63,77,'active',NULL,'Ibestff','2025-11-18','2026-10-22',NULL,'2026-08-25','2026-09-26','2025-11-17 22:16:17','2025-11-19 23:19:32'),(69,83,'active',NULL,'Test','2025-11-30','2026-05-29','2026-05-31','2026-03-30','2026-04-29','2025-11-30 04:46:51','2025-11-30 04:46:51'),(70,84,'active',NULL,'Evento Test 2','2025-12-24','2026-06-22','2026-06-24','2026-04-23','2026-05-23','2025-12-24 14:18:05','2025-12-24 14:18:06');
/*!40000 ALTER TABLE `seasons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_logs`
--

DROP TABLE IF EXISTS `security_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `security_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `details` text DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `security_logs_ip_address_type_index` (`ip_address`,`type`),
  KEY `security_logs_created_at_index` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_logs`
--

LOCK TABLES `security_logs` WRITE;
/*!40000 ALTER TABLE `security_logs` DISABLE KEYS */;
INSERT INTO `security_logs` (`id`, `ip_address`, `type`, `details`, `user_agent`, `created_at`, `updated_at`) VALUES (1,'127.0.0.1','test_security_system','This is a test log created from artisan command','Festgate Security Test Suite','2025-11-29 21:26:37','2025-11-29 21:26:37'),(2,'141.101.76.95','honeypot_trigger','Field: website, Value: yfZMNxXfsmvWivAAcf','\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36\"','2025-12-06 21:25:53','2025-12-06 21:25:53'),(3,'141.101.76.95','blocked_ip_attempt','Attempted access from blocked IP','\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36\"','2025-12-06 21:25:53','2025-12-06 21:25:53'),(4,'172.71.95.66','honeypot_trigger','Field: website, Value: gmGwTAzCVhZAPNHWBhhD','\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36\"','2025-12-13 00:36:56','2025-12-13 00:36:56'),(5,'162.159.113.88','honeypot_trigger','Field: website, Value: * * * $3,222 deposit available! Confirm your operation here: https://primefisolutions.com/?0apn8t * * * hs=cc60907ead4de0c6ca6acc3a60b5a29c* ххх*','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36','2025-12-13 09:27:10','2025-12-13 09:27:10'),(6,'172.71.103.226','honeypot_trigger','Field: website, Value: * * * <a href=\"https://primefisolutions.com/?0apn8t\">$3,222 payment available</a> * * * hs=cc60907ead4de0c6ca6acc3a60b5a29c* ххх*','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36','2025-12-13 09:27:11','2025-12-13 09:27:11'),(7,'172.71.99.147','honeypot_trigger','Field: website, Value: fsuqetjvxn','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.91 Safari/537.36','2025-12-16 19:09:34','2025-12-16 19:09:34'),(8,'172.69.234.162','rate_limit_exceeded','Type: login, IP: 172.69.234.162','Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; yie8; rv:11.0) like Gecko','2025-12-16 19:09:43','2025-12-16 19:09:43'),(9,'162.158.123.172','invalid_antifraud_token','Token mismatch or missing','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2025-12-22 10:23:28','2025-12-22 10:23:28'),(10,'104.23.199.20','honeypot_trigger','Field: website, Value: * * * $3,222 deposit available! Confirm your transaction here: https://google.com * * * hs=cc60907ead4de0c6ca6acc3a60b5a29c* ххх*','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36','2025-12-25 05:40:05','2025-12-25 05:40:05'),(11,'104.23.199.20','blocked_ip_attempt','Attempted access from blocked IP','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36','2025-12-25 05:40:06','2025-12-25 05:40:06'),(12,'162.159.113.88','blocked_ip_attempt','Attempted access from blocked IP','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36','2026-01-02 11:45:43','2026-01-02 11:45:43'),(13,'104.23.170.71','honeypot_trigger','Field: website, Value: * * * <a href=\"http://haesungint.com/?qvqg42\">$3,222 deposit available</a> * * * hs=cc60907ead4de0c6ca6acc3a60b5a29c* ххх*','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36','2026-01-02 11:45:44','2026-01-02 11:45:44'),(14,'162.158.87.92','honeypot_trigger','Field: website, Value: TwfzdamBySSIIixWVSzF','\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36\"','2026-01-09 17:22:26','2026-01-09 17:22:26'),(15,'104.23.253.22','time_trap','Form submitted in 1 seconds (min: 3)','Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36 OPR/54.0.2952.54','2026-02-03 14:38:13','2026-02-03 14:38:13'),(16,'104.23.199.228','honeypot_trigger','Field: website, Value: * * * $3,222 credit available! Confirm your transfer here: http://www.motorolapromocionesmm.com/?mexx3o * * * hs=cc60907ead4de0c6ca6acc3a60b5a29c* ххх*','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36','2026-02-09 10:20:11','2026-02-09 10:20:11'),(17,'104.23.199.228','blocked_ip_attempt','Attempted access from blocked IP','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36','2026-02-09 10:20:13','2026-02-09 10:20:13'),(18,'172.69.234.162','blocked_ip_attempt','Attempted access from blocked IP','Mozilla/5.0 (Windows NT 6.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36','2026-02-18 14:08:46','2026-02-18 14:08:46'),(19,'172.69.234.162','rate_limit_exceeded','Type: login, IP: 172.69.234.162','Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36','2026-02-18 14:08:57','2026-02-18 14:08:57'),(20,'172.69.234.163','honeypot_trigger','Field: website, Value: dhhthunxjo','Mozilla/5.0 (iPad; CPU OS 7_1_1 like Mac OS X) AppleWebKit/537.51.2 (KHTML, like Gecko) CriOS/45.0.2454.68 Mobile/11D201 Safari/9537.53','2026-03-16 14:17:26','2026-03-16 14:17:26'),(21,'172.69.234.163','rate_limit_exceeded','Type: login, IP: 172.69.234.163','Mozilla/5.0 (iPad; CPU OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5355d Safari/8536.25','2026-03-16 14:18:15','2026-03-16 14:18:15');
/*!40000 ALTER TABLE `security_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_settings`
--

DROP TABLE IF EXISTS `security_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `security_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'string',
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `security_settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_settings`
--

LOCK TABLES `security_settings` WRITE;
/*!40000 ALTER TABLE `security_settings` DISABLE KEYS */;
INSERT INTO `security_settings` (`id`, `key`, `value`, `type`, `description`, `created_at`, `updated_at`) VALUES (1,'enable_honeypot','1','boolean','Enable honeypot (trap field) protection','2025-11-29 20:53:03','2025-11-29 20:53:03'),(2,'honeypot_field_name','website','string','Name of the honeypot field','2025-11-29 20:53:03','2025-11-29 20:53:03'),(3,'enable_time_trap','1','boolean','Enable time trap (minimum form completion time)','2025-11-29 20:53:03','2025-11-29 20:53:03'),(4,'min_form_time_seconds','3','integer','Minimum seconds to complete the form','2025-11-29 20:53:03','2025-11-29 20:53:03'),(5,'enable_antifraud_token','1','boolean','Enable antifraud token validation','2025-11-29 20:53:03','2025-11-29 20:53:03'),(6,'block_suspicious_user_agents','1','boolean','Block suspicious user agents (bots, crawlers)','2025-11-29 20:53:03','2025-11-29 20:53:03'),(7,'max_login_attempts','5','integer','Maximum login attempts before blocking','2025-11-29 20:53:03','2025-11-29 20:53:03'),(8,'login_decay_minutes','15','integer','Minutes to wait after exceeding login attempts','2025-11-29 20:53:03','2025-11-29 20:53:03'),(9,'max_register_attempts','3','integer','Maximum registration attempts per IP','2025-11-29 20:53:03','2025-11-29 20:53:03'),(10,'register_decay_minutes','60','integer','Minutes to wait after exceeding registration attempts','2025-11-29 20:53:03','2025-11-29 20:53:03'),(11,'max_failed_attempts','5','integer','Failed attempts before IP block','2025-11-29 20:53:03','2025-11-29 20:53:03'),(12,'block_duration_minutes','30','integer','Duration of IP block in minutes','2025-11-29 20:53:03','2025-11-29 20:53:03'),(13,'block_disposable_emails','1','boolean','Block disposable/temporary email addresses','2025-11-29 20:53:03','2025-11-29 20:53:03'),(14,'verify_email_mx','1','boolean','Verify email domain has valid MX records','2025-11-29 20:53:03','2025-11-29 20:53:03'),(15,'custom_blocked_domains','','string','Custom blocked email domains (comma separated)','2025-11-29 20:53:03','2025-11-29 20:53:03');
/*!40000 ALTER TABLE `security_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mail_site_notification` varchar(255) DEFAULT NULL,
  `factubase_api_key` varchar(255) DEFAULT NULL COMMENT 'Factubase API Key (sk_live_xxx)',
  `factubase_webhook_secret` varchar(255) DEFAULT NULL COMMENT 'Factubase Webhook Secret (whsec_xxx)',
  `factubase_sandbox_mode` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Sandbox mode for testing',
  `factubase_invoice_series` varchar(50) DEFAULT NULL COMMENT 'Serie de facturación',
  `factubase_enabled` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Enable/disable Factubase integration',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` (`id`, `mail_site_notification`, `factubase_api_key`, `factubase_webhook_secret`, `factubase_sandbox_mode`, `factubase_invoice_series`, `factubase_enabled`) VALUES (1,'festgatellc@gmail.com','sk_evbdNNnSQNVSjI71X7qPgJkKXMAK3u818sj6mHU4PrKoRirw','whsec_784f094439c3590b29d7fd9db9d101e1a94aa5d3b3d4a4ec94891aca74ccdc36',0,NULL,1);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_confirmation_messages`
--

DROP TABLE IF EXISTS `submission_confirmation_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_confirmation_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` int(10) unsigned NOT NULL,
  `custom_message` text DEFAULT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `submission_confirmation_messages_event_id_unique` (`event_id`),
  CONSTRAINT `submission_confirmation_messages_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_confirmation_messages`
--

LOCK TABLES `submission_confirmation_messages` WRITE;
/*!40000 ALTER TABLE `submission_confirmation_messages` DISABLE KEYS */;
INSERT INTO `submission_confirmation_messages` (`id`, `event_id`, `custom_message`, `is_enabled`, `created_at`, `updated_at`) VALUES (1,77,NULL,0,'2025-11-19 02:59:18','2025-11-19 02:59:18');
/*!40000 ALTER TABLE `submission_confirmation_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submissions`
--

DROP TABLE IF EXISTS `submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `submissions` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT NULL,
  `event_id` int(10) DEFAULT NULL,
  `cat_id` int(10) DEFAULT NULL,
  `deadline_id` int(10) DEFAULT NULL,
  `season_id` int(10) DEFAULT NULL,
  `price` decimal(18,2) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `judging_status` varchar(200) NOT NULL DEFAULT 'Undecided',
  `notified` tinyint(1) NOT NULL DEFAULT 0,
  `notified_at` timestamp NULL DEFAULT NULL,
  `submission_status` varchar(200) NOT NULL DEFAULT 'In Consideration',
  `flag_status` int(10) DEFAULT NULL,
  `coupon_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `transaction_id` int(10) unsigned DEFAULT NULL,
  `payment_status` enum('pending','paid','failed','refunded','free') NOT NULL DEFAULT 'pending',
  `requires_payment` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `fk_submissions_transactions` (`transaction_id`),
  CONSTRAINT `fk_submissions_transactions` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submissions`
--

LOCK TABLES `submissions` WRITE;
/*!40000 ALTER TABLE `submissions` DISABLE KEYS */;
INSERT INTO `submissions` (`id`, `project_id`, `event_id`, `cat_id`, `deadline_id`, `season_id`, `price`, `status`, `judging_status`, `notified`, `notified_at`, `submission_status`, `flag_status`, `coupon_id`, `user_id`, `created_at`, `updated_at`, `transaction_id`, `payment_status`, `requires_payment`) VALUES (56,38,77,165,300,53,0.00,NULL,'Finalist',0,NULL,'In Consideration',NULL,NULL,4,'2023-07-28 12:51:25','2025-11-18 17:36:51',NULL,'pending',0),(67,210,77,166,300,53,0.00,NULL,'Finalist',0,NULL,'In Consideration',NULL,NULL,4,'2023-07-31 19:47:39','2025-11-17 21:25:17',NULL,'pending',0),(68,211,77,165,300,53,0.00,NULL,'Undecided',0,NULL,'In Consideration',NULL,NULL,4,'2023-07-31 22:35:41','2023-07-31 22:35:41',NULL,'pending',0),(72,209,77,165,300,53,0.00,NULL,'Selected',0,NULL,'In Consideration',NULL,NULL,4,'2023-07-31 23:01:08','2023-08-11 15:44:15',NULL,'pending',0),(73,38,83,181,352,69,10.00,NULL,'Undecided',0,NULL,'In Consideration',NULL,NULL,4,'2025-11-30 14:13:10','2025-11-30 14:13:10',1,'pending',0),(74,38,83,181,352,69,10.00,NULL,'Undecided',0,NULL,'In Consideration',NULL,NULL,4,'2025-12-01 02:40:48','2025-12-01 02:40:48',2,'pending',0),(75,209,83,181,352,69,10.00,NULL,'Undecided',0,NULL,'In Consideration',NULL,NULL,4,'2025-12-01 12:13:51','2025-12-01 12:13:51',3,'pending',0),(76,211,83,181,352,69,10.00,NULL,'Undecided',0,NULL,'Disqualified',NULL,NULL,4,'2025-12-02 06:44:42','2025-12-26 16:07:29',4,'pending',0),(77,210,83,181,352,69,10.00,NULL,'Selected',0,NULL,'In Consideration',NULL,NULL,4,'2025-12-02 07:29:55','2025-12-02 09:36:31',5,'pending',0),(78,38,83,182,352,69,10.00,NULL,'Undecided',0,NULL,'In Consideration',NULL,NULL,4,'2025-12-02 18:53:54','2025-12-02 18:53:54',8,'pending',0),(79,214,84,208,383,70,7.00,NULL,'Selected',0,NULL,'In Consideration',NULL,NULL,4,'2025-12-26 10:58:32','2025-12-26 11:10:01',11,'pending',0),(81,215,83,211,395,69,10.00,NULL,'Undecided',0,NULL,'In Consideration',NULL,NULL,4,'2025-12-26 18:14:38','2025-12-26 18:14:38',15,'pending',0),(82,210,83,214,395,69,25.00,NULL,'Undecided',0,NULL,'In Consideration',NULL,NULL,4,'2025-12-27 17:43:12','2025-12-27 17:43:12',18,'pending',0);
/*!40000 ALTER TABLE `submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_ticket_attachments`
--

DROP TABLE IF EXISTS `support_ticket_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_ticket_attachments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint(20) unsigned NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `file_size` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `support_ticket_attachments_ticket_id_foreign` (`ticket_id`),
  CONSTRAINT `support_ticket_attachments_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `support_tickets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_ticket_attachments`
--

LOCK TABLES `support_ticket_attachments` WRITE;
/*!40000 ALTER TABLE `support_ticket_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_ticket_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_ticket_replies`
--

DROP TABLE IF EXISTS `support_ticket_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_ticket_replies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint(20) unsigned NOT NULL,
  `replier_type` varchar(255) NOT NULL,
  `replier_id` bigint(20) unsigned NOT NULL,
  `message` text NOT NULL,
  `attachments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`attachments`)),
  `is_internal_note` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `support_ticket_replies_replier_type_replier_id_index` (`replier_type`,`replier_id`),
  KEY `support_ticket_replies_ticket_id_index` (`ticket_id`),
  KEY `support_ticket_replies_created_at_index` (`created_at`),
  CONSTRAINT `support_ticket_replies_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `support_tickets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_ticket_replies`
--

LOCK TABLES `support_ticket_replies` WRITE;
/*!40000 ALTER TABLE `support_ticket_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_ticket_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_tickets`
--

DROP TABLE IF EXISTS `support_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_tickets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_number` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `user_type` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `status` enum('open','in_progress','resolved','closed') NOT NULL DEFAULT 'open',
  `priority` enum('low','medium','high','urgent') NOT NULL DEFAULT 'medium',
  `category` varchar(255) DEFAULT NULL,
  `assigned_to` bigint(20) unsigned DEFAULT NULL,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `closed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `support_tickets_user_id_foreign` (`user_id`),
  CONSTRAINT `support_tickets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_tickets`
--

LOCK TABLES `support_tickets` WRITE;
/*!40000 ALTER TABLE `support_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_coupon_usages`
--

DROP TABLE IF EXISTS `ticket_coupon_usages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket_coupon_usages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `coupon_id` bigint(20) unsigned NOT NULL,
  `ticket_order_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `discount_amount` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_coupon_usages_coupon_id_user_id_index` (`coupon_id`,`user_id`),
  KEY `ticket_coupon_usages_ticket_order_id_foreign` (`ticket_order_id`),
  KEY `ticket_coupon_usages_user_id_foreign` (`user_id`),
  CONSTRAINT `ticket_coupon_usages_coupon_id_foreign` FOREIGN KEY (`coupon_id`) REFERENCES `ticket_coupons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ticket_coupon_usages_ticket_order_id_foreign` FOREIGN KEY (`ticket_order_id`) REFERENCES `ticket_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ticket_coupon_usages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_coupon_usages`
--

LOCK TABLES `ticket_coupon_usages` WRITE;
/*!40000 ALTER TABLE `ticket_coupon_usages` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_coupon_usages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_coupons`
--

DROP TABLE IF EXISTS `ticket_coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket_coupons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` int(10) unsigned NOT NULL,
  `code` varchar(255) NOT NULL,
  `discount_type` enum('percentage','fixed') NOT NULL DEFAULT 'percentage',
  `discount_value` decimal(10,2) NOT NULL,
  `max_uses` int(11) DEFAULT NULL,
  `uses_count` int(11) NOT NULL DEFAULT 0,
  `max_uses_per_user` int(11) NOT NULL DEFAULT 1,
  `valid_from` timestamp NULL DEFAULT NULL,
  `valid_until` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ticket_coupons_code_unique` (`code`),
  KEY `ticket_coupons_code_index` (`code`),
  KEY `ticket_coupons_event_id_is_active_index` (`event_id`,`is_active`),
  CONSTRAINT `ticket_coupons_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_coupons`
--

LOCK TABLES `ticket_coupons` WRITE;
/*!40000 ALTER TABLE `ticket_coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_orders`
--

DROP TABLE IF EXISTS `ticket_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket_orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_number` varchar(255) NOT NULL,
  `event_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `organizer_id` bigint(20) unsigned NOT NULL,
  `buyer_name` varchar(255) NOT NULL,
  `buyer_email` varchar(255) NOT NULL,
  `buyer_phone` varchar(255) DEFAULT NULL,
  `subtotal` decimal(10,2) NOT NULL DEFAULT 0.00,
  `platform_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `platform_fee_percentage` decimal(5,2) NOT NULL DEFAULT 0.00,
  `currency` varchar(3) NOT NULL DEFAULT 'EUR',
  `status` enum('pending','paid','cancelled','refunded') NOT NULL DEFAULT 'pending',
  `payment_type` enum('free','platform_owned','marketplace') NOT NULL DEFAULT 'marketplace',
  `transaction_id` bigint(20) unsigned DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_orders`
--

LOCK TABLES `ticket_orders` WRITE;
/*!40000 ALTER TABLE `ticket_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_types`
--

DROP TABLE IF EXISTS `ticket_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `quantity` int(11) DEFAULT NULL,
  `quantity_sold` int(11) NOT NULL DEFAULT 0,
  `max_per_order` int(11) NOT NULL DEFAULT 10,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sale_starts_at` timestamp NULL DEFAULT NULL,
  `sale_ends_at` timestamp NULL DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_types`
--

LOCK TABLES `ticket_types` WRITE;
/*!40000 ALTER TABLE `ticket_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tickets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_number` varchar(255) NOT NULL,
  `qr_code` varchar(255) NOT NULL,
  `ticket_order_id` bigint(20) unsigned NOT NULL,
  `ticket_type_id` bigint(20) unsigned NOT NULL,
  `event_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `attendee_name` varchar(255) DEFAULT NULL,
  `attendee_email` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('valid','used','cancelled','refunded') NOT NULL DEFAULT 'valid',
  `used_at` timestamp NULL DEFAULT NULL,
  `checked_in_by` bigint(20) unsigned DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tickets_ticket_number_unique` (`ticket_number`),
  UNIQUE KEY `tickets_qr_code_unique` (`qr_code`),
  KEY `tickets_ticket_order_id_index` (`ticket_order_id`),
  KEY `tickets_ticket_type_id_index` (`ticket_type_id`),
  KEY `tickets_event_id_index` (`event_id`),
  KEY `tickets_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` varchar(255) DEFAULT NULL,
  `tax_amount` decimal(10,2) DEFAULT NULL COMMENT 'Importe de IVA',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT 'Total CON IVA',
  `tax_percentage` decimal(5,2) NOT NULL DEFAULT 21.00 COMMENT 'Porcentaje de IVA',
  `created_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) NOT NULL,
  `event_id` int(10) unsigned DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `payment_intent_id` varchar(255) DEFAULT NULL COMMENT 'Stripe Payment Intent ID',
  `charge_id` varchar(255) DEFAULT NULL COMMENT 'Stripe Charge ID',
  `invoice_status` varchar(50) DEFAULT NULL COMMENT 'pending, issued, failed',
  `invoice_id` int(10) unsigned DEFAULT NULL COMMENT 'ID de factura en Factubase',
  `invoice_number` varchar(100) DEFAULT NULL COMMENT 'Número oficial',
  `invoice_pdf_url` text DEFAULT NULL COMMENT 'URL del PDF de la factura',
  `verifactu_csv` varchar(50) DEFAULT NULL COMMENT 'Código VeriFactu',
  `factubase_external_reference` varchar(255) DEFAULT NULL COMMENT 'Referencia enviada a Factubase',
  `factubase_customer_id` int(10) unsigned DEFAULT NULL COMMENT 'ID del customer en Factubase',
  `idempotency_key` varchar(255) DEFAULT NULL COMMENT 'Key para evitar duplicados',
  `customer_tax_id` varchar(50) DEFAULT NULL COMMENT 'CIF/NIF del cliente',
  `customer_legal_name` varchar(255) DEFAULT NULL COMMENT 'Razón social',
  `customer_email` varchar(255) DEFAULT NULL COMMENT 'Email de contacto',
  `customer_address` text DEFAULT NULL COMMENT 'Dirección fiscal completa',
  `customer_city` varchar(100) DEFAULT NULL,
  `customer_postal_code` varchar(20) DEFAULT NULL,
  `customer_country_code` varchar(2) NOT NULL DEFAULT 'ES' COMMENT 'Código país ISO',
  `product_name` varchar(255) DEFAULT NULL COMMENT 'Nombre del producto/plan',
  `product_description` text DEFAULT NULL COMMENT 'Descripción para la factura',
  `quantity` decimal(10,2) NOT NULL DEFAULT 1.00 COMMENT 'Cantidad',
  `unit_price` decimal(10,4) DEFAULT NULL,
  `error_message` text DEFAULT NULL COMMENT 'Mensaje de error si falla',
  `webhook_received_at` timestamp NULL DEFAULT NULL COMMENT 'Cuándo se recibió webhook de Factubase',
  `invoice_sent_at` timestamp NULL DEFAULT NULL COMMENT 'Cuándo se envió factura al cliente',
  `provider` varchar(50) DEFAULT NULL COMMENT 'stripe, mollie, paypal, etc',
  `transaction_number` varchar(100) DEFAULT NULL COMMENT 'Número único de transacción',
  `payment_method` varchar(100) DEFAULT NULL COMMENT 'card, bank_transfer, etc',
  `currency` varchar(3) NOT NULL DEFAULT 'EUR' COMMENT 'EUR, USD, etc',
  `status` varchar(50) DEFAULT NULL COMMENT 'pending, succeeded, failed, refunded',
  `paid_at` timestamp NULL DEFAULT NULL COMMENT 'Fecha y hora del pago',
  `amount` decimal(10,2) DEFAULT NULL COMMENT 'Importe sin IVA',
  `description` text DEFAULT NULL COMMENT 'Descripción de la transacción',
  PRIMARY KEY (`id`),
  UNIQUE KEY `transactions_idempotency_key_unique` (`idempotency_key`),
  UNIQUE KEY `transactions_transaction_number_unique` (`transaction_number`),
  KEY `event_id` (`event_id`),
  KEY `transactions_payment_intent_id_index` (`payment_intent_id`),
  KEY `transactions_invoice_number_index` (`invoice_number`),
  KEY `transactions_invoice_status_index` (`invoice_status`),
  CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` (`id`, `transaction_id`, `tax_amount`, `total_amount`, `tax_percentage`, `created_at`, `user_id`, `event_id`, `updated_at`, `deleted_at`, `payment_intent_id`, `charge_id`, `invoice_status`, `invoice_id`, `invoice_number`, `invoice_pdf_url`, `verifactu_csv`, `factubase_external_reference`, `factubase_customer_id`, `idempotency_key`, `customer_tax_id`, `customer_legal_name`, `customer_email`, `customer_address`, `customer_city`, `customer_postal_code`, `customer_country_code`, `product_name`, `product_description`, `quantity`, `unit_price`, `error_message`, `webhook_received_at`, `invoice_sent_at`, `provider`, `transaction_number`, `payment_method`, `currency`, `status`, `paid_at`, `amount`, `description`) VALUES (1,NULL,NULL,NULL,21.00,'2025-11-30 14:13:10',4,NULL,'2025-11-30 14:13:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ES',NULL,NULL,1.00,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'EUR',NULL,NULL,NULL,NULL),(2,NULL,1.74,10.00,21.00,'2025-12-01 02:40:47',4,NULL,'2025-12-01 02:40:48',NULL,NULL,'ch_3SZNylCXrlIYuh1W1yh6x6GA','pending',28584,'SANDBOX-2025-08511',NULL,NULL,'TXN-692D0E3FBDAE1',8051,'order_ch_3SZNylCXrlIYuh1W1yh6x6GA','37339278C','Antoni Caimari Caldes','antoni.caimari.caldes@gmail.com','Rosari, 47','Sa Pobla','07420','ES','Submission →  (Music Videos) - Deadline Early Bird','Submission →  (Music Videos) - Deadline Early Bird',1.00,8.2645,NULL,NULL,NULL,'stripe','TXN-692D0E3FBDAE1','stripe','EUR','succeeded','2025-12-01 02:40:47',8.26,NULL),(3,NULL,1.74,10.00,21.00,'2025-12-01 12:13:50',4,NULL,'2025-12-01 12:13:51',NULL,NULL,'ch_3SZWvJCXrlIYuh1W11ghFCMb','failed',NULL,NULL,NULL,NULL,NULL,NULL,'order_ch_3SZWvJCXrlIYuh1W11ghFCMb','37339278C','Antoni Caimari Caldes','antoni.caimari.caldes@gmail.com','Rosari, 47','Sa Pobla','07420','ES','Submission →  (Music Videos) - Deadline Early Bird','Submission →  (Music Videos) - Deadline Early Bird',1.00,8.2645,'Factubase error: API key not provided. Use: Authorization: Bearer {api_key}',NULL,NULL,'stripe','TXN-692D948E5F313','stripe','EUR','succeeded','2025-12-01 12:13:50',8.26,NULL),(4,NULL,1.74,10.00,21.00,'2025-12-02 06:44:40',4,NULL,'2025-12-02 06:44:42',NULL,NULL,'ch_3SZoGKCXrlIYuh1W0wdDnxt2','failed',NULL,NULL,NULL,NULL,NULL,NULL,'order_ch_3SZoGKCXrlIYuh1W0wdDnxt2','37339278C','Antoni Caimari Caldes','antoni.caimari.caldes@gmail.com','Rosari, 47','Sa Pobla','07420','ES','Submission →  (Music Videos) - Deadline Early Bird','Submission →  (Music Videos) - Deadline Early Bird',1.00,8.2645,'Factubase error: Validation failed',NULL,NULL,'stripe','TXN-692E98E8D3D7D','stripe','EUR','succeeded','2025-12-02 06:44:40',8.26,NULL),(5,NULL,1.74,10.00,21.00,'2025-12-02 07:29:54',4,NULL,'2025-12-02 07:29:55',NULL,NULL,'ch_3SZoy6CXrlIYuh1W1ZQa6u7R','pending',NULL,NULL,NULL,NULL,'TXN-692EA382BE3F6',NULL,'order_ch_3SZoy6CXrlIYuh1W1ZQa6u7R','37339278C','Antoni Caimari Caldes','antoni.caimari.caldes@gmail.com','Rosari, 47','Sa Pobla','07420','ES','Submission →  (Music Videos) - Deadline Early Bird','Submission →  (Music Videos) - Deadline Early Bird',1.00,8.2645,NULL,NULL,NULL,'stripe','TXN-692EA382BE3F6','stripe','EUR','succeeded','2025-12-02 07:29:54',8.26,NULL),(6,NULL,1.74,10.00,21.00,'2025-12-02 09:32:10',4,NULL,'2025-12-02 09:32:11',NULL,NULL,'ch_3SZqsQCXrlIYuh1W0obgliiE','failed',NULL,NULL,NULL,NULL,NULL,NULL,'order_ch_3SZqsQCXrlIYuh1W0obgliiE','37339278C','Antoni Caimari Caldes','antoni.caimari.caldes@gmail.com','Rosari, 47','Sa Pobla','07420','ES','Submission →  (Music Videos) - Deadline Early Bird','Submission →  (Music Videos) - Deadline Early Bird',1.00,8.2645,'Factubase error: Error processing sandbox transaction',NULL,NULL,'stripe','TXN-692EC02ADB557','stripe','EUR','succeeded','2025-12-02 09:32:10',8.26,NULL),(7,NULL,1.74,10.00,21.00,'2025-12-02 14:54:41',4,NULL,'2025-12-02 19:08:08',NULL,NULL,'ch_3SZvuWCXrlIYuh1W0A2EAoFR','issued',3,'SANDBOX-2025-23734','https://api.factubase.com/sandbox/invoices/3/pdf','E70D95AB','TXN-692F0BC16C813',8972,'order_ch_3SZvuWCXrlIYuh1W0A2EAoFR','37339278C','Antoni Caimari Caldes','antoni.caimari.caldes@gmail.com','Rosari, 47','Sa Pobla','07420','ES','Submission →  (Music Videos) - Deadline Early Bird','Submission →  (Music Videos) - Deadline Early Bird',1.00,8.2645,NULL,NULL,NULL,'stripe','TXN-692F0BC16C813','stripe','EUR','succeeded','2025-12-02 14:54:41',8.26,NULL),(8,NULL,1.74,10.00,21.00,'2025-12-02 18:53:51',4,NULL,'2025-12-02 19:08:08',NULL,NULL,'ch_3SZzdzCXrlIYuh1W12BoYouv','issued',4,'SANDBOX-2025-61688','https://api.factubase.com/sandbox/invoices/4/pdf','FD70C0B8','TXN-692F43CFD4242',4538,'order_ch_3SZzdzCXrlIYuh1W12BoYouv','37339278C','Antoni Caimari Caldes','antoni.caimari.caldes@gmail.com','Rosari, 47','Sa Pobla','07420','ES','Submission →  (Cortometrajes) - Deadline Early Bird','Submission →  (Cortometrajes) - Deadline Early Bird',1.00,8.2645,NULL,NULL,NULL,'stripe','TXN-692F43CFD4242','stripe','EUR','succeeded','2025-12-02 18:53:51',8.26,NULL),(10,'tr_3R6bGR3rTqcmn7QXzBkJJ',NULL,NULL,21.00,'2025-12-23 16:57:04',4,NULL,'2025-12-23 16:57:04',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ES',NULL,NULL,1.00,NULL,NULL,NULL,NULL,NULL,'TXN-694AD7F0AAC08','mollie','EUR','paid',NULL,12.10,NULL),(11,'tr_K6tJuuVa84hD26yrAKsJJ',NULL,NULL,21.00,'2025-12-26 10:58:32',4,NULL,'2025-12-26 10:58:32',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ES',NULL,NULL,1.00,NULL,NULL,NULL,NULL,NULL,'TXN-694E7868B99F7','mollie','EUR','paid',NULL,8.47,NULL),(13,'tr_Vko26CUsD3ugNtecX5tJJ',NULL,NULL,21.00,'2025-12-26 18:01:33',4,NULL,'2025-12-26 18:01:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ES',NULL,NULL,1.00,NULL,NULL,NULL,NULL,NULL,'TXN-694EDB8D82967','mollie','EUR','paid',NULL,12.10,NULL),(14,'tr_FGsXYTDps49y8bQNj5tJJ',NULL,NULL,21.00,'2025-12-26 18:03:29',4,NULL,'2025-12-26 18:03:29',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ES',NULL,NULL,1.00,NULL,NULL,NULL,NULL,NULL,'TXN-694EDC013F1EF','mollie','EUR','paid',NULL,12.10,NULL),(15,'tr_TL6Wksz2t7cX8P85s6tJJ',NULL,NULL,21.00,'2025-12-26 18:14:38',4,NULL,'2025-12-26 18:14:38',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ES',NULL,NULL,1.00,NULL,NULL,NULL,NULL,'mollie','TXN-694EDE9EBF1D0','mollie','EUR','paid',NULL,12.10,NULL),(16,'tr_NBZNX5KXx4pgcVCMEcvJJ',5.25,30.25,21.00,'2025-12-27 17:33:34',4,NULL,'2025-12-27 17:33:34',NULL,'tr_NBZNX5KXx4pgcVCMEcvJJ','tr_NBZNX5KXx4pgcVCMEcvJJ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'mollie_order_tr_NBZNX5KXx4pgcVCMEcvJJ','37339278C','Antoni Caimari Caldes','antoni.caimari.caldes@gmail.com','Rosari, 47','Sa Pobla','07420','ES','Test - Guion (Deadline Regular)','Test - Guion (Deadline Regular)',1.00,25.0000,NULL,NULL,NULL,'mollie','TXN-6950267E43A6E','mollie','EUR','paid','2025-12-27 17:33:34',25.00,NULL),(17,'tr_AdjBe7tQNzo4qbigKcvJJ',5.25,30.25,21.00,'2025-12-27 17:34:15',4,NULL,'2025-12-27 17:34:15',NULL,'tr_AdjBe7tQNzo4qbigKcvJJ','tr_AdjBe7tQNzo4qbigKcvJJ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'mollie_order_tr_AdjBe7tQNzo4qbigKcvJJ','37339278C','Antoni Caimari Caldes','antoni.caimari.caldes@gmail.com','Rosari, 47','Sa Pobla','07420','ES','Test - Guion (Deadline Regular)','Test - Guion (Deadline Regular)',1.00,25.0000,NULL,NULL,NULL,'mollie','TXN-695026A716B42','mollie','EUR','paid','2025-12-27 17:34:15',25.00,NULL),(18,'tr_iAuYDoeKkAxW8NgCAdvJJ',5.25,30.25,21.00,'2025-12-27 17:43:12',4,NULL,'2025-12-27 17:51:34',NULL,'tr_iAuYDoeKkAxW8NgCAdvJJ','tr_iAuYDoeKkAxW8NgCAdvJJ','issued',5,'SANDBOX-2025-61752','https://api.factubase.com/sandbox/invoices/5/pdf','8D94814B',NULL,6673,'mollie_order_tr_iAuYDoeKkAxW8NgCAdvJJ','37339278C','Antoni Caimari Caldes','antoni.caimari.caldes@gmail.com','Rosari, 47','Sa Pobla','07420','ES','Test - Guion (Deadline Regular)','Test - Guion (Deadline Regular)',1.00,25.0000,NULL,NULL,NULL,'mollie','TXN-695028C094087','mollie','EUR','paid','2025-12-27 17:43:12',25.00,NULL);
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `translations`
--

DROP TABLE IF EXISTS `translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `translations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `translatable_id` bigint(20) unsigned NOT NULL,
  `locale` varchar(5) NOT NULL,
  `value` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `translations_type_translatable_id_locale_unique` (`type`,`translatable_id`,`locale`),
  KEY `translations_type_translatable_id_locale_index` (`type`,`translatable_id`,`locale`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translations`
--

LOCK TABLES `translations` WRITE;
/*!40000 ALTER TABLE `translations` DISABLE KEYS */;
INSERT INTO `translations` (`id`, `type`, `translatable_id`, `locale`, `value`, `created_at`, `updated_at`) VALUES (1,'event_type',1,'es','Festival de Cine','2025-12-03 12:36:03','2025-12-03 12:36:03'),(2,'event_type',6,'es','Concurso de Arte','2025-12-03 12:36:03','2025-12-03 12:36:03'),(3,'event_type',3,'es','Concurso de Música','2025-12-03 12:36:03','2025-12-03 12:36:03'),(4,'event_type',5,'es','Festival en Línea / Evento de Premios','2025-12-03 12:36:03','2025-12-03 12:36:03'),(5,'event_type',7,'es','Otro','2025-12-03 12:36:03','2025-12-03 12:36:03'),(6,'event_type',4,'es','Concurso de Fotografía','2025-12-03 12:36:03','2025-12-03 12:36:03'),(7,'event_type',2,'es','Concurso de Guión','2025-12-03 12:36:03','2025-12-03 12:36:03'),(8,'event_category',15,'es','360 Video','2025-12-03 12:36:03','2025-12-03 12:36:03'),(9,'event_category',1,'es','Animación','2025-12-03 12:36:03','2025-12-03 12:36:03'),(10,'event_category',16,'es','Realidad Aumentada','2025-12-03 12:36:03','2025-12-03 12:36:03'),(11,'event_category',2,'es','Documental','2025-12-03 12:36:03','2025-12-03 12:36:03'),(12,'event_category',3,'es','Experimental','2025-12-03 12:36:03','2025-12-03 12:36:03'),(13,'event_category',4,'es','Largometraje','2025-12-03 12:36:03','2025-12-03 12:36:03'),(14,'event_category',24,'es','Ficción','2025-12-03 12:36:03','2025-12-03 12:36:03'),(15,'event_category',22,'es','Banda Sonora','2025-12-03 12:36:03','2025-12-03 12:36:03'),(16,'event_category',13,'es','Juego','2025-12-03 12:36:03','2025-12-03 12:36:03'),(17,'event_category',12,'es','Instalación','2025-12-03 12:36:03','2025-12-03 12:36:03'),(18,'event_category',14,'es','Película Interactiva','2025-12-03 12:36:03','2025-12-03 12:36:03'),(19,'event_category',23,'es','Solo Letra','2025-12-03 12:36:03','2025-12-03 12:36:03'),(20,'event_category',25,'es','Música','2025-12-03 12:36:03','2025-12-03 12:36:03'),(21,'event_category',5,'es','Video Musical','2025-12-03 12:36:03','2025-12-03 12:36:03'),(22,'event_category',11,'es','Performance','2025-12-03 12:36:03','2025-12-03 12:36:03'),(23,'event_category',17,'es','Guión','2025-12-03 12:36:03','2025-12-03 12:36:03'),(24,'event_category',6,'es','Cortometraje','2025-12-03 12:36:03','2025-12-03 12:36:03'),(25,'event_category',18,'es','Guión Corto','2025-12-03 12:36:03','2025-12-03 12:36:03'),(26,'event_category',21,'es','Canción','2025-12-03 12:36:03','2025-12-03 12:36:03'),(27,'event_category',19,'es','Obra de Teatro','2025-12-03 12:36:03','2025-12-03 12:36:03'),(28,'event_category',7,'es','Estudiante','2025-12-03 12:36:03','2025-12-03 12:36:03'),(29,'event_category',8,'es','Televisión','2025-12-03 12:36:03','2025-12-03 12:36:03'),(30,'event_category',20,'es','Guión de Televisión','2025-12-03 12:36:03','2025-12-03 12:36:03'),(31,'event_category',9,'es','Realidad Virtual','2025-12-03 12:36:03','2025-12-03 12:36:03'),(32,'event_category',10,'es','Web / Nuevos Medios','2025-12-03 12:36:03','2025-12-03 12:36:03'),(33,'project_category',165,'es','Cortometraje','2025-12-03 16:03:23','2025-12-03 16:03:23'),(34,'project_category',166,'es','Video Musical','2025-12-03 16:03:23','2025-12-03 16:03:23'),(36,'project_category',168,'es','Largometraje','2025-12-03 16:03:23','2025-12-03 16:03:23'),(37,'project_category',169,'es','Televisión','2025-12-03 16:03:23','2025-12-03 16:03:23'),(38,'project_category',170,'es','Guión','2025-12-03 16:03:23','2025-12-03 16:03:23'),(39,'project_category',171,'es','Arte','2025-12-03 16:03:23','2025-12-03 16:03:23'),(43,'project_category',183,'es','Ficción','2025-12-03 16:04:01','2025-12-03 16:04:01'),(44,'project_category',184,'es','Animación','2025-12-03 16:04:01','2025-12-03 16:04:01'),(45,'project_category',185,'es','Documental','2025-12-03 16:04:01','2025-12-03 16:04:01'),(46,'project_category',186,'es','Experimental','2025-12-03 16:04:01','2025-12-03 16:04:01'),(47,'project_category',187,'es','Estudiante','2025-12-03 16:04:01','2025-12-03 16:04:01'),(48,'project_category',188,'es','Web / Nuevos Medios','2025-12-03 16:04:01','2025-12-03 16:04:01'),(49,'project_category',189,'es','Guión Corto','2025-12-03 16:04:01','2025-12-03 16:04:01'),(50,'project_category',190,'es','Obra de Teatro','2025-12-03 16:04:01','2025-12-03 16:04:01'),(51,'project_category',191,'es','Guión de Televisión','2025-12-03 16:04:01','2025-12-03 16:04:01'),(52,'project_category',192,'es','Tratamiento','2025-12-03 16:04:01','2025-12-03 16:04:01'),(53,'project_category',193,'es','Canción','2025-12-03 16:04:01','2025-12-03 16:04:01'),(54,'project_category',194,'es','Banda Sonora','2025-12-03 16:04:01','2025-12-03 16:04:01'),(55,'project_category',195,'es','Solo Letra','2025-12-03 16:04:01','2025-12-03 16:04:01'),(56,'project_category',196,'es','Realidad Virtual','2025-12-03 16:04:01','2025-12-03 16:04:01'),(57,'project_category',197,'es','Performance','2025-12-03 16:04:01','2025-12-03 16:04:01'),(58,'project_category',198,'es','Instalación','2025-12-03 16:04:01','2025-12-03 16:04:01'),(59,'project_category',199,'es','Juego','2025-12-03 16:04:01','2025-12-03 16:04:01'),(60,'project_category',200,'es','Película Interactiva','2025-12-03 16:04:01','2025-12-03 16:04:01'),(61,'project_category',201,'es','Video 360','2025-12-03 16:04:01','2025-12-03 16:04:01'),(62,'project_category',202,'es','Realidad Aumentada','2025-12-03 16:04:01','2025-12-03 16:04:01'),(63,'project_category',203,'es','Fotografía','2025-12-03 16:04:01','2025-12-03 16:04:01'),(64,'project_category',204,'es','Otro','2025-12-03 16:04:01','2025-12-03 16:04:01');
/*!40000 ALTER TABLE `translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_coupons`
--

DROP TABLE IF EXISTS `user_coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_coupons` (
  `user_id` int(10) NOT NULL,
  `coupon_id` int(10) NOT NULL,
  `times_used` int(10) DEFAULT 0,
  PRIMARY KEY (`user_id`,`coupon_id`),
  KEY `coupon_id` (`coupon_id`),
  CONSTRAINT `user_coupons_ibfk_1` FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_coupons`
--

LOCK TABLES `user_coupons` WRITE;
/*!40000 ALTER TABLE `user_coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profile_name` varchar(150) NOT NULL,
  `birthdate` date DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `has_logged_in` tinyint(1) DEFAULT 0,
  `countries_id` char(25) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `tax_id` varchar(50) DEFAULT NULL COMMENT 'CIF/NIF/VAT del cliente',
  `legal_name` varchar(255) DEFAULT NULL COMMENT 'Razón social o nombre completo',
  `is_business` tinyint(1) NOT NULL DEFAULT 0 COMMENT '¿Es empresa?',
  `billing_address` text DEFAULT NULL COMMENT 'Dirección fiscal',
  `billing_city` varchar(100) DEFAULT NULL COMMENT 'Ciudad',
  `billing_postal_code` varchar(20) DEFAULT NULL COMMENT 'Código postal',
  `billing_country_code` varchar(2) NOT NULL DEFAULT 'ES' COMMENT 'Código país ISO (ES, FR, DE, etc)',
  `vat_validated` tinyint(1) NOT NULL DEFAULT 0 COMMENT '¿VAT validado con VIES?',
  `vat_validated_at` timestamp NULL DEFAULT NULL COMMENT 'Cuándo se validó el VAT',
  `vat_validation_data` text DEFAULT NULL COMMENT 'Datos de validación VIES (JSON)',
  `locale` varchar(5) NOT NULL DEFAULT 'es',
  `date_format_preference` varchar(20) NOT NULL DEFAULT 'd/m/Y',
  `time_format_preference` varchar(20) NOT NULL DEFAULT 'H:i',
  `timezone` varchar(50) NOT NULL DEFAULT 'UTC',
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `avatar` varchar(70) DEFAULT NULL,
  `cover` varchar(70) DEFAULT NULL,
  `status` enum('pending','active','suspended','delete') NOT NULL DEFAULT 'active',
  `role` enum('normal','admin') NOT NULL DEFAULT 'normal',
  `permission` enum('all','none') NOT NULL DEFAULT 'none',
  `remember_token` varchar(100) DEFAULT NULL,
  `token` varchar(80) DEFAULT NULL,
  `confirmation_code` varchar(125) DEFAULT NULL,
  `paypal_account` varchar(200) DEFAULT NULL,
  `payment_gateway` varchar(50) DEFAULT NULL,
  `bank` text DEFAULT NULL,
  `featured` enum('yes','no') NOT NULL DEFAULT 'no',
  `featured_date` timestamp NULL DEFAULT NULL,
  `about` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text DEFAULT NULL,
  `story` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profession` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oauth_uid` varchar(255) DEFAULT NULL,
  `oauth_provider` varchar(255) DEFAULT NULL,
  `categories_id` varchar(255) DEFAULT NULL,
  `website` varchar(200) DEFAULT NULL,
  `stripe_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `card_brand` varchar(255) DEFAULT NULL,
  `card_last_four` varchar(4) DEFAULT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `balance` decimal(10,2) DEFAULT NULL,
  `verified_id` enum('yes','no','reject') DEFAULT 'no',
  `address` varchar(200) DEFAULT NULL,
  `city` varchar(150) DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `facebook` varchar(200) DEFAULT NULL,
  `twitter` varchar(200) DEFAULT NULL,
  `instagram` varchar(200) DEFAULT NULL,
  `youtube` varchar(200) DEFAULT NULL,
  `vimeo` varchar(255) DEFAULT NULL,
  `pinterest` varchar(200) DEFAULT NULL,
  `github` varchar(200) DEFAULT NULL,
  `last_seen` timestamp NULL DEFAULT NULL,
  `email_new_subscriber` enum('yes','no') NOT NULL DEFAULT 'yes',
  `plan` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notify_new_subscriber` enum('yes','no') NOT NULL DEFAULT 'yes',
  `notify_liked_post` enum('yes','no') NOT NULL DEFAULT 'yes',
  `notify_commented_post` enum('yes','no') NOT NULL DEFAULT 'yes',
  `company` varchar(250) DEFAULT NULL,
  `post_locked` enum('yes','no') NOT NULL DEFAULT 'yes',
  `ip` varchar(40) DEFAULT NULL,
  `dark_mode` enum('on','off') NOT NULL DEFAULT 'off',
  `gender` varchar(50) DEFAULT NULL,
  `allow_download_files` enum('no','yes') NOT NULL DEFAULT 'no',
  `language` varchar(10) DEFAULT NULL,
  `free_subscription` enum('yes','no') NOT NULL DEFAULT 'yes',
  `wallet` decimal(10,2) DEFAULT NULL,
  `tiktok` varchar(200) DEFAULT NULL,
  `snapchat` varchar(200) DEFAULT NULL,
  `paystack_plan` varchar(100) DEFAULT NULL,
  `paystack_authorization_code` varchar(100) DEFAULT NULL,
  `paystack_last4` int(10) unsigned DEFAULT NULL,
  `paystack_exp` varchar(50) DEFAULT NULL,
  `paystack_card_brand` varchar(25) DEFAULT NULL,
  `notify_new_tip` enum('yes','no') NOT NULL DEFAULT 'yes',
  `hide_profile` enum('yes','no') DEFAULT 'no',
  `hide_last_seen` enum('yes','no') DEFAULT NULL,
  `last_login` varchar(250) DEFAULT NULL,
  `hide_count_subscribers` enum('yes','no') NOT NULL DEFAULT 'no',
  `hide_my_country` enum('yes','no') NOT NULL DEFAULT 'no',
  `show_my_birthdate` enum('yes','no') NOT NULL DEFAULT 'no',
  `notify_new_post` enum('yes','no') NOT NULL DEFAULT 'yes',
  `notify_email_new_post` enum('yes','no') NOT NULL DEFAULT 'yes',
  `custom_fee` int(10) unsigned DEFAULT NULL,
  `hide_name` enum('yes','no') NOT NULL DEFAULT 'no',
  `birthdate_changed` enum('yes','no') NOT NULL DEFAULT 'no',
  `email_new_tip` enum('yes','no') NOT NULL DEFAULT 'yes',
  `email_new_ppv` enum('yes','no') NOT NULL DEFAULT 'yes',
  `notify_new_ppv` enum('yes','no') NOT NULL DEFAULT 'yes',
  `active_status_online` enum('yes','no') NOT NULL DEFAULT 'yes',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `permissions` text DEFAULT NULL,
  `super_user` tinyint(1) DEFAULT 0,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `avatar_id` int(10) unsigned DEFAULT NULL,
  `manage_supers` tinyint(1) NOT NULL DEFAULT 0,
  `dob` date DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  `confirmed_at` datetime DEFAULT NULL,
  `email_verify_token` varchar(120) DEFAULT NULL,
  `credits` int(10) unsigned DEFAULT NULL,
  `is_featured` tinyint(1) DEFAULT NULL,
  `type_user` varchar(20) DEFAULT 'creator',
  `payment_account_required` tinyint(1) NOT NULL DEFAULT 0,
  `payment_account_verified` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` int(10) DEFAULT NULL,
  `blocked_countries` text DEFAULT NULL,
  `two_factor_secret` text DEFAULT NULL,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `current_team_id` bigint(20) unsigned DEFAULT NULL,
  `profile_photo_path` text DEFAULT NULL,
  `festgate` enum('0','1') NOT NULL DEFAULT '0',
  `custom_emails` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `username` (`status`),
  KEY `role` (`role`),
  KEY `username_2` (`username`),
  KEY `permission` (`permission`),
  KEY `categories_id` (`categories_id`),
  KEY `stripe_id` (`stripe_id`(191)),
  KEY `idx_tax_id` (`tax_id`),
  KEY `idx_billing_country` (`billing_country_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3614 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `profile_name`, `birthdate`, `username`, `has_logged_in`, `countries_id`, `password`, `email`, `tax_id`, `legal_name`, `is_business`, `billing_address`, `billing_city`, `billing_postal_code`, `billing_country_code`, `vat_validated`, `vat_validated_at`, `vat_validation_data`, `locale`, `date_format_preference`, `time_format_preference`, `timezone`, `date`, `avatar`, `cover`, `status`, `role`, `permission`, `remember_token`, `token`, `confirmation_code`, `paypal_account`, `payment_gateway`, `bank`, `featured`, `featured_date`, `about`, `description`, `story`, `profession`, `oauth_uid`, `oauth_provider`, `categories_id`, `website`, `stripe_id`, `card_brand`, `card_last_four`, `trial_ends_at`, `price`, `balance`, `verified_id`, `address`, `city`, `zip`, `facebook`, `twitter`, `instagram`, `youtube`, `vimeo`, `pinterest`, `github`, `last_seen`, `email_new_subscriber`, `plan`, `notify_new_subscriber`, `notify_liked_post`, `notify_commented_post`, `company`, `post_locked`, `ip`, `dark_mode`, `gender`, `allow_download_files`, `language`, `free_subscription`, `wallet`, `tiktok`, `snapchat`, `paystack_plan`, `paystack_authorization_code`, `paystack_last4`, `paystack_exp`, `paystack_card_brand`, `notify_new_tip`, `hide_profile`, `hide_last_seen`, `last_login`, `hide_count_subscribers`, `hide_my_country`, `show_my_birthdate`, `notify_new_post`, `notify_email_new_post`, `custom_fee`, `hide_name`, `birthdate_changed`, `email_new_tip`, `email_new_ppv`, `notify_new_ppv`, `active_status_online`, `email_verified_at`, `created_at`, `updated_at`, `permissions`, `super_user`, `firstname`, `lastname`, `avatar_id`, `manage_supers`, `dob`, `phone`, `confirmed_at`, `email_verify_token`, `credits`, `is_featured`, `type_user`, `payment_account_required`, `payment_account_verified`, `created_by`, `blocked_countries`, `two_factor_secret`, `two_factor_recovery_codes`, `current_team_id`, `profile_photo_path`, `festgate`, `custom_emails`) VALUES (1,'webmaster',NULL,'webmaster',1,'1','$2y$10$/0lAfOz1KepD9omY5BHQOe2NHzfKPAzvzG21RSEc224CqnfXwfpMW','webmaster@festgate.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','profiles/1/0e88374a-a1d7-4a3c-94c9-eaf8c598017a.png','','active','admin','none','5JvWvflKzObM2KpDoHiJILNYoSzR2eCvn2zE0JmwhBkBEu5k45ZKf2Jk4AaZ','','$2y$10$TekakqhWxrlubGkwGfz4V.7L7U.LdKx4oZJRGaakGK6/x6KcEIZaS','','','','no',NULL,NULL,NULL,'','','','','',NULL,NULL,NULL,NULL,NULL,0.00,0.00,'no','',NULL,'',NULL,NULL,NULL,NULL,NULL,'','','2023-07-12 02:56:58','yes','','yes','yes','yes',NULL,'no','','off',NULL,'no','','yes',0.00,'','','','',0,'','','yes','no','no','2023-05-26 16:21:31','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-06-11 20:56:49','2025-12-26 12:52:13',NULL,1,'System','Admin',1301,1,'1976-12-22',NULL,NULL,NULL,0,NULL,'organizer',0,0,1,NULL,NULL,'',NULL,'','1',NULL),(4,'Antoni Caimari Caldés','1976-12-22','caimari',1,'199','$2y$10$jj4UbJW9u8yN0FmmC4dXquS2mOLXO0gkFDtR3IEhWByVlQ2ScZKjG','antoni.caimari.caldes@gmail.com','37339278C','Antoni Caimari Caldes',0,'Rosari, 47','Sa Pobla','07420','ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','profiles/users/4/1690041892.jpg','','active','normal','none','lkukp9nDhu2NEvDhyQaCiJuxfPfGOrNFsCZIPPPmphiR8QkF7fbwF0S3tsNL','','','','','','no',NULL,'Cineasta',NULL,'','','','','','https;//caimari.com',NULL,NULL,NULL,NULL,0.00,0.00,'no','','Sa Pobla','',NULL,NULL,'https://www.instagram.com/acaimari/',NULL,NULL,'','','2023-07-01 11:44:34','yes','','yes','yes','yes','Screen Art S.L','no','','off','Male','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-02 07:05:00','2026-01-02 15:18:21',NULL,0,'Antoni','Caimari',NULL,0,NULL,'605 26 24 18','2021-11-02 08:05:01',NULL,97,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','1',NULL),(13,'carlosrom',NULL,'carlosrom',1,'140','$2y$10$YAAEQLNli4W4UF2OE50qJea0xeCRqR2s/3e/K0BGsGLTYnPQ5DRGy','arcomexfilms@hotmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','profiles/users/13/1691611569.jpg','','active','normal','none','X8HbRIA6jiB6xb1jxOaDHkOOhgIHVoO3SDMlP0RhbEzco6evglLEUfxpOmzp','','','','','','no',NULL,NULL,NULL,'dwdw','','','','',NULL,NULL,NULL,NULL,NULL,0.00,557.44,'no','dwdw','Ecatepec de Morelos','dwdw',NULL,NULL,NULL,NULL,NULL,'','','2023-06-17 13:16:06','yes','user_13','yes','yes','yes',NULL,'no','','off','Male','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','yes','yes','yes','yes','yes',NULL,'2021-11-06 20:33:44','2025-11-16 13:51:36',NULL,0,'Carlos rom','Mateus',1133,0,NULL,NULL,'2021-11-06 16:33:45',NULL,NULL,0,'organizer',0,0,1,NULL,NULL,'',NULL,'','1','[{\"id\":1,\"notification\":\"Selected\",\"db\":\"selected\",\"message\":\"Default\",\"modified\":\"26\\/01\\/2023\",\"editar\":true,\"content\":null},{\"id\":2,\"notification\":\"Not Selected\",\"db\":\"not-selected\",\"message\":\"Default\",\"modified\":\"02\\/08\\/2022\",\"editar\":true,\"content\":null},{\"id\":3,\"notification\":\"Award Winner\",\"db\":\"award-winner\",\"message\":\"Default\",\"modified\":\"Never\",\"editar\":false,\"content\":null},{\"id\":4,\"notification\":\"Finalist\",\"db\":\"finalist\",\"message\":\"Default\",\"modified\":\"Never\",\"editar\":false,\"content\":null},{\"id\":5,\"notification\":\"Semi-Finalist\",\"db\":\"semi-finalist\",\"message\":\"Default\",\"modified\":\"Never\",\"editar\":false,\"content\":null},{\"id\":6,\"notification\":\"Quarter-Finalist\",\"db\":\"quarter-finalist\",\"message\":\"Default\",\"modified\":\"Never\",\"editar\":false,\"content\":null},{\"id\":7,\"notification\":\"Nominee\",\"db\":\"nominee\",\"message\":\"Default\",\"modified\":\"Never\",\"editar\":false,\"content\":null},{\"id\":8,\"notification\":\"Honorable Mention\",\"db\":\"honorable-mention\",\"message\":\"Default\",\"modified\":\"Never\",\"editar\":false,\"content\":null}]'),(15,'icarrum',NULL,'icarrum',0,'','$2y$10$9KV21xXg0xkEumX7p8G5K.9nPVhFWFhmb.8IwA9mPEac/ocZo9FMW','icarrum@hotmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-09 19:11:57','2021-11-09 19:11:58',NULL,0,'Elias Ivan','Carrum Luna',NULL,0,NULL,NULL,'2021-11-09 14:11:58',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(16,'omarazizstar',NULL,'omarazizstar',0,'','$2y$10$umz9xCk2zRvPcqp.647tROaTGwAKskLrbInZxufipQMOL1UT0.Jw6','omarazizfilms@hotmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-11 20:38:54','2021-11-11 20:38:56',NULL,0,'Omar','Aziz',NULL,0,NULL,NULL,'2021-11-11 15:38:56',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(17,'nahdtop',NULL,'nahdtop',0,'','$2y$10$09ZCCKn9fDAPnzPT44seDuJYuU5BjYMmHg9wed55wPHJx1qvQb3Hm','nahdtop@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-11 20:43:33','2021-11-11 20:43:34',NULL,0,'Nahd','Bashir',NULL,0,NULL,NULL,'2021-11-11 15:43:34',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(18,'adelmashoo',NULL,'adelmashoori',0,'','$2y$10$3iGyi7VHTPGgjhEjUP/Tduau/xUwHZWGczME/1mDz0AdTKnlmwzmS','adelmashoori@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-11 21:09:30','2021-11-11 21:09:31',NULL,0,'adel','mashoori',NULL,0,NULL,NULL,'2021-11-11 16:09:31',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(21,'aleka',NULL,'alekandramartin',0,'','$2y$10$.B8CDo6yY2whf9Y6Z4ouv.vR.4jkebHd7K.jH4Lb7TTuXqTatLCya','duplicado_alekandramartin@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-12 18:25:55','2021-11-12 18:25:57',NULL,0,'Alekandra','Martin',NULL,0,NULL,NULL,'2021-11-12 13:25:57',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(22,'rom',NULL,'rom',0,'','$2y$10$o8J8xlwC2voIG3wVG.8hF.Pk2V5CZiOhiO2ciPnRiuenNFoHS3v8.','romravno@hotmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-12 20:37:47','2021-11-12 20:37:48',NULL,0,'rom ravno','ravno',NULL,0,NULL,NULL,'2021-11-12 15:37:48',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(23,'marcosnu',NULL,'marcosnu',0,'','$2y$10$W6lJubNPEs/G8yepVlemvu9Gxk9skXjJQbjdM/xxqbWtt7BwSUgNi','creativo@domi.com.mx',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-12 20:52:23','2021-11-12 20:52:25',NULL,0,'MARCOS','MUÑOZ FLORES',NULL,0,NULL,NULL,'2021-11-12 15:52:25',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(24,'IvalLs',NULL,'ivalls',0,'','$2y$10$uUmVAzu3q/Q7IWHhK1ftreStnmlDUe/3aWnLciuv.c81b2fP8xb5q','ivanlowenberg@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','WdbROZOtTYxnLGMPgdL6noOm5tgYGJyV1ajkFl2V4AqfV2AiyJFOkJhJprqz','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-12 23:06:45','2021-11-12 23:06:46',NULL,0,'Ivan','Lowenberg',NULL,0,NULL,NULL,'2021-11-12 18:06:46',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(25,'Corto Esmeralda',NULL,'corto-esmeralda',0,'','$2y$10$H9SQ7RikueXY41mWY4199urldIgEyqo6xKNUypieZyItP02dGsWRa','cortoesmeralda@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-13 18:08:53','2021-11-13 18:08:54',NULL,0,'Samantha','Orozco',NULL,0,NULL,NULL,'2021-11-13 13:08:54',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(30,'Alibeigi',NULL,'alibeigi',0,'','$2y$10$ChcE0YYmGshUIGh8isOppu.Ev8ruE5NdE7rTrPr2rm1lyGvms3/Y6','alirezabeigi021@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','D63uYDHfcUIX0KLPaT3oCloEgD5SFfdySKxrjoy1QCFS7EAvLNE2TnINc4H9','','','','','','no',NULL,'','I m film maker','','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','male','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-14 00:32:12','2021-11-14 06:01:09',NULL,0,'Alireza','Beigi',1166,0,'1982-10-12','989122252107','2021-11-13 19:32:13',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(31,'ebad3449',NULL,'ebad_3449',0,'','$2y$10$umOhhcXxCVBSfZyE.1aCiujTuqOTAVMs4bNgC8xt29Lu/fvLP092K','ebad.adib344@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','male','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-14 06:34:44','2021-11-14 06:38:47',NULL,0,'Ebad','Adibpour',NULL,0,'1986-06-23','+989177443449','2021-11-14 01:34:46',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(33,'ankodeyanimesh',NULL,'ankondeyanimesh',0,'','$2y$10$Zi98uOnjz.B8apa9rOaQwOpAyz72b2qLTG1N5QnAFvbamgdDCVKMm','ankondeyanimesh@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-14 15:11:49','2021-11-14 15:11:51',NULL,0,'Ankon','Dey',NULL,0,NULL,NULL,'2021-11-14 10:11:51',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(34,'andibrimi',NULL,'andibrimi',0,'','$2y$10$dxnp1AvTz9wj9ZAYWmH2F.zInBnFCyNUjW9YX8/OHAyUyErEYKns6','andibrimi@hotmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-14 19:02:22','2021-11-14 19:02:23',NULL,0,'Andrea María','Briseño Millán',NULL,0,NULL,NULL,'2021-11-14 14:02:23',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(35,'gzuniga',NULL,'gzuniga',0,'','$2y$10$WE1k5pXPKn1o2zJuaWdl9.WKV0krVKwr.SmHlelW1N3/1XZGVfDbS','gabo.zehmx@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-16 23:04:55','2021-11-16 23:04:56',NULL,0,'Gabriel','Zúñiga',NULL,0,NULL,NULL,'2021-11-16 18:04:56',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(36,'lospachamama',NULL,'lospachamama',0,'','$2y$10$X/9hgagMklM0wuJZauYCwOCdyzShSiFP/X2tiDV3VFNscT2la69iW','pachabeto@hotmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-17 13:07:54','2021-11-17 13:07:55',NULL,0,'Roberto','Sobrinoo',NULL,0,NULL,NULL,'2021-11-17 08:07:55',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(37,'produccionesgomez',NULL,'produccionesgomez',0,'','$2y$10$cF3Sw3nLFtuMe61tCQyhi.H2CrJ/aq3T2JPT18OMfC0pz1W4gNJRy','oswaldogonez174@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-18 14:34:32','2021-11-18 14:34:34',NULL,0,'Oswaldo','Gómez',NULL,0,NULL,NULL,'2021-11-18 09:34:34',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(38,'alekadramartin',NULL,'alekandramartin',0,'','$2y$10$N7oUzx.bikInwTs7ODWRnumt.WHZtsiyHSSCgmQuP1JTouoH084ke','alekandramartin@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-19 00:19:28','2021-11-19 00:19:29',NULL,0,'Alekandra','Martin',NULL,0,NULL,NULL,'2021-11-18 19:19:29',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(39,'Lobo Cromatico',NULL,'lobocromatico',0,'','$2y$10$.Q5qA5f4UXEBYh3jSbYG8OKLJGWVeifTyZFQReMCOcYUaP3BQWLe6','jarem88@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-22 19:48:46','2021-11-22 19:48:47',NULL,0,'Jesús','Reyes',NULL,0,NULL,NULL,'2021-11-22 14:48:47',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(40,'Dann 26',NULL,'dann26',0,'','$2y$10$GuIb6OYoBCWxikgtM3TkwuMYL7C2MefkQuTzZVVGMgoPZnXG.mp8q','d.proyecto@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-25 04:32:46','2021-11-25 04:32:47',NULL,0,'Dann','Núñez',NULL,0,NULL,NULL,'2021-11-24 23:32:47',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(41,'Leo Cea',NULL,'leocea',0,'','$2y$10$MNjgyChkmfKUwQso5yG6HuIaLg9u2sW25o29bnAKc/8ksho6dAL7y','leonardocea@hotmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-27 04:38:11','2021-11-27 04:38:13',NULL,0,'leonardo','Cea',NULL,0,NULL,NULL,'2021-11-26 23:38:13',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(42,'Kaaf Film',NULL,'kaaffilm',0,'','$2y$10$hXIRROPlMZiNK8koAkYG7eKxnR8NZ/2Tf7qOQvmltZ2yqjUaNSECy','kaaffilm@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-30 09:11:59','2021-11-30 09:12:35',NULL,0,'Midia','Kiasat',1209,0,NULL,NULL,'2021-11-30 04:12:00',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(43,'Adrian Arce',NULL,'adrianarce',0,'140','$2y$10$X50U/yz7oU5WjrLN1PtRiuNJrTEfdfeVgNmZcVBsYGWRpmSlB4kva','delagarce@yahoo.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'','I am a filmmaker interested in social, cultural and artistic films, documentary and fiction.','','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','male','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-11-30 23:23:56','2021-11-30 23:26:26',NULL,0,'Adrián','Arce',1210,0,'1976-08-09',NULL,'2021-11-30 18:23:58',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(44,'lemar96',NULL,'lemar96',0,'','$2y$10$Wj46wKsfD6eXyzWHmjDe7e3WjHGLgrOPpewSP.uZ1Qt/VZAzGls0C','santimartilegui@hotmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-12-02 01:09:54','2021-12-02 01:09:55',NULL,0,'Santiago','Martinez Leguizamon',NULL,0,NULL,NULL,'2021-12-01 20:09:55',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(49,'Jose Luis Pedrero',NULL,'joseluispedrero',0,'199','$2y$10$Y8t2wYJhaIv4C9QCkavRzeacc0a2NfoCi.uuMQ0Xi8Qw.LiUbTdFC','joseluispedrero@asismaval.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','nhks92QPzOvFNH5gpRKuuBJQfyfDJNUrpXX92dIwq08criBebglEuBsPDP6a','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','','2023-04-20 08:29:39','yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-12-09 18:19:16','2021-12-09 18:19:18',NULL,0,'José Luis','Pedrero Ramón',NULL,0,NULL,NULL,'2021-12-09 13:19:18',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(52,'Eva Sol',NULL,'Evasolsol',0,'','$2y$10$BZJeIunl.flBE05P2UJ9uOQmnA9MKbEwVkkMbX1n0lNB.MQ8o97IK','aymanssolina@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-12-15 22:48:40','2021-12-15 22:48:42',NULL,0,'Eva','Aymans',NULL,0,NULL,NULL,'2021-12-15 17:48:42',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(53,'Pam Arias G',NULL,'Pam.AriasG',0,'','$2y$10$BesJziazfCFObVzR6xpVcuQ.W6oQuem1/L9vmincksGQaReKf75oe','pam.ariasgallardo@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-12-15 22:50:18','2021-12-15 22:50:19',NULL,0,'Pamela','Arias Gallardo',NULL,0,NULL,NULL,'2021-12-15 17:50:19',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(54,'M Bacebo',NULL,'mbacebo',0,'','$2y$10$s0HmpUqhn4jVSaPc0K13huNBTVM8h7L4vzTh5UVSP7NQajRd7huXm','mbacebo@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-12-15 23:39:37','2021-12-15 23:39:38',NULL,0,'María Belén','Acebo Plaza',NULL,0,NULL,NULL,'2021-12-15 18:39:38',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(55,'Patghenov',NULL,'patghenov',0,'170','$2y$10$EQ4BMSoTWyvorUV.Lcurz.bOuyWJDoHN4CDFrq.k6qXJZIH2g8KFW','patghenov1@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','Pasaje Las Morenas 122 Miraflores','Lima','15074','','','','','','','','2022-06-08 05:02:38','yes','user_55','yes','yes','yes','Student','no','','off','male','no','es','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','yes','yes','yes','yes','yes',NULL,'2021-12-16 00:10:07','2021-12-16 00:10:08',NULL,0,'Patricio','Ghezzi Novak',NULL,0,NULL,NULL,'2021-12-15 19:10:08',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(56,'Jvr Strg',NULL,'jvr.strg',0,'','$2y$10$NBBWWudQAj28wxLoPzfUROSmJCdWWaiVGElylCHmp2rvvjhbCYri2','jastorgarubina@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','9jMHE7sjkX1VZoIhfW0DsTClkB9XNR2NHwRugInVHCyX7sqM21nET573FyQY','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','','2022-08-22 19:15:46','yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-12-16 00:15:05','2022-06-07 06:10:38',NULL,0,'Javiera','Astorga Rubina',NULL,0,NULL,NULL,'2021-12-15 19:15:07',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(58,'Sbahramhan',NULL,'Sbahramjahan',0,'','$2y$10$zf6dqqFXB71ZbnjFHE9PMex7UtzEXQlHbJg1EsdqwyMRYJLaUfCE6','sarabahramjahan@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-12-16 20:04:29','2021-12-16 20:04:31',NULL,0,'Sara','Bahramjahan',NULL,0,NULL,NULL,'2021-12-16 15:04:31',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(60,'Alan Bidard',NULL,'AlanBidard',0,'','$2y$10$U61JxeY9dkw/n5BC9PMZweWfVDnj1Mlba14.qMNTYDh4HJPuh42A6','alain.bidard@yahoo.fr',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-12-16 22:15:26','2021-12-16 22:15:28',NULL,0,'Alain','Bidard',NULL,0,NULL,NULL,'2021-12-16 17:15:28',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(63,'Dnuez',NULL,'dnuez.26',0,'','$2y$10$B9X8spdmZhNfaRyWVR24y.cYwpv49wC5j/ZP1749EKrEjVTbEFv2G','darayanux@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-11 16:52:14','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2021-12-19 04:23:34','2021-12-19 04:23:36',NULL,0,'Dann','Nuñez',NULL,0,NULL,NULL,'2021-12-18 23:23:36',NULL,NULL,NULL,'creator',0,0,1,NULL,NULL,'',NULL,'','0',NULL),(65,'choquemanta',NULL,'choquemanta',0,'','$2y$10$L4o5Q5qbKjyVFNVlvFjJ3.69r52fae6YIS5JA/rQzlfs3630E81v2','choquemanta@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-12 16:52:13','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'','Choque - Luciano Ramos es músico principalmente. A su vez se desarrolló como diseñador gráfico y en el área de dirección artística en cine.\r\nEn varias ocasiones a unificado estos dos mundos dirigiendo videos musicales.','','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','male','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2022-01-12 10:52:13','2022-01-12 11:07:10',NULL,0,'Luciano','Ramos',1311,0,'1980-07-23','01151639623','2022-01-12 11:52:13',NULL,NULL,NULL,'creator',0,0,NULL,NULL,NULL,'',NULL,'','0',NULL),(67,'ram',NULL,'ram',0,'','$2y$10$XZL4iSCmSdz/Qufq4yJVzuPWAUkiMQ6A78SKTyxCWqLcx8kBIuqzG','rm.film@outlook.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2022-01-21 23:32:16','default-1641976645.jpg','','active','normal','none','','','','','','','no',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','',NULL,'yes','','yes','yes','yes','','no','','off','','no','','yes',0.00,'','','','',0,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,'2022-01-21 17:32:16','2022-01-21 17:32:22',NULL,0,'Raul','Querci',NULL,0,NULL,NULL,'2022-01-21 18:32:22',NULL,NULL,NULL,'creator',0,0,NULL,NULL,NULL,'',NULL,'','0',NULL),(2437,'Armin',NULL,'u2437',0,'','$2y$10$pWPK10x5Ak7iOgUNGIXVpuOSw2.g3baAt1z0RbWBXwApbK5YDrOhu','deathanniversary.shortfilm@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2023-06-24 18:47:04','default-1641976645.jpg','cover_default-1639599705.jpg','active','normal','none','','PRTPI74sZTpjao70GIKoCxMg48oxEWDP89V4WVVsxEEdFMbouUlgXhQxcthXDdSG1RrG2Bj5qVn','$2y$10$dPzpMAeRUCn8mFVunQi/LuTvorfjqLrl10IV.XmtZkQRN/CaJR4sC','','','','no',NULL,'',NULL,'Welcome to my profile.','','','','','',NULL,NULL,NULL,NULL,0.00,0.00,'no','','','','','','','','','','','2023-06-27 08:55:21','yes','','yes','yes','yes','','no','93.115.17.234','off','','no','en','yes',0.00,'','','','',NULL,'','','yes','no','no','','no','no','no','yes','yes',0,'no','no','yes','yes','yes','yes',NULL,NULL,NULL,NULL,0,'Armin','Keshvari',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,'creator',0,0,NULL,NULL,NULL,'',NULL,'','1',NULL),(2440,'Ibestff','2022-01-01','Ibestff',0,NULL,'$2y$10$/9laea9zsPCJQ/0ZQ5vdv.jlTKnvGzicYou/879FDgx66/MXmKrcu','ibestfilmsfestival@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2023-07-12 15:22:33','profiles/users/2440/1691602843.png',NULL,'active','normal','none','U2uYeOy5MWt9E7E8JONitGVBNRR4gQLZO71WS08wT4AqoLDvXrPi7VrloU9W',NULL,NULL,NULL,NULL,NULL,'no',NULL,'Film Festival',NULL,NULL,NULL,NULL,NULL,NULL,'https://ibestff.com',NULL,NULL,NULL,NULL,NULL,NULL,'no',NULL,'Santa Monica',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'yes',NULL,'yes','yes','yes','Ibestff','yes',NULL,'off','Other','no',NULL,'yes',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'yes','no',NULL,NULL,'no','no','no','yes','yes',NULL,'no','no','yes','yes','yes','yes',NULL,'2023-07-12 13:22:33','2025-11-20 01:21:49',NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,'organizer',0,0,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL),(3613,'Muse Layer LLC',NULL,'muselayerllc',0,NULL,'$2y$10$52gSuZV34icx4OCHfbO.JOhA9MIA3T8IENpW8BV94xN7pYBnUgWs6','muselayerllc@gmail.com',NULL,NULL,0,NULL,NULL,NULL,'ES',0,NULL,NULL,'es','d/m/Y','H:i','UTC','2025-12-22 12:22:30','profiles/3613/9bf53ed9-ee3c-4f62-966b-e306865c50d2.png',NULL,'active','normal','none','x88NYA0kGK7fZ1LEHeGzMddMfeG6EWLjq5mgL9tgf2AU2B1qeM3hl3orp7FK',NULL,NULL,NULL,NULL,NULL,'no',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'no',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'yes',NULL,'yes','yes','yes',NULL,'yes',NULL,'off',NULL,'no',NULL,'yes',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'yes','no',NULL,NULL,'no','no','no','yes','yes',NULL,'no','no','yes','yes','yes','yes',NULL,'2025-12-22 11:22:30','2025-12-22 14:59:05',NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,'organizer',0,0,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wishlists`
--

DROP TABLE IF EXISTS `wishlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wishlists` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `event_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_wishlists_event_id` (`event_id`),
  CONSTRAINT `fk_wishlists_event_id` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wishlists`
--

LOCK TABLES `wishlists` WRITE;
/*!40000 ALTER TABLE `wishlists` DISABLE KEYS */;
/*!40000 ALTER TABLE `wishlists` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-29  6:03:40
